@echo off
echo ================================================
echo BICA - Business Intelligence Conversion Agent v0.11.22
echo ================================================
echo.
cd /d "%~dp0"
echo Installing BICA...
echo.

REM Try python -m pip first, then pip, then pip3
python -m pip install --upgrade bica-0.11.22-py3-none-any.whl
if %ERRORLEVEL% NEQ 0 (
    pip install --upgrade bica-0.11.22-py3-none-any.whl
    if %ERRORLEVEL% NEQ 0 (
        pip3 install --upgrade bica-0.11.22-py3-none-any.whl
        if %ERRORLEVEL% NEQ 0 (
            echo.
            echo ERROR: Installation failed. Make sure Python 3.9+ is installed.
            echo Download from: https://www.python.org/downloads/
            echo.
            echo IMPORTANT: During Python installation, check "Add Python to PATH"
            pause
            exit /b 1
        )
    )
)

echo.
echo Installing the Tableau Hyper API (reads the data inside .twbx extracts)...
REM Bundled wheel first (works without internet), then the internet as a fallback.
python -m pip install --no-index --find-links "%~dp0wheels" tableauhyperapi
if %ERRORLEVEL% NEQ 0 python -m pip install tableauhyperapi
python -c "import tableauhyperapi" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo WARNING: The Tableau Hyper API could not be installed. Workbooks whose data is in a
    echo Tableau extract will convert WITHOUT data. Make sure you use 64-bit Python.
) else (
    echo Tableau Hyper API: installed.
)

echo.
echo ================================================
echo Installation complete!
echo.
echo To start BICA, run: run.bat
echo ================================================
echo.
pause

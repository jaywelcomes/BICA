#!/bin/bash
echo "================================================"
echo "BICA - Business Intelligence Conversion Agent v0.11.24"
echo "================================================"
echo ""
cd "$(dirname "$0")"
echo "Installing BICA..."
echo ""

pip3 install --upgrade bica-0.11.24-py3-none-any.whl
if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Installation failed. Make sure Python 3.9+ is installed."
    echo "On Mac: brew install python3"
    echo "On Ubuntu/Debian: sudo apt install python3 python3-pip"
    exit 1
fi

echo ""
echo "Installing the Tableau Hyper API (reads the data inside .twbx extracts)..."
pip3 install --no-index --find-links ./wheels tableauhyperapi 2>/dev/null || pip3 install tableauhyperapi \
  || echo "WARNING: tableauhyperapi not installed - workbooks whose data is in an extract will convert without data"

echo ""
echo "================================================"
echo "Installation complete!"
echo ""
echo "To start BICA, run: ./run.sh"
echo "Or from command line: bica ui"
echo "================================================"

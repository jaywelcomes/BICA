# BICA - Business Intelligence Conversion Agent

Convert Tableau workbooks (.twb/.twbx) to Power BI projects (PBIP).

## What's new in 0.11.27

**"The key didn't match any rows ... Key=[Name=gta_trend_view, Kind=Table]" is fixed.**
BICA looked up every database object as `Kind="Table"`. gta_trend_view is a database *view*,
which Redshift, Snowflake, BigQuery, Databricks and Denodo list as `Kind="View"`, so the Live
step found nothing. Tables and views are now looked up by name only, the way Power BI's
Navigator writes it: `Schema{[Name="gta_trend_view"]}[Data]`. (`tableau2pbip/nav_guard.py`)

**Far fewer queries and steps for Tableau groups.** Each group used to add a `Map_<group>`
helper query plus four steps (Merged / Expanded / Added / Removed helper). Now all the groups
of a table are one step, "Added group columns", with the member lists written inside it, and
the Map_* queries are gone. The result is the same, and there are no joins to run on refresh.
(`tableau2pbip/group_steps.py`; set BICA_GROUP_STEPS=queries for the old layout)

**The right database connector for every source.** Every Tableau connection class maps to its
own Power Query connector: Denodo (Power BI's native Denodo connector, `Denodo.Contents`), SAP
HANA, SQL Server / Azure SQL / Synapse, Amazon Redshift, Oracle, Snowflake, PostgreSQL, MySQL,
Teradata, Db2, BigQuery and Databricks. "Other Databases (ODBC/JDBC)" connections are recognised
by their driver, JDBC URL, host or port (for example `DenodoODBC`, `jdbc:denodo://`, `HDBODBC`,
`*.redshift.amazonaws.com`, port 9996 / 30015 / 1521). (`tableau2pbip/source_detect.py`)

**Tableau Server published data sources use their real database.** A workbook that uses a
published data source (like "Inventory Daily movment" -> "Daily movment") does not contain the
database connection; it is only on Tableau Server. 0.11.26 then used the default (Amazon
Redshift) without saying so. BICA now finds the real connection, in this order:

1. `published_sources.json` next to the workbook, in a `--data-dir` folder or in
   `%USERPROFILE%\.tableau2pbip\`:
   ```json
   {
     "Daily movment": {"type": "denodo", "server": "denodo-host", "database": "inventory",
                       "table": "dv_daily_movement"},
     "*":             {"type": "redshift"}
   }
   ```
   `type` is any of: denodo, saphana, sqlserver, azuresql, redshift, oracle, snowflake, postgres,
   mysql, teradata, db2, bigquery, databricks. `server`, `database`, `table` (or `schema.table`)
   and `sql` (Custom SQL) are optional. Without a server, the table gets `<Type>_Server` /
   `<Type>_Database` parameters (Transform data > Edit parameters). Without a table, the table or
   view named like the data source is used, or the Custom SQL in the `<source>_SQL` parameter.
   `"*"` is the default for every published source not listed.
2. A downloaded `.tds` or `.tdsx` of the data source next to the workbook (or uploaded with it).
3. Tableau Server, once "Set Tableau Server login.bat" has been run: BICA reads the data source's
   connection (type, server, port) from the REST API and the table behind it from the Metadata
   API. This works even without the Download permission.
4. Otherwise the default type (database.json / BICA_DB_TYPE, Redshift if not set). The report
   and the query now say **DATABASE TYPE ASSUMED**, so a wrong guess is visible.

## What's new in 0.11.26

**EMPLOYEE MASTER loads in Power BI.** In 0.11.25 the refresh stopped with three errors. Each
one is fixed for every workbook:

- *"DAX comparison operations do not support comparing values of type Text with values of type
  Integer"*. A published data source keeps its own parameters. When the workbook already has a
  parameter with the same internal name, Tableau renames the data source's one ("Parameter 1" ->
  "Parameter 1 1"). The calculations from the published source still use the old name. BICA used
  the workbook's parameter of that name, so FX Rate compared the text parameter Time Dimension
  with 1. These calculations now use the renamed parameter, as Tableau does.
  (`tableau2pbip/published_params.py`)
- *"The MEDIAN function only accepts a column reference"*. SUM, AVERAGE, MIN, MAX, MEDIAN,
  COUNT and DISTINCTCOUNT over an expression become their iterator form (MEDIANX ...).
- *"Memory Allocation failure"*. Calculated columns no longer call measures. A measure in a
  column makes Power BI filter the table by every column for every row. Parameter and date values
  are now written into the column directly. Whole-table MIN/MAX columns drop their CALCULATE. A
  FIXED MEDIAN column is computed once per key in a hidden helper table and looked up, instead of
  re-sorting the group for every row. (`tableau2pbip/dax_guard.py`)

The visuals' "Something's wrong with one or more filters" came from the failed load: their
filters are on EMPLOYEE MASTER calculated columns, which had no values.

## What's new in 0.11.25

The conversion is now the same for every workbook and every source; nothing is tuned per file.
On "CEO Pay Ratio 2" it went from 171 converted / 141 manual (57%) to 343 converted / 0 manual.

**Every source column is read.** Published data sources and many databases store numeric
columns as "measure" records; they were skipped, so 22 EMPLOYEE MASTER columns (direct_reports,
loc_salary, successors_total ...) and every calculation using them were missing.
(`tableau2pbip/field_capture.py`)

**Calculations convert in any order.** A calculation that uses another one waits for it instead
of failing; sets, groups, FIXED / INCLUDE / EXCLUDE inside bigger formulas, DATEPARSE, ISDATE,
SPLIT, MAKEDATETIME, INT/FLOAT on text and more are translated. Calculations that use a parameter
stay live in visuals. (`tableau2pbip/calc_engine.py`)

**Every database connects.** Oracle, SAP HANA, Redshift, PostgreSQL, MySQL, Teradata, Db2, SQL
Server / Azure, BigQuery, Snowflake and ODBC sources get the same M that Power BI's Navigator
writes; Power BI asks for the sign-in on first refresh. A source that also has an extract gets
a "Data_Source_Mode" parameter: Live (default, current data) or Extract (the snapshot in the
Data folder, works offline). Tables load in Import mode (set BICA_STORAGE=auto for the old
DirectQuery choice). (`tableau2pbip/connectors.py`)

**Published data sources with no data** (EMPLOYEE MASTER) connect to the database in the
Database_Server / Database_Name parameters and read the table with the same name. If the table
has another name, paste the published source's Custom SQL into the "<source>_SQL" parameter.
Best: run "Set Tableau Server login.bat" once and convert again; BICA then downloads the data
source and uses its exact connection.

**Extracts are fast.** Hyper now writes the CSVs itself: 2 million Oracle rows in 2.8 s instead
of 17.5 s. (`tableau2pbip/fast_extract.py`; BICA_FAST_EXTRACT=0 uses the old exporter)

**More filters carry over.** Month-Year, week, weekday and month/day/year filters, number and
date ranges, relative dates ("last 3 months"), data source date filters, and calculations typed
directly on a worksheet. (`tableau2pbip/filter_plus.py`)

**Parameters look like Tableau.** List parameters show their display names (Select an Audit:
"None", "<50% Market Ratio" ...) in Tableau's order while the measure still returns the value.
Date parameters that accept any date get a date table and a date slicer.
(`tableau2pbip/param_plus.py`)

## What's new in 0.11.24

**KPI columns show their values.** Tableau stores its standard number format as just "N"; Power BI
printed that letter instead of the number, so Hold, Cancelled, Closures, Total Roles, Active Roles,
KIV and Duplicates were unreadable. They now use "#,0". A calculation that returns a date
(1st CV Submission Date = MIN(forwarded_date)) got a number format and showed "#,0.00" on every
row; date results now get a date format. (`tableau2pbip/format_guard.py`)

**DATE() on text no longer breaks a column.** Tableau's DATE("") is NULL; the DAX DATEVALUE
raised an error that fails the whole calculated column (REQ Approved Date, REQ Closed Date). It
now returns blank, like Tableau.

## What's new in 0.11.23

**"By Category 1" / "By Category 2" now switch the Scorecard like in Tableau.** In 0.11.22 the
field parameters were created, but the visuals used the parameter column as a plain column, so
Power BI drew one category named "Role Category" with every measure in one bar group. Visuals now
declare the field parameter the way Power BI stores it (`fieldParameters` in the visual), so
picking Region / Country / Team ... in the slicer swaps the breakdown. The slicer preset also
follows renamed columns (e.g. "Region (2)").

**Scorecard sheets become a matrix.** A sheet with Measure Names on Rows and dimensions on Columns
(GTA "Scorecard" and "Scorecard Chart") is now a matrix: measures as rows, Category 1 > Category 2
as nested columns, no subtotals, and data bars in each cell for the Bar version, instead of one
clustered column chart / a flat table. (`tableau2pbip/measure_grid.py`)

The parameter and field-parameter tables have no relationships on purpose: they only pick which
field a visual shows, they never filter the data.

## What's new in 0.11.22

**Fixes "Expression.Error: The name 'human_resources_reporting' wasn't recognized"** after
pointing a converted table at its real database. A workbook that uses a Tableau Server published
data source with no extract (e.g. "GTA SOURCING MODEL | Project : 03 GTA") used to convert to an
empty placeholder table with no data source behind it, so Power BI showed no source to repoint
and the navigation steps Power BI adds by hand did not fit the converted query. The workbook does
record the database table behind the published source (here
`human_resources_reporting.gta_sourcing_model`), so the table now gets the full navigation,
written the way Power BI's Navigator writes it:

```
Source = AmazonRedshift.Database(Database_Server, Database_Name),
human_resources_reporting = Source{[Name="human_resources_reporting"]}[Data],
gta_sourcing_model = human_resources_reporting{[Name="gta_sourcing_model"]}[Data],
```

Table, column and file names are unchanged. Server and database are Power Query parameters
(Transform data > Edit parameters); sign in to the database when Power BI asks, then Refresh.
Defaults: the HR Redshift cluster / `techr`. Change them per machine with
`~/.tableau2pbip/database.json` (`{"type": "redshift", "server": "...", "database": "..."}`) or the
variables `BICA_DB_TYPE`, `BICA_DB_SERVER`, `BICA_DB_NAME` (types: redshift, sqlserver,
postgresql, snowflake). `BICA_PUBLISHED_SOURCE=placeholder` restores the old empty table.
(`tableau2pbip/source_link.py`)

**More of the workbook is carried over:**
- Data source filters become a Power Query step (e.g. Req Status: nulls removed) and filters set
  to "All using this data source" become report-level filters (e.g. the Req Status list). A data
  source filter on a security calculation (ISMEMBEROF) is reported as row-level security to
  build in Power BI, not applied. (`filter_capture.py`)
- FIXED LOD calculations are translated instead of left blank: `{ FIXED [Req Id] : ... }`
  becomes a calculated column, `AVG({ FIXED ... })` a measure weighted the way Tableau does it
  ("# Req Aged", "1st CV Submission", "TAT - 1st CV Submission"), so "Role Category" is a real
  column again. DATEDIFF with an empty date now gives blank, as in Tableau, instead of a huge
  number of days. (`lod_capture.py`)
- "Show by" parameters (`CASE [By Category 1] WHEN 1 THEN "Global" WHEN 2 THEN [Role Category]
  ...`) become Power BI field parameters ("Categroy 1", "Categroy 2"); the slicer lists Global /
  Role Category / Region / Country / Team / Submission Year / Submission Quarter, preset to the
  workbook's value. (`param_dims.py`)

## What's new in 0.11.21

**Fixes "Can't display this visual. This visual contains one or more filters with deleted
columns, type mismatches, or other breaking modeling changes."** Tableau sheet filters were
written into each visual with the values exactly as Tableau stores them, on the base column.
Power BI refuses to draw a visual when a filter value's type differs from its column's type.
That happened for filters on YEAR / QUARTER / MONTH / DAY of a date (2023, 2024 written against
the date column), for whole numbers on a decimal column (2 written as 2L instead of 2D), and for
values of one type on a column of another (number vs text, 1/0 vs true/false). A new layer
(`tableau2pbip/filter_guard.py`) puts date-part filters on the matching date-part column
("Order Date Year", "Order Date Month No", "Order Date Quarter") with converted values, keeps
filters on exact dates (written as datetime literals instead of being dropped), and converts
every filter value to its column's type. Anything that cannot be converted is left out and
listed under "Model notes" in `MIGRATION_REPORT.md`, so the visual always loads.

## What's new in 0.11.20

**Fixes "!! failed: None".** Workbooks saved by a recent Tableau version (2020.2 and later)
store a single-table data source in a feature-flagged XML tag (`_.fcp...relation`) instead of a
plain `<relation>`. BICA did not read that tag, so such a data source (very common with
Redshift) had no tables and the conversion stopped with `KeyError: None`. A new layer
(`tableau2pbip/fcp_compat.py`) reads these tags, so the tables, their columns and the
extract data are converted normally.

**One problem no longer fails the whole workbook** (`tableau2pbip/resilience.py`). Each data
source step and each sheet runs in its own safety net: if one fails, the log shows the real
error (type, message and file/line, e.g. `KeyError: missing key None (mapper.py:267 in
add_measure)`), the item is listed under "Needs review" in `MIGRATION_REPORT.md`, a text box
marks a failed sheet, and the rest of the workbook is converted. If a conversion still fails,
the log shows the real reason and a short traceback, and the full details are saved to
`BICA_error_<workbook>.txt` in the output folder.

## What's new in 0.11.19

**Workbooks that use Tableau Server published data sources now get their data too.** Such a
workbook only links to the server, so before 0.11.19 those tables were empty. BICA now does
two steps automatically:

1. **Download:** it signs in to the Tableau Server named in the workbook with your personal
   access token, finds each published data source the workbook uses and downloads it with its
   extract (.tdsx).
2. **Convert with data:** the extract goes to the project's `Data/` folder and the tables load
   from it, like an extract packaged in a .twbx. Column names that differ only in case or
   spacing ("Employee ID" / employee_id) are matched.

**One-time setup:** in Tableau Server open *My Account Settings > Personal Access Tokens* and
create a token, then double-click **`Set Tableau Server login.bat`** and enter the token name
and secret (saved in `%USERPROFILE%\.tableau2pbip\tableau_server.json`, never in the project).
Your account needs the *Download Data Source* permission on those data sources. Without a
login, or if you already have the files, put the downloaded .tdsx files next to the workbook
(or upload them together in the web interface); they are matched by name.

A published data source that is a live connection (not an extract) has no data on the server
to download; the report says so for that table. Every download and match is listed under
"Data sources" in `MIGRATION_REPORT.md`.

## What's new in 0.11.18

**Reports open with data, not an empty skeleton.** A .twbx carries its data (Tableau extracts,
CSV and Excel files). BICA now always ships that data inside the converted project:

- Every extract table is written as a CSV file to the project's `Data/` folder and the
  Power BI tables load from it, so visuals show the same numbers as in Tableau. Before, a
  workbook connected to a database (e.g. Redshift) ignored its extract and pointed at the
  database, which gave empty tables until someone re-pointed them.
- Data sources that are a `.hyper` file, and multi-table extracts (Tableau 2020.2+), are read too.
- `MIGRATION_REPORT.md` lists each source's original connection (server, database) so you
  can point a table back at the live source later. To convert straight to the live database
  instead, choose **Never use extracts** in the web interface (or `--extracts never`).
- **`Open in Power BI.bat`** in every project folder: double-click it to open the report. It
  first points the `Data_Folder` parameter at the `Data` folder next to it, so the data loads
  wherever you extracted the project (Power Query needs a full path).
- **The Tableau Hyper API is bundled** in the `wheels/` folder (Windows, 64-bit Python 3.9+).
  `install.bat` and `run.bat` install it without internet; without it, extract data cannot be
  read. This is why the download is larger (about 75 MB).

A data source that has no extract in the workbook (a live database connection) has no data to
ship; the report says so for that table, and you sign in to the database in Power BI.

## What's new in 0.11.17

**Fixes "M Engine error: Invalid identifier".** Power Query only accepts a plain `[Column]`
reference when the name is letters, digits, underscores and single spaces. Tableau names such
as `Region/Area`, `Dept-Code`, `Headcount %`, `Gender (group)` or ` Sales` (leading space)
must be written `[#"Region/Area"]`. A new safety layer (`tableau2pbip/m_guard.py`) now quotes
every column, field, record and step name in every generated query wherever Power Query
requires it, and never touches text inside strings or comments.

**New model checks (`tableau2pbip/model_guard.py`)**, each fixed automatically and listed
under "Model notes" in `MIGRATION_REPORT.md`:

- names with leading/trailing spaces, tabs or line breaks are cleaned (and every reference updated)
- relationships to a missing table/column, a table to itself, or between columns of different
  data types are removed; when two tables are connected by more than one active path
  ("ambiguous paths"), the extra relationships are written as inactive
- sort-by columns that are missing, point at themselves, or form a chain are cleared
- hierarchy levels that are not columns are dropped; empty hierarchies removed
- measures with an empty formula become `BLANK ()`; a table with no columns gets a hidden
  placeholder column
- report visuals and filters drop fields that are not in the model
- duplicate lineage tags are made unique

`bica validate` (and the "Validation problems" section of the report) now also checks every
Power Query in the written project for unquoted names and unbalanced brackets, names with
stray spaces, empty measures and duplicate lineage tags. As in 0.11.16, the existing converter
code is unchanged: the new layers are separate modules switched on in `__init__.py`.

## What's new in 0.11.16

**No more "Item 'X' already exists in the collection" errors.** Tableau treats names that differ
only in upper/lower case as different (`Employees` and `employees`, `Gender Group` and
`GENDER group`); Power BI does not. A new final step (the *Power BI name guard*,
`tableau2pbip/name_guard.py`) now checks every name before the project is written and renames
anything that would clash, updating every DAX formula, Power Query step, relationship,
hierarchy, sort-by column and report visual that refers to it. It covers:

- tables (also on a case-insensitive Windows disk, where `Sales.tmdl` and `sales.tmdl` collide)
- Power Query expressions and parameters, including ones that share a name with a table
  (e.g. `Map_Gender_Group`)
- columns, measures and hierarchies inside a table, and measures across the whole model
- hierarchy levels, duplicate relationships, Power Query step names and copied data files

Every rename is listed under **Model notes** in `MIGRATION_REPORT.md` as "Name fix: ...", and
`bica validate` now also reports expression/table clashes, duplicate relationships and
duplicate hierarchy levels. The existing converter logic is unchanged.

**Maps use Azure Maps.** Tableau maps used to become the Bing-based Power BI map, which Power BI
is retiring ("Bing map visuals are going away"). They are now written as Azure Maps visuals
(new layer `tableau2pbip/azure_maps.py`) with the same Location / Size / Legend fields. If a
map shows blank, your Power BI admin needs to allow Azure Maps in the tenant settings.

**Version check on start:** `run.bat` / `run.sh` now show the version and install the bundled
wheel automatically if an older BICA is still installed on the machine.

**Upgrading:** run `install.bat` / `install.sh` again (it now uses `pip install --upgrade`),
then convert the workbook again. Projects converted with an older version keep their old names
until they are re-converted.

## Quick Start

**First, extract this zip to a normal folder** (right-click > Extract All). Do not run the files from inside the zip.

### Windows

1. **Install Python 3.9+** from [python.org](https://www.python.org/downloads/) if not already installed. During setup, tick "Add Python to PATH".
2. Double-click `install.bat` to install BICA
3. Double-click `run.bat` to start the web interface
4. Open http://127.0.0.1:8765 in your browser

### Mac/Linux

1. Open Terminal in this folder
2. Run: `./install.sh`
3. Run: `./run.sh`
4. Open http://127.0.0.1:8765 in your browser

## Manual Installation

```bash
pip install bica-0.11.24-py3-none-any.whl
```

To include Tableau .hyper extract support (bundled, no internet needed):
```bash
pip install --no-index --find-links wheels tableauhyperapi
```

## Usage

### Web Interface (Recommended)
```bash
bica ui
```
Then open http://127.0.0.1:8765 in your browser.

### Command Line
```bash
bica convert <workbook.twbx> -o <output-folder>
```

## Output

Each converted workbook produces a `_PBIP` folder containing:
- `.pbip` file - Open this in Power BI Desktop
- `.SemanticModel/` - TMDL data model
- `.Report/` - PBIR report definition
- `Data/` - Copied data files
- `MIGRATION_REPORT.md` - What was converted and what needs review
- `Reconciliation_Report.xlsx` - Validation results

**Open the project from a normal folder, not from inside a zip.** If you zip a project to share it, extract it fully (for example to `C:\MyProject_PBIP`) before double-clicking the `.pbip` file. Opening it from inside the zip gives "Required artifact is missing ... definition.pbir".

## Workbooks that use Tableau Server published data sources

From 0.11.22 a published source with no data in the workbook is connected to the database table
behind it (see "What's new in 0.11.22"): open the `.pbip`, sign in to the database and refresh.
If the server or database differs, change the `Database_Server` / `Database_Name` parameters
(Transform data > Edit parameters). Tables that still convert empty (older workbooks that do not
record the table) can be pointed at Redshift with:

```bash
python set_redshift_source.py "<...>_PBIP" --employee <schema.table> --succession <schema.table>
```

See the header of `set_redshift_source.py` for details.

## Things to review after converting

- `MIGRATION_REPORT.md` lists every item that needs manual work.
- **Row-level security** (`USERNAME()`, `ISMEMBEROF()`) is not converted. Build equivalent roles in Power BI before sharing a report that holds sensitive data.
- Relationships between tables that came from Tableau data blends must be set up manually.
- Calculated fields that live only on a Tableau Server published source are missing unless you also export and convert that source as `.tdsx`.

## Custom Logos

Place your logo files in the `logos/` folder:
- `company.png` - Your brand logo (top left)
- `tableau.png` - Tableau logo
- `powerbi.png` - Power BI logo

## Requirements

- Python 3.9 or higher
- Power BI Desktop (to open converted projects)

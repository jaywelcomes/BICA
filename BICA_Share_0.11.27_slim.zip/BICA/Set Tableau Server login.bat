@echo off
echo ================================================
echo BICA - Tableau Server login (personal access token)
echo ================================================
echo.
echo Lets BICA download the published data sources a workbook uses, so the
echo converted report opens with data. Saved in your Windows user profile only.
echo.
python -m tableau2pbip.tableau_server
echo.
pause

Logos for tableau2pbip's Business Intelligence Conversion Agent
==================================================================

Put image files here to show real logos in the web interface. Names are
matched loosely (case, spaces and extra words are fine, e.g. "Power BI Logo.PNG").
Supported: .svg, .png, .webp, .jpg, .jpeg, .gif, .avif. Main names:

  company          your primary brand logo, shown at the top left (bica.*, capgemini.* or app.* also work)
  footer           a small secondary/credit logo, shown bottom-right in the footer (optional; poweredby.* also works)
  tableau          Tableau
  powerbi          Power BI
  cognos           IBM Cognos
  microstrategy    MicroStrategy
  qlik             Qlik Sense
  businessobjects  SAP BusinessObjects
  looker           Looker

Example: tableau.svg, powerbi.png. Check what was picked up with:
  tableau2pbip logos
Use the official files from each vendor's
brand or press page and follow their usage guidelines. Square images with a
transparent background look best. Reload the page after adding files; missing
logos fall back to letter tiles.

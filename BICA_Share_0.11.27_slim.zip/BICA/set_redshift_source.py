"""Point the two empty published-data-source tables of a converted project at Redshift.

Usage (from any folder):
  python set_redshift_source.py "<...>_PBIP" ^
      --employee human_resources.employee_master ^
      --succession human_resources.succession_planning

Each table's partition starts with a placeholder step
    Source = #table(type table [col = type, ...], {})
which already lists the right (Tableau remote) column names. Every later step - select,
retype, rename, group merges - is built on that step, so only this one line is replaced
by a Redshift query that returns the same columns. Column names are lower-case in Redshift,
which matches the names Tableau used.

The project is backed up to "<project>_backup_before_redshift" first. Re-run the same
command to change the table names (it only touches the Source line).
"""
import argparse
import glob
import os
import re
import shutil
import sys

HOST = "te-aws-hr-redshift-cluster.cjddorcehwap.us-east-1.redshift.amazonaws.com:5439"
DB = "techr"

PLACEHOLDER = re.compile(r"^(?P<ind>[ \t]*)Source = #table\(type table \[.*?\], \{\}\),[ \t]*$", re.M)
ALREADY = re.compile(r"^(?P<ind>[ \t]*)Source = Value\.NativeQuery\(AmazonRedshift\.Database\(.*\),[ \t]*$", re.M)
TODO = re.compile(r"^[ \t]*// TODO: Tableau connection 'sqlproxy' was not converted\..*\n", re.M)


def find_table_file(project, marker):
    pat = os.path.join(project, "*.SemanticModel", "definition", "tables", "*.tmdl")
    hits = [f for f in glob.glob(pat) if marker.lower() in os.path.basename(f).lower()]
    if len(hits) != 1:
        sys.exit(f"Expected exactly one table file matching '{marker}', found {len(hits)}.")
    return hits[0]


def patch(path, relation, host, db):
    with open(path, encoding="utf-8", newline="") as fh:
        text = fh.read()
    nl = "\r\n" if "\r\n" in text else "\n"
    text = text.replace("\r\n", "\n")
    if not re.fullmatch(r"[A-Za-z_][\w$]*\.[A-Za-z_][\w$]*", relation):
        sys.exit(f"'{relation}' must look like schema.table (letters, digits, underscore).")
    sql = f"SELECT * FROM {relation}"
    new = ('Source = Value.NativeQuery(AmazonRedshift.Database("%s", "%s"), "%s", null, '
           '[EnableFolding = true]),' % (host, db, sql))
    pat = PLACEHOLDER if PLACEHOLDER.search(text) else ALREADY
    if not pat.search(text):
        sys.exit(f"Could not find the Source step in {os.path.basename(path)}.")
    text = pat.sub(lambda m: m.group("ind") + new, text, count=1)
    text = TODO.sub("", text, count=1)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text.replace("\n", nl))
    print(f"  {os.path.basename(path)} -> {sql}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("project", help="the converted <Name>_PBIP folder")
    ap.add_argument("--employee", required=True, help="schema.table for 'EMPLOYEE MASTER | Project : 01 HR GENERAL'")
    ap.add_argument("--succession", required=True, help="schema.table for 'Succession Planning | Project : 05 GTM'")
    ap.add_argument("--host", default=HOST)
    ap.add_argument("--database", default=DB)
    a = ap.parse_args()

    project = os.path.abspath(a.project)
    if not os.path.isdir(project):
        sys.exit(f"Not a folder: {project}")
    emp = find_table_file(project, "EMPLOYEE MASTER")
    suc = find_table_file(project, "Succession Planning")
    backup = project + "_backup_before_redshift"
    if not os.path.exists(backup):
        shutil.copytree(project, backup)
        print(f"Backup: {backup}")
    patch(emp, a.employee, a.host, a.database)
    patch(suc, a.succession, a.host, a.database)
    print("Done. Open the .pbip, sign in to Redshift when asked, then Refresh.")


if __name__ == "__main__":
    main()

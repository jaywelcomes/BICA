@echo off
echo ================================================
echo BICA - Database behind Tableau Server published data sources
echo ================================================
echo.
echo A workbook that uses a published data source does not say which database
echo is behind it. Tell BICA once (Denodo, SAP HANA, SQL Server, Oracle ...);
echo it is saved in your Windows user profile and used by every conversion.
echo.
python -c "import tableau2pbip,sys; sys.exit(0 if tableau2pbip.__version__=='0.11.28' else 1)" 2>nul
if %ERRORLEVEL% NEQ 0 python -m pip install --upgrade "%~dp0bica-0.11.28-py3-none-any.whl"
python -m tableau2pbip.set_sources %*
echo.
pause

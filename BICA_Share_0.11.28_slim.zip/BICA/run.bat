@echo off
echo ================================================
echo BICA - Business Intelligence Conversion Agent v0.11.28
echo ================================================
echo.

REM Make sure the BICA version in this folder is the one that is installed
REM (an older BICA left installed would otherwise start and show its own version),
REM and that the Tableau Hyper API is there so extract data can be read.
set "BICA_WHL=%~dp0bica-0.11.28-py3-none-any.whl"
python -c "import tableau2pbip,sys; sys.exit(0 if tableau2pbip.__version__=='0.11.28' else 1)" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Installing BICA 0.11.28 ...
    python -m pip install --upgrade "%BICA_WHL%"
    echo.
)
python -c "import tableauhyperapi" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Installing the Tableau Hyper API from the bundled wheels folder ...
    python -m pip install --no-index --find-links "%~dp0wheels" tableauhyperapi || python -m pip install tableauhyperapi
    echo.
)

echo Starting web interface...
echo.
echo Open your browser to: http://127.0.0.1:8765
echo Press Ctrl+C to stop the server
echo.

REM Try bica command first
bica ui --port 8765 2>nul
if %ERRORLEVEL% NEQ 0 (
    REM Fall back to python module
    python -m tableau2pbip ui --port 8765 2>nul
    if %ERRORLEVEL% NEQ 0 (
        python3 -m tableau2pbip ui --port 8765 2>nul
        if %ERRORLEVEL% NEQ 0 (
            echo.
            echo ERROR: Could not start BICA.
            echo Please run install.bat first.
            pause
        )
    )
)

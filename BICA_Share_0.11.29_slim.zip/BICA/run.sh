#!/bin/bash
echo "================================================"
echo "BICA - Business Intelligence Conversion Agent v0.11.29"
echo "================================================"
echo ""
HERE="$(cd "$(dirname "$0")" && pwd)"
if ! python3 -c "import tableau2pbip,sys; sys.exit(0 if tableau2pbip.__version__=='0.11.29' else 1)" 2>/dev/null; then
    echo "Installing BICA 0.11.29 ..."
    pip3 install --upgrade "$HERE/bica-0.11.29-py3-none-any.whl"
    echo ""
fi
if ! python3 -c "import tableauhyperapi" 2>/dev/null; then
    echo "Installing the Tableau Hyper API ..."
    pip3 install --no-index --find-links "$HERE/wheels" tableauhyperapi 2>/dev/null || pip3 install tableauhyperapi
    echo ""
fi
echo "Starting web interface..."
echo ""
echo "Open your browser to: http://127.0.0.1:8765"
echo "Press Ctrl+C to stop the server"
echo ""
bica ui --port 8765

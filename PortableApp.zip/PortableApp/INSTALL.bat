@echo off
REM ============================================================
REM  BI Conversion Agent - One-time Installation
REM  Run this ONCE after copying to Windows
REM ============================================================

echo.
echo ============================================================
echo    BI Conversion Agent - Installing Dependencies
echo ============================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo.
    echo Please install Python 3.9 or later from:
    echo https://www.python.org/downloads/
    echo.
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)

echo Python found:
python --version
echo.

echo Installing dependencies...
python -m pip install --upgrade pip
pip install pandas openpyxl jsonschema referencing
pip install -e .

if errorlevel 1 (
    echo.
    echo ERROR: Installation failed!
    pause
    exit /b 1
)

echo.
echo ============================================================
echo    Installation Complete!
echo ============================================================
echo.
echo You can now run the application using:
echo    RUN.bat          (starts the web interface)
echo    RUN_CLI.bat      (shows command line help)
echo.
pause

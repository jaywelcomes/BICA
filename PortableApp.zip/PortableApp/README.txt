============================================================
  BI Conversion Agent - Portable Python Version
  Tableau to Power BI Converter
============================================================

REQUIREMENTS:
  - Python 3.9 or later (https://www.python.org/downloads/)
  - During Python installation, CHECK "Add Python to PATH"

SETUP (one time):
  1. Copy this entire folder to your Windows machine
  2. Double-click INSTALL.bat to install dependencies

RUNNING THE APPLICATION:
  - Double-click RUN.bat to start the web interface
  - The web interface opens in your browser automatically
  - Keep the command window open while using the app

COMMAND LINE USAGE:
  - Double-click RUN_CLI.bat for help
  - Or open Command Prompt in this folder and run:
      python -m tableau2pbip convert myfile.twbx -o output
      python -m tableau2pbip ui

FEATURES:
  - Convert Tableau .twb and .twbx files to Power BI PBIP format
  - Batch conversion of multiple files
  - Web interface for easy drag-and-drop
  - Reconciliation reports
  - AI-assisted conversion (requires API key)

LOGOS:
  - Place your company logo in the logos/ folder
  - Supported names: company.png, bica.png, capgemini.png
  - Product logos: tableau.png, powerbi.png, etc.

============================================================

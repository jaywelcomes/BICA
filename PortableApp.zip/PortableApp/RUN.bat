@echo off
REM ============================================================
REM  BI Conversion Agent - Start Web Interface
REM ============================================================

echo Starting BI Conversion Agent...
echo.
echo The web interface will open in your browser.
echo Keep this window open while using the application.
echo Press Ctrl+C to stop the server.
echo.

python -m tableau2pbip ui --logos logos

if errorlevel 1 (
    echo.
    echo ERROR: Failed to start. Did you run INSTALL.bat first?
    pause
)

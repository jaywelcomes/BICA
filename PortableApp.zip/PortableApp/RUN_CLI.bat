@echo off
REM ============================================================
REM  BI Conversion Agent - Command Line Interface
REM ============================================================

echo BI Conversion Agent - Command Line
echo.
echo Usage Examples:
echo   python -m tableau2pbip convert myfile.twbx -o output_folder
echo   python -m tableau2pbip ui
echo   python -m tableau2pbip validate output_folder/Project_PBIP
echo.
echo For full help:
echo   python -m tableau2pbip --help
echo   python -m tableau2pbip convert --help
echo.

python -m tableau2pbip --help

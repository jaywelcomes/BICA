"""Prepare the converted semantic model for Power BI Copilot / Q&A (no AI needed).

Levers written into the project files:
  1. descriptions on every table, column and measure (the useful part first: Copilot reads
     roughly the first 200 characters);
  2. enumerated values ("One of: A, B, C.") on text columns, when the data was read;
  3. AI instructions (CustomInstructions in the culture's linguistic metadata), with the
     editable source saved as ai-instructions.md in the project folder;
  4. settings.qnaEnabled = true in definition.pbism (without it, 1-3 are ignored).

Approach adapted from the powerbi-ai-readiness skill in
Guust-Franssens/tableau-to-powerbi-migration (MIT).
"""
from __future__ import annotations

import math
import os

from . import __version__, profiler

MAX_ENUM = 20
AGG_WORDS = {"Sum": "Sum", "Avg": "Average", "Count": "Count of non-blank values", "CountD": "Number of distinct values",
             "Min": "Minimum", "Max": "Maximum", "Median": "Median"}
TYPE_WORDS = {"string": "Text attribute", "int64": "Whole number", "double": "Number", "dateTime": "Date",
              "boolean": "True/false flag"}
DEFERRED = [
    "AI data schema (choose which fields Copilot may use) - set in the Power BI service",
    "Verified answers - need published report visuals",
    "\"Approved for Copilot\" and semantic indexing - tenant and workspace settings",
    "Refresh the model after publishing so the linguistic settings sync",
]


def _join(*parts):
    return " ".join(p.strip() for p in parts if p and p.strip())


def _values(plan, table, column):
    """Distinct non-blank values of a column from the loaded data, or None."""
    df = plan.frames.get(table)
    if df is None:
        return None
    if column not in df.columns:
        try:
            df = plan.derive_all(table, df.copy())
        except Exception:
            return None
        if column not in df.columns:
            return None
    s = df[column].dropna()
    s = s[s.astype(str).str.strip() != ""]
    vals = s.unique()
    if len(vals) == 0 or len(vals) > MAX_ENUM:
        return None
    return sorted(str(v) for v in vals)


def _fmt_num(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    if math.isnan(v):
        return "(blank)"
    return f"{v:,.0f}" if v.is_integer() else f"{v:,.2f}"


def enrich(plan, wb):
    """Fill in descriptions and build the AI instructions. Returns the readiness summary."""
    from .ai_stages import static_columns
    frozen = set(static_columns(plan))
    lookups = {r.to_table for r in plan.relationships if not r.many_to_many}
    facts = {r.from_table for r in plan.relationships}
    param_names = {r.name for (d, _), r in plan.field_map.items() if r.kind == "param"}
    stats = {"tables": [0, 0], "columns": [0, 0], "measures": [0, 0], "enumerated": [0, 0]}

    for t in plan.tables.values():
        rows = len(plan.frames[t.name]) if t.name in plan.frames else None
        if t.is_parameter:
            lead = "Parameter (control) table for a slicer; not a dimension, don't group or filter data by it."
        elif t.name in lookups and t.name not in facts:
            lead = "Lookup table."
        elif t.name in facts:
            lead = "Fact table."
        else:
            lead = "Table."
        size = f"{rows:,} rows when converted." if rows is not None else ""
        if not t.description.startswith(lead):
            t.description = _join(lead, t.source_note + "." if t.source_note else "", size, t.description)
        stats["tables"][1] += 1
        stats["tables"][0] += bool(t.description)

        for c in t.columns.values():
            stats["columns"][1] += 1
            parts = []
            is_text = c.dtype == "string" and not c.hidden
            if is_text:
                stats["enumerated"][1] += 1
                vals = _values(plan, t.name, c.name)
                if vals:
                    stats["enumerated"][0] += 1
                    shown = ", ".join(vals)
                    parts.append(f"One of: {shown}.")
            if (t.name, c.name) in frozen:
                parts.append("Uses parameter default values set at refresh; does not follow slicers.")
            if c.category:
                parts.append(f"Geographic field ({c.category}).")
            if c.expression and not c.description:
                parts.append("Calculated column.")
            if c.hidden and c.name.startswith("Key "):
                parts.append("Technical key for a relationship; not for analysis.")
            if not c.description and not parts:
                parts.append(f"{TYPE_WORDS.get(c.dtype, 'Value')} from {t.name}.")
            c.description = _join(*parts, c.description)
            stats["columns"][0] += bool(c.description)

        for m in t.measures:
            stats["measures"][1] += 1
            if m.name in param_names:
                lead = "Currently selected value of a parameter slicer."
            elif m.status == "placeholder":
                lead = "Not converted yet; returns blank. Do not use in answers."
            elif m.recon:
                deriv, rt, rc = m.recon
                lead = f"{AGG_WORDS.get(deriv, deriv)} of {rc} ({rt})."
            elif m.name.startswith("Is ") and "Tableau set" in m.description:
                lead = "Returns 1 for members of a Tableau set."
            elif m.name.startswith("Is "):
                lead = "Returns 1 for members of a Tableau set; use as a visual filter, not as a number."
            else:
                lead = "Measure converted from a Tableau calculated field."
            if m.status == "ai":
                lead += " AI-translated; review before relying on it."
            if not m.description.startswith(lead):
                m.description = _join(lead, m.description)
            stats["measures"][0] += bool(m.description)

    plan.ai_instructions = instructions(plan, wb, frozen, lookups, facts)
    plan.qna_enabled = True
    plan.readiness = stats
    return stats


def instructions(plan, wb, frozen, lookups, facts):
    lines = [f"# {plan.name}", "",
             f"Converted from the Tableau file {os.path.basename(wb.source_path)} by tableau2pbip {__version__}.", ""]
    security = [i for i in plan.items if i.area == "Security"]
    if security:
        lines += ["## Security", "",
                  "This model has NO row-level security. The source Tableau workbook restricted rows per "
                  "user (via " + ", ".join(sorted({i.result for i in security if i.result})) + "()), but that "
                  "was not carried over automatically. Every viewer of this model currently sees every row. "
                  "Do not assume answers are scoped to the asking user's permissions.", ""]
    lines += ["## Grain and tables", ""]
    for t in plan.tables.values():
        if t.is_parameter:
            continue
        rows = f", {len(plan.frames[t.name]):,} rows" if t.name in plan.frames else ""
        role = "fact table" if t.name in facts else ("lookup table" if t.name in lookups else "table")
        lines.append(f"- '{t.name}': {role}{rows}. {t.source_note}".rstrip())
    for r in plan.relationships:
        lines.append(f"- '{r.from_table}'[{r.from_col}] relates to '{r.to_table}'[{r.to_col}]"
                     + (" (many-to-many)." if r.many_to_many else "."))

    lines += ["", "## Business terminology and defaults", ""]
    params = [t.name for t in plan.tables.values() if t.is_parameter]
    if params:
        lines.append("- Parameter tables (" + ", ".join(f"'{p}'" for p in params) + ") are slicer controls, "
                     "not dimensions or calendars. Never group or filter data by them.")
    extract_tables = [t.name for t in plan.tables.values() if "from Tableau extract" in (t.source_note or "")]
    for name in extract_tables:
        latest = _latest_date(plan, name)
        if latest:
            lines.append(f"- '{name}' is a snapshot. \"Latest\" or \"current\" means the latest date in the data, "
                         f"not today's date. Latest values: {latest}.")
    if not params and not extract_tables:
        lines.append("- No special conventions were detected.")

    lines += ["", "## Measure naming", "",
              "- \"Total X\" is the sum of X; \"Average X\" the mean; \"Count of X\" counts non-blank values; "
              "\"Distinct Count of X\" counts distinct values; \"Min X\"/\"Max X\" as named.",
              "- Measures ending in \"Value\" return the value currently selected in a parameter slicer.",
              "- \"Is <name>\" measures return 1 for members of a Tableau set; use them as filters, not numbers."]

    headline = _headline(plan)
    if headline:
        lines += ["", "## Verified headline numbers (source data at conversion time)", ""]
        lines += [f"- {n} = {v}" for n, v in headline]

    avoid = []
    placeholders = [m.name for t in plan.tables.values() for m in t.measures if m.status == "placeholder"]
    if placeholders:
        avoid.append("- These measures are placeholders that return blank; never use them in answers: "
                     + ", ".join(f"[{p}]" for p in placeholders[:15]) + ".")
    if frozen:
        avoid.append("- These columns use parameter defaults fixed at refresh and ignore slicers: "
                     + ", ".join(f"'{t}'[{c}]" for t, c in sorted(frozen)[:15]) + ".")
    keys = [f"'{t.name}'[{c.name}]" for t in plan.tables.values() for c in t.columns.values()
            if c.hidden and c.name.startswith("Key ")]
    if keys:
        avoid.append("- Hidden key columns (" + ", ".join(keys[:10]) + ") exist only for relationships.")
    if avoid:
        lines += ["", "## Things to avoid", ""] + avoid
    return "\n".join(lines) + "\n"


def _latest_date(plan, table):
    """'Order Date' 2016-12-30, 'Ship Date' 2017-01-05 (data columns only, not calculated ones)."""
    df = plan.frames.get(table)
    if df is None or profiler.pd is None:
        return ""
    out = []
    for c in plan.tables[table].columns.values():
        if c.dtype == "dateTime" and not c.expression and c.name in df.columns:
            v = profiler.pd.to_datetime(df[c.name], errors="coerce").max()
            if v is not None and not profiler.pd.isna(v):
                out.append(f"'{c.name}' {v.strftime('%Y-%m-%d')}")
    return ", ".join(out)


def _headline(plan, limit=8):
    out = []
    for t in plan.tables.values():
        df = plan.frames.get(t.name)
        if df is None:
            continue
        for m in t.measures:
            if not m.recon or m.recon[0] != "Sum" or m.recon[1] != t.name:
                continue
            col = m.recon[2]
            if col not in df.columns:
                continue
            try:
                total = profiler.pd.to_numeric(df[col], errors="coerce").sum()
            except Exception:
                continue
            out.append((f"[{m.name}] over all data", _fmt_num(total)))
            if len(out) >= limit:
                return out
    return out


def report_section(plan):
    s = getattr(plan, "readiness", None)
    if not s:
        return []
    frac = lambda k: f"{s[k][0]} of {s[k][1]}"
    lines = ["## AI readiness (Copilot and Q&A)", "",
             "| Check | Result |", "| --- | --- |",
             f"| Tables with descriptions | {frac('tables')} |",
             f"| Columns with descriptions | {frac('columns')} |",
             f"| Measures with descriptions | {frac('measures')} |",
             f"| Text columns with their values listed | {frac('enumerated')} "
             "(others have more than 20 values, or the data wasn't read) |",
             "| Q&A enabled (qnaEnabled) | Yes |",
             "| AI instructions | Written to the model; edit `ai-instructions.md` and re-convert to change them |",
             "", "Still to do after publishing (these aren't stored in project files):", ""]
    lines += [f"- {d}" for d in DEFERRED]
    lines += ["", "Descriptions are generated from the Tableau metadata; replace them with business wording "
                  "where it matters. Check that Copilot's answers improve before relying on it.", ""]
    return lines

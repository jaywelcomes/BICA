"""AI stages beyond formula translation.

1. make_interactive  - measures that depend on calculated columns frozen at
   refresh (because the Tableau calc used a parameter) are rewritten so they
   react to slicers.
2. improve_visuals   - sheets the rules could only approximate get an AI
   proposal for visual type and field roles.
3. review            - a prioritised fix list for the migration report.

Every AI answer is validated against the model before it is applied; a
rejected answer leaves the rule-based result in place.
"""
from __future__ import annotations

import json
import re
from collections import OrderedDict

from .ai_translator import COL_RE, MEASURE_RE, AIResult, validate_dax
from .llm import BudgetExceeded

STAGES = ("formulas", "interactivity", "visuals", "review")

# ----------------------------------------------------------------------------- helpers
def _col_refs(dax):
    text = re.sub(r'"(?:[^"]|"")*"', '""', dax or "")
    return {((m.group(1) or m.group(2)).replace("''", "'"), m.group(3).replace("]]", "]"))
            for m in COL_RE.finditer(text)}


def _measure_refs(dax):
    text = re.sub(r'"(?:[^"]|"")*"', '""', dax or "")
    return {m.group(1).replace("]]", "]") for m in MEASURE_RE.finditer(COL_RE.sub("", text))}


def _slicer_measures(plan):
    """Parameter measures backed by a slicer table."""
    return {r.name for (d, _), r in plan.field_map.items()
            if r.kind == "param" and r.table and plan.tables.get(r.table) and plan.tables[r.table].is_parameter}


def _uses_slicer(plan, measure, slicers, seen=None):
    seen = seen or set()
    if measure in slicers:
        return True
    if measure in seen or measure not in plan.measure_by_name:
        return False
    seen.add(measure)
    return any(_uses_slicer(plan, m, slicers, seen) for m in _measure_refs(plan.measure_by_name[measure].expression))


def static_columns(plan):
    """Calculated columns whose value depends on a slicer-driven parameter (frozen at refresh)."""
    slicers = _slicer_measures(plan)
    calc_cols = {(t.name, c.name): c for t in plan.tables.values() for c in t.columns.values() if c.expression}
    frozen = {k for k, c in calc_cols.items()
              if any(_uses_slicer(plan, m, slicers) for m in _measure_refs(c.expression))}
    changed = True
    while changed:
        changed = False
        for k, c in calc_cols.items():
            if k not in frozen and _col_refs(c.expression) & frozen:
                frozen.add(k)
                changed = True
    return {k: calc_cols[k] for k in frozen}


# ----------------------------------------------------------------------------- 1. interactivity
INTERACTIVE_PROMPT = """You are refactoring a Power BI semantic model converted from Tableau.

Some Tableau row-level calculations used parameters. In Power BI they became calculated
columns, which are computed once at refresh and ignore slicers. Rewrite the given measure so it
gives the same result WITHOUT referencing any of those frozen columns: inline their logic inside
the measure (iterators, CALCULATE with filter predicates, variables), reading parameters through
their measures so slicers work.

Rules:
- Use only objects in the catalog. Reference columns as 'Table'[Column], measures as [Measure].
- Do not reference any column listed under "frozen columns".
- Read parameter measures into VAR variables before CALCULATE/iterators; a measure inside a CALCULATE
  boolean filter ('T'[Col] >= [Start]) fails at query time.
- Comparison-period logic (current vs prior period flags) becomes
  VAR _start = ... VAR _end = ... RETURN CALCULATE ( <aggregation>, KEEPFILTERS ( 'T'[Date] >= _start && 'T'[Date] <= _end ) ).
- If you inline CALCULATE ( ..., FILTER ( <fact>, ... ) ) inside an iterator, wrap it in one more CALCULATE.
- Keep the measure's meaning (same aggregation, same blank handling).
- Name columns you create inside table expressions with an @ prefix.

Answer with ONLY a JSON object:
{"dax": "<expression only>", "confidence": "high|medium|low", "notes": "<assumptions>"}"""


def make_interactive(mapper, log):
    plan, ai = mapper.plan, mapper.ai
    frozen = static_columns(plan)
    if not frozen:
        return 0
    frozen_desc = "\n".join(f"- '{t}'[{c}] = {col.expression}" for (t, c), col in frozen.items())
    targets = [(t, m) for t in plan.tables.values() for m in t.measures
               if _col_refs(m.expression) & set(frozen)]
    done = 0
    for table, m in targets:
        catalog = mapper.catalog()
        prompt = (f"Catalog:\n{json.dumps(catalog, indent=1)}\n\nFrozen columns (do not reference):\n{frozen_desc}\n\n"
                  f"Measure to rewrite: [{m.name}] in table '{table.name}'\nCurrent DAX:\n{m.expression}\n\n"
                  f"Original Tableau definition: {m.description}\n")
        problem = ""
        for attempt in range(2):
            text = prompt if not attempt else prompt + f"\nPrevious answer rejected: {problem}. Fix it.\n"
            try:
                obj = ai.client.complete_json(INTERACTIVE_PROMPT, text)
            except BudgetExceeded as e:
                log(f"    {e}")
                return done
            except Exception as e:
                problem = str(e)
                break
            dax = (obj.get("dax") or "").strip()
            problem = validate_dax(AIResult("measure", dax, "", "number", "", ""), catalog)
            if not problem and _col_refs(dax) & set(frozen):
                problem = "still references a frozen column: " + ", ".join(
                    f"'{t}'[{c}]" for t, c in sorted(_col_refs(dax) & set(frozen)))
            if not problem:
                old = m.expression
                m.expression, m.status = dax, "ai"
                m.description = (m.description + f" | Interactive AI rewrite ({obj.get('confidence', 'low')}): "
                                 f"{obj.get('notes', '')}").strip()
                plan.log("Interactivity", m.name, "ai",
                         f"AI ({obj.get('confidence', 'low')} confidence) rewrote the measure so it reacts to "
                         f"slicers. {obj.get('notes', '')}", source=old, result=dax)
                done += 1
                break
        if problem:
            plan.log("Interactivity", m.name, "note",
                     f"Uses columns frozen at refresh (parameter defaults); AI rewrite not applied: {problem}")
    uses = set()
    for spec in plan.specs.values():
        cols = {(p.table, p.name) for p in spec.all_projections() if p.kind == "column"}
        cols |= {(p.table, p.name) for p, _, _ in spec.filters}
        hit = cols & set(frozen)
        if hit:
            uses.add(spec.sheet)
            spec.notes.append("Axis/filter uses a column frozen at parameter defaults: "
                              + ", ".join(c for _, c in sorted(hit)))
    if uses:
        plan.log("Interactivity", f"{len(uses)} visual(s)", "note",
                 "Axes or filters use parameter-driven columns, which stay at their defaults. "
                 "Use a measure-based visual filter or field parameters if they must follow slicers.",
                 result=", ".join(sorted(uses)))
    return done


# ----------------------------------------------------------------------------- 2. visuals
ALLOWED_VISUALS = {
    "clusteredBarChart": {"Category", "Y", "Series", "Tooltips"},
    "clusteredColumnChart": {"Category", "Y", "Series", "Tooltips"},
    "stackedBarChart": {"Category", "Y", "Series", "Tooltips"},
    "stackedColumnChart": {"Category", "Y", "Series", "Tooltips"},
    "lineChart": {"Category", "Y", "Series", "Tooltips"},
    "areaChart": {"Category", "Y", "Series", "Tooltips"},
    "pieChart": {"Category", "Y"},
    "donutChart": {"Category", "Y"},
    "scatterChart": {"Category", "X", "Y", "Size"},
    "tableEx": {"Values"},
    "pivotTable": {"Rows", "Columns", "Values"},
    "card": {"Values"},
    "map": {"Category", "Size", "Series"},
}
MEASURE_ROLES = {"Y", "X", "Size", "Tooltips"}
COLUMN_ROLES = {"Category", "Series", "Rows", "Columns"}
FALLBACK_MARKERS = ("converted to a table", "shown as a bar/column chart", "without a measure axis",
                    "Nothing to show", "no measures selected", "simplified to one visual")

VISUAL_PROMPT = """You map a Tableau worksheet to one Power BI visual.

Pick the visual that best reproduces the worksheet's intent, from the allowed list, and assign
model fields to its roles. Use only fields from the catalog (kind "column" or "measure").
Value roles (Y, X, Size, Tooltips) take measures; Category, Series, Rows, Columns take columns;
Values (table, card) and pivot Values take measures (tables may also take columns).

Answer with ONLY a JSON object:
{"vtype": "<visual type>", "roles": {"<Role>": [{"kind": "column|measure", "table": "<table>", "name": "<field>"}]},
 "confidence": "high|medium|low", "notes": "<what differs from Tableau>"}"""


def _describe_sheet(mapper, ws):
    def name(u):
        if u.generated:
            return u.column
        ref = mapper.use_ref(u)
        label = f"{ref.table}[{ref.name}] ({ref.kind})" if ref else f"{u.column} (unavailable)"
        return f"{label}, aggregation {u.derivation}"
    return {
        "worksheet": ws.name, "title": ws.title, "mark": ws.mark,
        "rows": [name(u) for u in ws.rows], "columns": [name(u) for u in ws.cols],
        "marks_card": [f"{k}: {name(u)}" for k, u in ws.encodings],
        "measure_values": [name(u) for u in ws.measure_values],
    }


def _validate_visual(obj, plan):
    vtype = obj.get("vtype")
    if vtype not in ALLOWED_VISUALS:
        return None, f"visual type '{vtype}' not allowed"
    roles = OrderedDict()
    from .mapper import Projection
    for role, items in (obj.get("roles") or {}).items():
        if role not in ALLOWED_VISUALS[vtype]:
            return None, f"role '{role}' not valid for {vtype}"
        projs = []
        for it in items or []:
            kind, table, name = it.get("kind"), it.get("table"), it.get("name")
            t = plan.tables.get(table)
            if t is None:
                return None, f"unknown table '{table}'"
            if kind == "column" and name not in t.columns:
                return None, f"unknown column '{table}'[{name}]"
            if kind == "measure" and name not in {m.name for m in t.measures}:
                return None, f"unknown measure [{name}] in '{table}'"
            if kind not in ("column", "measure"):
                return None, f"bad kind '{kind}'"
            if role in MEASURE_ROLES and kind != "measure":
                return None, f"role {role} needs measures"
            if role in COLUMN_ROLES and kind != "column":
                return None, f"role {role} needs columns"
            projs.append(Projection(kind, table, name, not projs))
        if projs:
            roles[role] = projs
    if not roles:
        return None, "no fields assigned"
    return (vtype, roles), ""


def improve_visuals(mapper, log):
    plan, ai = mapper.plan, mapper.ai
    done = 0
    for ws in mapper.wb.worksheets.values():
        spec = plan.specs.get(ws.name)
        if not spec or not any(mk in n for n in spec.notes for mk in FALLBACK_MARKERS):
            continue
        fields = {t.name: {"columns": list(t.columns), "measures": [m.name for m in t.measures]}
                  for t in plan.tables.values()}
        current = {"vtype": spec.vtype, "roles": {r: [f"{p.table}[{p.name}]" for p in ps] for r, ps in spec.roles.items()},
                   "rule_notes": spec.notes}
        prompt = (f"Allowed visuals and roles: {json.dumps({k: sorted(v) for k, v in ALLOWED_VISUALS.items()})}\n\n"
                  f"Catalog: {json.dumps(fields)}\n\nWorksheet: {json.dumps(_describe_sheet(mapper, ws))}\n\n"
                  f"Rule-based result (approximate): {json.dumps(current)}\n")
        try:
            obj = ai.client.complete_json(VISUAL_PROMPT, prompt)
        except BudgetExceeded as e:
            log(f"    {e}")
            return done
        except Exception as e:
            plan.log("Visual", ws.name, "note", f"AI visual suggestion failed: {e}")
            continue
        result, problem = _validate_visual(obj, plan)
        if problem:
            plan.log("Visual", ws.name, "note", f"AI visual suggestion rejected: {problem}")
            continue
        before = spec.vtype
        spec.vtype, spec.roles = result
        spec.objects = {}
        spec.notes = [n for n in spec.notes if not any(mk in n for mk in FALLBACK_MARKERS)]
        spec.notes.append(f"AI ({obj.get('confidence', 'low')}) chose {spec.vtype}. {obj.get('notes', '')}".strip())
        plan.log("Visual", ws.name, "ai", spec.notes[-1], source=f"rules: {before}", result=spec.vtype)
        done += 1
    return done


# ----------------------------------------------------------------------------- 3. review
REVIEW_PROMPT = """You are a senior Power BI architect reviewing an automated Tableau-to-Power BI migration.
Write a short, prioritised action plan in Markdown for the developer who will finish it:
- start with one sentence on overall readiness;
- then a numbered list (at most 10) of the most important fixes, each with the object name,
  why it matters and the concrete Power BI step or DAX pattern to use;
- end with what to verify after refresh.
Use only the facts provided; don't invent objects. No headings."""


def review(plan, wb, validation, ai, log):
    items = [f"{i.area} | {i.name} | {i.status} | {i.detail[:300]}" for i in plan.items
             if i.status in ("ai", "placeholder", "note", "skipped")][:150]
    facts = {
        "workbook": wb.name,
        "tables": {t.name: {"columns": len(t.columns), "measures": len(t.measures), "source": t.source_note}
                   for t in plan.tables.values()},
        "pages": [f"{p.display}: {len(p.visuals)} visuals" for p in plan.pages],
        "schema_problems": validation["problems"][:20],
    }
    prompt = f"Facts: {json.dumps(facts)}\n\nItems needing attention (area | name | status | detail):\n" + "\n".join(items)
    try:
        text = ai.client.complete(REVIEW_PROMPT, prompt).strip()
    except Exception as e:
        log(f"    AI review skipped: {e}")
        return ""
    return text[:6000]

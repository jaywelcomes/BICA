"""LLM fallback for Tableau formulas the rules can't translate.

Uses the Claude Messages API over plain HTTPS (no SDK dependency). The model
gets the real list of tables, columns, measures and parameters and must answer
with JSON. Every answer is checked: unknown table/column/measure references or
unbalanced brackets cause a rejection, so the caller falls back to a
placeholder for manual review.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass

from .llm import DEFAULT_MODEL  # noqa: F401  (re-exported)

SYSTEM_PROMPT = """You convert Tableau calculated fields into DAX for a Power BI semantic model.

Rules:
- Use ONLY the tables, columns, measures and parameter measures listed in the catalog. Never invent names.
- Reference columns as 'Table'[Column] and measures as [Measure].
- Decide the object kind:
  * "measure" for aggregate logic (SUM, AVG, COUNTD, LOD expressions, table calculations, ratios of aggregates).
  * "column" for row-level logic evaluated per row of one table (give that table in "table").
- LOD expressions: FIXED -> CALCULATE with REMOVEFILTERS/ALLEXCEPT or an iterator over SUMMARIZE/VALUES;
  INCLUDE/EXCLUDE -> iterator or CALCULATE patterns that reproduce the level of detail.
- Table calculations: pick the most likely addressing (usually along the visual's date or category axis),
  use WINDOW/OFFSET/INDEX or CALCULATE + date/ALLSELECTED patterns, and explain the assumption in "notes".
- Use DIVIDE for division. Use BLANK() for NULL. Prefer VAR/RETURN for readability.
- Never put a measure inside a CALCULATE/CALCULATETABLE boolean filter ('T'[Col] = [Measure] fails at
  query time). Read the measure into a VAR first and compare the column to the VAR.
- Inside SUMX/AVERAGEX/MAXX/MINX/RANKX, an inline CALCULATE ( ..., FILTER ( <fact table>, ... ) ) needs
  one extra CALCULATE around it, otherwise the filter is evaluated in the outer context and the result
  is silently wrong. A plain CALCULATE ( SUM ( ... ) ) needs no extra wrap.
- In DAX a BLANK compares as 0, but a Tableau NULL fails every comparison. Where 0 would satisfy a
  comparison (x < 100, x >= 0, x = 0), guard it: NOT ISBLANK ( x ) && x < 100.
- Name any column you create inside a table expression with an @ prefix, e.g. "@Total".
- If a faithful translation is impossible, return kind "unsupported" with the reason in "notes".

Answer with ONLY a JSON object, no prose and no code fences:
{"kind": "measure" | "column" | "unsupported", "table": "<table for columns, else empty>",
 "dax": "<expression only, without the 'Name =' prefix>", "datatype": "string|number|bool|date",
 "confidence": "high|medium|low", "notes": "<assumptions a reviewer should check>"}"""


@dataclass
class AIResult:
    kind: str
    dax: str
    table: str
    datatype: str
    confidence: str
    notes: str


class AITranslator:
    """Formula translation stage. Also owns the shared LLM client used by the other AI stages."""

    def __init__(self, api_key: str | None = None, model: str | None = None, client=None,
                 examples_file: str = "", **client_kwargs):
        from .llm import LLMClient
        self.client = client or LLMClient(api_key=api_key, model=model, **client_kwargs)
        self.examples = load_examples(examples_file)

    @property
    def available(self) -> bool:
        return self.client.available

    @property
    def model(self) -> str:
        return self.client.model

    @property
    def calls(self) -> int:
        return self.client.calls

    def _call(self, user_text: str) -> str:
        return self.client.complete(self.system_prompt(), user_text)

    def system_prompt(self) -> str:
        if not self.examples:
            return SYSTEM_PROMPT
        shots = "\n\n".join(f"Tableau: {e['tableau']}\nDAX ({e['kind']}): {e['dax']}"
                             + (f"\nWhy: {e['notes']}" if e.get("notes") else "") for e in self.examples)
        return SYSTEM_PROMPT + "\n\nApproved example translations (patterns, not the same model):\n\n" + shots

    # ------------------------------------------------------------------ public
    def translate(self, caption: str, formula: str, catalog: dict, reason: str,
                  sheet_context: str = "") -> tuple[AIResult | None, str]:
        """Return (result, rejection_reason). One self-correcting retry on a failed check."""
        prompt = (
            f"Catalog (the only objects you may reference):\n{json.dumps(catalog, indent=1)}\n\n"
            f"Tableau calculated field name: {caption}\n"
            f"Tableau formula:\n{formula}\n\n"
            f"The rule engine could not convert it because: {reason}\n"
        )
        if sheet_context:
            prompt += f"\nHow the field is used on worksheets: {sheet_context}\n"
        problem = ""
        for attempt in range(2):
            text = prompt if attempt == 0 else (
                prompt + f"\nYour previous answer was rejected by the validator: {problem}\n"
                         "Fix it and answer again with JSON only.\n")
            try:
                raw = self._call(text)
            except Exception as e:  # network, auth, rate limit, budget
                return None, f"AI call failed: {e}"
            try:
                from .llm import parse_json
                obj = parse_json(raw)
            except ValueError:
                problem = "answer was not valid JSON"
                continue
            res = AIResult(kind=obj.get("kind", ""), dax=(obj.get("dax") or "").strip(),
                           table=obj.get("table", "") or "", datatype=obj.get("datatype", "") or "",
                           confidence=obj.get("confidence", "low"), notes=obj.get("notes", "") or "")
            if res.kind == "unsupported":
                return None, f"AI: {res.notes or 'not translatable'}"
            problem = validate_dax(res, catalog)
            if not problem:
                if attempt:
                    res.notes = (res.notes + " (corrected after validator feedback)").strip()
                return res, ""
        return None, f"AI answer rejected: {problem}"


def load_examples(extra_file: str = ""):
    """Bundled Tableau->DAX pattern library plus an optional user file of approved pairs."""
    from importlib import resources
    out = []
    try:
        ref = resources.files("tableau2pbip").joinpath("resources/ai/dax_examples.json")
        out = json.loads(ref.read_text(encoding="utf-8"))
    except Exception:
        pass
    if extra_file:
        with open(extra_file, encoding="utf-8") as f:
            out += json.load(f)
    return out


# ---------------------------------------------------------------------- guardrails
COL_RE = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_]*))\[((?:[^\]]|\]\])+)\]")
MEASURE_RE = re.compile(r"(?<![\w'\]])\[((?:[^\]]|\]\])+)\]")


def validate_dax(res: AIResult, catalog: dict) -> str:
    if res.kind not in ("measure", "column"):
        return f"unknown kind '{res.kind}'"
    if not res.dax:
        return "empty expression"
    if res.kind == "column" and res.table not in catalog["tables"]:
        return f"unknown home table '{res.table}'"
    text = re.sub(r'"(?:[^"]|"")*"', '""', res.dax)  # ignore string literals
    for ch_open, ch_close in ("()", "{}"):
        if text.count(ch_open) != text.count(ch_close):
            return "unbalanced brackets"
    tables = catalog["tables"]
    for m in COL_RE.finditer(text):
        t = (m.group(1) or m.group(2)).replace("''", "'")
        c = m.group(3).replace("]]", "]")
        if t not in tables:
            # VAR names and function-style tokens can't precede '[' in valid DAX, so this is a bad ref
            return f"unknown table '{t}'"
        if c not in tables[t]["columns"] and c not in tables[t].get("measures", []):
            return f"unknown column '{t}'[{c}]"
    from .dax_lint import lint
    issues = lint(res.dax)
    if issues:
        return issues[0]
    stripped = COL_RE.sub("", text)
    known = set(catalog["measures"]) | set(catalog.get("parameter_measures", []))
    for m in MEASURE_RE.finditer(stripped):
        name = m.group(1).replace("]]", "]")
        if name not in known and not name.startswith("@"):
            return f"unknown measure [{name}]"
    return ""

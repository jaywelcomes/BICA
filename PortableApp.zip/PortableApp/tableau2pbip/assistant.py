"""AI Migration Assistant: a conversational Claude chat grounded in one converted project's own
output files — the web UI's "AI Migration Assistant" tab, for use *after* a conversion finishes.

Unlike the four AI stages during conversion (ai_translator.py, ai_stages.py), which produce a
single validated, schema-checked answer, this is open-ended chat: there is nothing to validate a
free-text answer against. So instead of trying to police correctness, this module is careful about
*grounding* — it always gives the model the project's real MIGRATION_REPORT.md, its Copilot
instructions, its reconciliation results and (on demand, keyword-matched) real TMDL/M/PBIR/DAX
excerpts — and the system prompt tells the model to say so when something isn't in that context
rather than guess. It never edits the project; every answer is text for a human to read and act on.

No new network surface: this reuses llm.LLMClient (chat() added there for multi-turn use) — same
transport, retries, disk cache and call budget as every other AI stage.
"""
from __future__ import annotations

import glob
import json
import os
import re

MAX_FILE_CHARS = 9000
MAX_SNIPPET_CHARS = 6000
MAX_SNIPPET_FILES = 6

SYSTEM_PROMPT = """You are the AI Migration Assistant inside Business Intelligence Conversion Agent \
(tableau2pbip), \
answering questions about ONE already-converted project: a Tableau workbook that a deterministic \
rules engine (plus optional AI stages) turned into a Power BI Project (PBIP: a semantic model in \
TMDL and a report in PBIR). You are an expert in Tableau, Power BI, Microsoft Fabric, DAX, Power \
Query M, TMDL, semantic modelling, and Tableau-to-Power-BI migration and modernization.

Ground rules:
- Answer from the CONTEXT below (the project's own migration report, Copilot instructions, \
reconciliation results, and any file excerpts retrieved for this question) — never invent numbers, \
file contents, or conversion outcomes that aren't in it.
- If the context doesn't cover the question, say exactly what's missing and name the specific file \
the user should open (e.g. "check `<Name>.SemanticModel/definition/tables/Orders.tmdl`") rather \
than guessing.
- There is no live connection to Tableau Server/Cloud/Desktop or to a deployed Power BI/Fabric model \
from this tool. Numbers in the reconciliation results were computed from the same profiled source \
data on both "sides" (see the report's own methodology note) — say so if it's relevant, never imply \
a live query was compared.
- When asked to write or fix DAX or Power Query M, use only the tables/columns/measures visible in \
the context; say so if you're inferring a name that isn't confirmed there. Put code in fenced code \
blocks (```dax or ```m).
- Be concrete and specific to THIS project, not a generic Tableau-to-Power-BI explainer. Cite the \
worksheet, measure, table or file name from the context whenever you can.
- Keep answers focused; use short sections/bullets for multi-part questions rather than one long \
paragraph.
- You cannot modify any file — every answer is guidance for a human to apply."""


def _read_capped(path, cap=MAX_FILE_CHARS):
    if not os.path.exists(path):
        return ""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    if len(text) > cap:
        text = text[:cap] + f"\n\n...(truncated; {len(text):,} characters total in this file)"
    return text


def _manifest_summary(folder):
    path = os.path.join(folder, "validation", "run_manifest.json")
    if not os.path.exists(path):
        return ""
    try:
        with open(path, encoding="utf-8") as f:
            m = json.load(f)
    except (OSError, ValueError):
        return ""
    keep = {k: m.get(k) for k in ("tool", "version", "input", "options", "ai", "published_datasources",
                                  "results", "conversion_score", "validation")}
    return json.dumps(keep, indent=1)


def _file_index(folder):
    tables = sorted(os.path.basename(p)[:-5] for p in
                    glob.glob(os.path.join(folder, "*.SemanticModel", "definition", "tables", "*.tmdl")))
    pages = sorted({os.path.basename(os.path.dirname(os.path.dirname(p))) for p in
                   glob.glob(os.path.join(folder, "*.Report", "definition", "pages", "*", "visuals", "*"))})
    lines = []
    if tables:
        lines.append("Semantic model tables: " + ", ".join(tables))
    if pages:
        lines.append("Report pages: " + ", ".join(pages))
    return "\n".join(lines)


def build_context(folder, name):
    """Baseline context sent with every turn of one conversation: stable across the session, so it
    goes in the system prompt rather than being re-fetched per message."""
    parts = [f"# Project: {name}", ""]
    report = _read_capped(os.path.join(folder, "MIGRATION_REPORT.md"))
    if report:
        parts += ["## MIGRATION_REPORT.md", report, ""]
    ai_instr = _read_capped(os.path.join(folder, "ai-instructions.md"), 4000)
    if ai_instr:
        parts += ["## ai-instructions.md (Copilot instructions written into the model)", ai_instr, ""]
    recon_summary = _read_capped(os.path.join(folder, "validation", "reconciliation_summary.json"), MAX_FILE_CHARS)
    if recon_summary:
        parts += ["## Reconciliation_Report.xlsx (structured data behind the Excel workbook)", recon_summary, ""]
    manifest = _manifest_summary(folder)
    if manifest:
        parts += ["## validation/run_manifest.json (trimmed: tool/options/results, not per-file hashes)",
                  manifest, ""]
    index = _file_index(folder)
    if index:
        parts += ["## Files available for a closer look (ask about one by name to see its content)",
                  index, ""]
    return "\n".join(parts)


_STOPWORDS = {"the", "is", "was", "were", "what", "why", "show", "this", "that", "all", "and", "for",
             "with", "from", "into", "does", "did", "how", "are", "can", "could", "would", "should",
             "please", "measure", "measures", "column", "columns", "table", "tables", "dax", "query",
             "queries", "file", "files", "power", "explain", "generate", "recommend", "compare"}


def _tokens(message):
    words = re.findall(r"[A-Za-z0-9_']{3,}", message)
    return sorted({w for w in words if w.lower() not in _STOPWORDS}, key=len, reverse=True)[:12]


def search_snippets(folder, message):
    """Keyword-matched excerpts from the actual TMDL/PBIR/DAX/M files, so specific questions
    ("explain the Region Sales LOD measure", "why was this relationship created") get grounded in
    real file content without stuffing every file into every turn's context."""
    tokens = _tokens(message)
    if not tokens:
        return ""
    patterns = [re.compile(re.escape(t), re.I) for t in tokens]
    candidates = []
    for pattern in ("*.SemanticModel/definition/tables/*.tmdl",
                    "*.SemanticModel/definition/relationships.tmdl",
                    "*.Report/definition/pages/*/visuals/*/visual.json",
                    "validation/queries.dax", "validation/reconciliation.md"):
        candidates += glob.glob(os.path.join(folder, pattern))
    hits = []
    for path in sorted(candidates):
        try:
            with open(path, encoding="utf-8") as f:
                text = f.read()
        except OSError:
            continue
        if not any(p.search(text) for p in patterns):
            continue
        lines = text.splitlines()
        matched = set()
        for i, line in enumerate(lines):
            if any(p.search(line) for p in patterns):
                matched.update(range(max(0, i - 2), min(len(lines), i + 3)))
        if not matched:
            continue
        hits.append((os.path.relpath(path, folder), "\n".join(lines[i] for i in sorted(matched))))
        if len(hits) >= MAX_SNIPPET_FILES:
            break
    if not hits:
        return ""
    out, total = [], 0
    for rel, snippet in hits:
        block = f"### {rel}\n```\n{snippet[:1800]}\n```"
        if total + len(block) > MAX_SNIPPET_CHARS:
            break
        out.append(block)
        total += len(block)
    return ("Excerpts retrieved from the project for this question (not the whole file):\n\n"
            + "\n\n".join(out))


def ask(folder, name, client, history, message):
    """`history`: prior turns as `[{"role": "user"|"assistant", "content": str}, ...]`, oldest
    first, NOT including `message`. Returns the assistant's reply; the caller appends both the
    plain `message` and the reply to its own persisted history (snippets are re-retrieved fresh
    each turn, not stored, so history stays small and readable)."""
    system = SYSTEM_PROMPT + "\n\n" + build_context(folder, name)
    snippets = search_snippets(folder, message)
    turn = (snippets + "\n\nQuestion: " if snippets else "") + message
    return client.chat(system, history + [{"role": "user", "content": turn}])


STARTERS = [
    "Explain my migration.",
    "Show migration risks.",
    "Show unsupported features.",
    "Review DAX measures.",
    "Review Power Query.",
    "Analyze semantic model.",
    "Analyze security.",
    "Analyze data blending.",
    "Analyze validation results.",
    "Recommend next actions.",
]

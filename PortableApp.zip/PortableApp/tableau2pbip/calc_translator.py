"""Rule-based translation of Tableau calculation formulas to DAX.

The formula is tokenised, parsed into a small AST and emitted as DAX. Anything
the rules can't handle safely raises `Unsupported`, which the caller routes to
the AI translator or to a placeholder for manual review.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Optional


class Unsupported(Exception):
    pass


class SecurityFunction(Unsupported):
    """Raised for USERNAME()/FULLNAME()/ISMEMBEROF()/ISFULLNAME()/TABLEAUSERVER(): Tableau has no
    other built-in way to implement row-level security, so a formula using one of these almost
    always *is* part of the workbook's security model. Never routed to the AI formula stage —
    guessing security logic wrong is worse than not translating it — always becomes a
    placeholder plus a loud, dedicated warning in the migration report (mapper.map_calcs,
    reporting.write_report)."""
    def __init__(self, func_name):
        self.func_name = func_name
        super().__init__(f"Uses {func_name}() — likely row-level security; not translated automatically")


SECURITY_FUNCTIONS = {"USERNAME", "FULLNAME", "ISMEMBEROF", "ISFULLNAME", "TABLEAUSERVER"}


# --------------------------------------------------------------------------- resolver contract
@dataclass
class Ref:
    kind: str            # column | rowcalc | measure | param
    name: str            # column / measure name in the model
    table: str = ""      # model table for column / rowcalc
    dtype: str = "unknown"   # string | number | bool | date | unknown
    constant: bool = False   # measure built only from parameters/literals (usable at row level)


@dataclass
class Resolver:
    """Callbacks the translator needs from the model mapper."""
    resolve: Callable[[Optional[str], str], Ref]          # (datasource or None, field name) -> Ref
    related: Callable[[str, str], bool]                   # can rows of A use RELATED() to reach B?


@dataclass
class Translation:
    kind: str            # measure | column
    dax: str
    dtype: str
    table: str = ""      # home table for a column
    notes: list = field(default_factory=list)
    constant: bool = False   # no columns and no aggregation: depends only on parameters/literals


# --------------------------------------------------------------------------- tokenizer
TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<comment>//[^\n]*|/\*.*?\*/)
  | (?P<date>\#[^#]+\#)
  | (?P<num>\d+\.\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?|\d+(?:[eE][-+]?\d+)?)
  | (?P<ident>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op><=|>=|<>|!=|==|[=<>+\-*/%^(),{}:])
""", re.VERBOSE | re.DOTALL)

KEYWORDS = {"IF", "THEN", "ELSEIF", "ELSE", "END", "CASE", "WHEN", "AND", "OR", "NOT",
            "TRUE", "FALSE", "NULL", "IN"}


def tokenize(s: str):
    toks, i, n = [], 0, len(s)
    while i < n:
        ch = s[i]
        if ch == "[":
            name, i = _read_bracket(s, i)
            if s.startswith(".[", i):
                second, i = _read_bracket(s, i + 1)
                toks.append(("field", (name, second)))
            else:
                toks.append(("field", (None, name)))
            continue
        if ch in "'\"":
            val, i = _read_string(s, i)
            toks.append(("str", val))
            continue
        m = TOKEN_RE.match(s, i)
        if not m:
            raise Unsupported(f"Unexpected character {ch!r} at {i}")
        i = m.end()
        kind = m.lastgroup
        text = m.group(kind)
        if kind in ("ws", "comment"):
            continue
        if kind == "ident" and text.upper() in KEYWORDS:
            toks.append(("kw", text.upper()))
        else:
            toks.append((kind, text))
    toks.append(("eof", None))
    return toks


def _read_bracket(s, i):
    j, out = i + 1, []
    while j < len(s):
        if s[j] == "]":
            if s.startswith("]]", j):
                out.append("]")
                j += 2
                continue
            return "".join(out), j + 1
        out.append(s[j])
        j += 1
    raise Unsupported("Unclosed [field] reference")


def _read_string(s, i):
    q, j, out = s[i], i + 1, []
    while j < len(s):
        c = s[j]
        if c == "\\" and j + 1 < len(s):
            out.append(s[j + 1])
            j += 2
            continue
        if c == q:
            if j + 1 < len(s) and s[j + 1] == q:
                out.append(q)
                j += 2
                continue
            return "".join(out), j + 1
        out.append(c)
        j += 1
    raise Unsupported("Unclosed string literal")


# --------------------------------------------------------------------------- parser
class Parser:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self, k=0):
        return self.t[self.i + k]

    def take(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def accept(self, kind, val=None):
        tk = self.peek()
        if tk[0] == kind and (val is None or tk[1] == val):
            self.i += 1
            return tk
        return None

    def expect(self, kind, val=None):
        tk = self.accept(kind, val)
        if not tk:
            raise Unsupported(f"Expected {val or kind}, found {self.peek()[1]!r}")
        return tk

    def parse(self):
        node = self.expr()
        if self.peek()[0] != "eof":
            raise Unsupported(f"Unexpected token {self.peek()[1]!r}")
        return node

    def expr(self):
        return self.or_()

    def or_(self):
        n = self.and_()
        while self.accept("kw", "OR"):
            n = ("bin", "OR", n, self.and_())
        return n

    def and_(self):
        n = self.not_()
        while self.accept("kw", "AND"):
            n = ("bin", "AND", n, self.not_())
        return n

    def not_(self):
        if self.accept("kw", "NOT"):
            return ("un", "NOT", self.not_())
        return self.cmp()

    def cmp(self):
        n = self.add()
        tk = self.peek()
        if tk[0] == "op" and tk[1] in ("=", "==", "<>", "!=", "<", "<=", ">", ">="):
            self.take()
            n = ("bin", tk[1], n, self.add())
        elif tk == ("kw", "IN"):
            self.take()
            self.expect("op", "(")
            items = [self.expr()]
            while self.accept("op", ","):
                items.append(self.expr())
            self.expect("op", ")")
            n = ("in", n, items)
        return n

    def add(self):
        n = self.mul()
        while self.peek()[0] == "op" and self.peek()[1] in "+-":
            op = self.take()[1]
            n = ("bin", op, n, self.mul())
        return n

    def mul(self):
        n = self.unary()
        while self.peek()[0] == "op" and self.peek()[1] in ("*", "/", "%"):
            op = self.take()[1]
            n = ("bin", op, n, self.unary())
        return n

    def unary(self):
        if self.accept("op", "-"):
            return ("un", "-", self.unary())
        if self.accept("op", "+"):
            return self.unary()
        return self.power()

    def power(self):
        n = self.primary()
        if self.accept("op", "^"):
            n = ("bin", "^", n, self.unary())
        return n

    def primary(self):
        kind, val = self.take()
        if kind == "num":
            return ("num", val)
        if kind == "str":
            return ("str", val)
        if kind == "date":
            return ("date", val.strip("#"))
        if kind == "field":
            return ("field", val[0], val[1])
        if kind == "kw":
            if val in ("TRUE", "FALSE"):
                return ("bool", val == "TRUE")
            if val == "NULL":
                return ("null",)
            if val == "IF":
                return self.if_()
            if val == "CASE":
                return self.case_()
        if kind == "op" and val == "(":
            n = self.expr()
            self.expect("op", ")")
            return n
        if kind == "op" and val == "{":
            raise Unsupported("LOD expression ({FIXED/INCLUDE/EXCLUDE})")
        if kind == "ident":
            if self.accept("op", "("):
                args = []
                if not self.accept("op", ")"):
                    args.append(self.expr())
                    while self.accept("op", ","):
                        args.append(self.expr())
                    self.expect("op", ")")
                return ("func", val.upper(), args)
            raise Unsupported(f"Unknown identifier {val}")
        raise Unsupported(f"Unexpected token {val!r}")

    def if_(self):
        branches = [(self.expr(), None)]
        self.expect("kw", "THEN")
        branches[0] = (branches[0][0], self.expr())
        otherwise = None
        while True:
            if self.accept("kw", "ELSEIF"):
                c = self.expr()
                self.expect("kw", "THEN")
                branches.append((c, self.expr()))
            elif self.accept("kw", "ELSE"):
                otherwise = self.expr()
            else:
                break
        self.expect("kw", "END")
        return ("if", branches, otherwise)

    def case_(self):
        subject = self.expr()
        whens, otherwise = [], None
        while self.accept("kw", "WHEN"):
            w = self.expr()
            self.expect("kw", "THEN")
            whens.append((w, self.expr()))
        if self.accept("kw", "ELSE"):
            otherwise = self.expr()
        self.expect("kw", "END")
        return ("case", subject, whens, otherwise)


# --------------------------------------------------------------------------- emitter
AGG_SIMPLE = {"SUM": "SUM", "AVG": "AVERAGE", "MIN": "MIN", "MAX": "MAX", "COUNT": "COUNTA",
              "COUNTD": "DISTINCTCOUNTNOBLANK", "MEDIAN": "MEDIAN", "STDEV": "STDEV.S",
              "STDEVP": "STDEV.P", "VAR": "VAR.S", "VARP": "VAR.P"}
AGG_ITER = {"SUM": "SUMX", "AVG": "AVERAGEX", "MIN": "MINX", "MAX": "MAXX", "COUNT": "COUNTX",
            "MEDIAN": "MEDIANX", "STDEV": "STDEVX.S", "STDEVP": "STDEVX.P", "VAR": "VARX.S",
            "VARP": "VARX.P"}
AGG_FUNCS = set(AGG_SIMPLE) | {"ATTR", "PERCENTILE"}
TABLE_CALCS = {"RUNNING_SUM", "RUNNING_AVG", "RUNNING_COUNT", "RUNNING_MIN", "RUNNING_MAX",
               "WINDOW_SUM", "WINDOW_AVG", "WINDOW_MIN", "WINDOW_MAX", "WINDOW_COUNT",
               "WINDOW_MEDIAN", "WINDOW_STDEV", "WINDOW_VAR", "WINDOW_PERCENTILE", "WINDOW_CORR",
               "INDEX", "RANK", "RANK_DENSE", "RANK_MODIFIED", "RANK_PERCENTILE", "RANK_UNIQUE",
               "LOOKUP", "PREVIOUS_VALUE", "TOTAL", "SIZE", "FIRST", "LAST", "SCRIPT_REAL",
               "SCRIPT_STR", "SCRIPT_INT", "SCRIPT_BOOL", "MODEL_PERCENTILE", "MODEL_QUANTILE"}
DATE_UNITS = {"year": "YEAR", "quarter": "QUARTER", "month": "MONTH", "week": "WEEK",
              "day": "DAY", "hour": "HOUR", "minute": "MINUTE", "second": "SECOND"}


def dax_str(v: str) -> str:
    return '"' + v.replace('"', '""') + '"'


def qtable(t: str) -> str:
    return "'" + t.replace("'", "''") + "'"


def qcol(t: str, c: str) -> str:
    return f"{qtable(t)}[{c.replace(']', ']]')}]"


def qmeasure(m: str) -> str:
    return f"[{m.replace(']', ']]')}]"


class Emitter:
    def __init__(self, resolver: Resolver, mode: str, home: str):
        self.r, self.mode, self.home = resolver, mode, home
        self.notes = []

    # ---- helpers
    def field(self, node, iter_table=None):
        ref = self.r.resolve(node[1], node[2])
        if ref.kind == "param" or (ref.kind == "measure" and ref.constant):
            if self.mode == "column":
                self.notes.append(f"Parameter [{node[2]}] in a calculated column uses its default value "
                                  "(columns don't respond to slicers).")
            return qmeasure(ref.name), ref.dtype
        if ref.kind == "measure":
            if self.mode == "column" or iter_table:
                raise Unsupported(f"Aggregate calc [{node[2]}] used at row level")
            return qmeasure(ref.name), ref.dtype
        # column or row-level calc
        table = iter_table or (self.home if self.mode == "column" else None)
        if table is None:
            raise Unsupported(f"Field [{node[2]}] used without aggregation in an aggregate calc")
        if ref.table == table:
            return qcol(ref.table, ref.name), ref.dtype
        if self.r.related(table, ref.table):
            return f"RELATED ( {qcol(ref.table, ref.name)} )", ref.dtype
        raise Unsupported(f"Field [{node[2]}] is in table {ref.table}, not reachable from {table}")

    def emit(self, n, it=None):
        k = n[0]
        if k == "num":
            return n[1], "number"
        if k == "str":
            return dax_str(n[1]), "string"
        if k == "bool":
            return ("TRUE ()" if n[1] else "FALSE ()"), "bool"
        if k == "null":
            return "BLANK ()", "unknown"
        if k == "date":
            return self.date_literal(n[1]), "date"
        if k == "field":
            return self.field(n, it)
        if k == "un":
            a, t = self.emit(n[2], it)
            if n[1] == "NOT":
                return f"NOT ( {a} )", "bool"
            return (f"-( {a} )" if n[2][0] == "bin" else f"-{a}"), t
        if k == "bin":
            return self.binop(n, it)
        if k == "in":
            a, _ = self.emit(n[1], it)
            items = ", ".join(self.emit(x, it)[0] for x in n[2])
            if any(self._num(x) == 0 for x in n[2]):
                return f"( NOT ISBLANK ( {a} ) && {a} IN {{ {items} }} )", "bool"
            return f"{a} IN {{ {items} }}", "bool"
        if k == "if":
            return self.if_(n, it)
        if k == "case":
            subj, _ = self.emit(n[1], it)
            parts, dtype = [subj], "unknown"
            for w, v in n[2]:
                parts.append(self.emit(w, it)[0])
                val, dtype = self.emit(v, it)
                parts.append(val)
            if n[3] is not None:
                parts.append(self.emit(n[3], it)[0])
            return f"SWITCH ( {', '.join(parts)} )", dtype
        if k == "func":
            return self.func(n[1], n[2], it)
        raise Unsupported(f"Unhandled node {k}")

    @staticmethod
    def date_literal(text):
        m = re.match(r"(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?", text.strip())
        if not m:
            raise Unsupported(f"Date literal #{text}# not understood")
        y, mo, d, hh, mi, ss = m.groups()
        base = f"DATE ( {int(y)}, {int(mo)}, {int(d)} )"
        if hh:
            base += f" + TIME ( {int(hh)}, {int(mi)}, {int(ss or 0)} )"
        return base

    PREC = {"OR": 1, "AND": 2, "=": 3, "==": 3, "<>": 3, "!=": 3, "<": 3, "<=": 3, ">": 3,
            ">=": 3, "+": 4, "-": 4, "*": 5}

    def _wrap(self, child, parent_op, right):
        """Emit a child, adding parentheses only when precedence requires it."""
        text, dtype = self.emit(child[0], child[1])
        node = child[0]
        if node[0] == "bin" and node[1] in self.PREC and parent_op in self.PREC:
            cp, pp = self.PREC[node[1]], self.PREC[parent_op]
            if cp < pp or (right and cp == pp and parent_op == "-"):
                text = f"( {text} )"
        return text, dtype

    def binop(self, n, it):
        op = n[1]
        if op in ("/", "%", "^"):
            a, _ = self.emit(n[2], it)
            b, _ = self.emit(n[3], it)
            fn = {"/": "DIVIDE", "%": "MOD", "^": "POWER"}[op]
            return f"{fn} ( {a}, {b} )", "number"
        a, ta = self._wrap((n[2], it), op, False)
        b, tb = self._wrap((n[3], it), op, True)
        if op == "+":
            if "string" in (ta, tb):
                return f"{a} & {b}", "string"
            return f"{a} + {b}", ("date" if "date" in (ta, tb) else "number")
        if op == "-":
            if ta == tb == "date":   # Tableau: whole days between dates
                return f"INT ( {a} - {b} )", "number"
            return f"{a} - {b}", ("date" if ta == "date" else "number")
        if op == "*":
            return f"{a} * {b}", "number"
        if op == "AND":
            return f"( {a} && {b} )", "bool"
        if op == "OR":
            return f"( {a} || {b} )", "bool"
        dop = {"==": "=", "!=": "<>"}.get(op, op)
        guard = self._blank_guard(n, dop, a, b)
        if guard:
            return f"( NOT ISBLANK ( {guard} ) && {a} {dop} {b} )", "bool"
        return f"{a} {dop} {b}", "bool"

    @staticmethod
    def _num(node):
        if node[0] == "num":
            return float(node[1])
        if node[0] == "un" and node[1] == "-" and node[2][0] == "num":
            return -float(node[2][1])
        return None

    def _blank_guard(self, n, op, a, b):
        """Tableau: NULL fails every comparison. DAX: BLANK compares as 0.
        When 0 would pass the comparison against a numeric literal, guard the other operand
        (see Guust-Franssens/tableau-to-powerbi-migration, translation guide, issue #82)."""
        left, right = self._num(n[2]), self._num(n[3])
        if (left is None) == (right is None):
            return None          # both or neither literal
        checks = {"=": lambda x, y: x == y, "<": lambda x, y: x < y, "<=": lambda x, y: x <= y,
                  ">": lambda x, y: x > y, ">=": lambda x, y: x >= y}
        if op not in checks:
            return None
        passes = checks[op](0.0, right) if right is not None else checks[op](left, 0.0)
        return (a if right is not None else b) if passes else None

    def if_(self, n, it):
        branches, otherwise = n[1], n[2]
        tail = self.emit(otherwise, it)[0] if otherwise is not None else None
        dtype = "unknown"
        out = tail
        for cond, val in reversed(branches):
            c, _ = self.emit(cond, it)
            v, dtype = self.emit(val, it)
            out = f"IF ( {c}, {v}, {out} )" if out is not None else f"IF ( {c}, {v} )"
        return out, dtype

    # ---- functions
    def func(self, name, args, it):
        if name in SECURITY_FUNCTIONS:
            raise SecurityFunction(name)
        if name in TABLE_CALCS:
            raise Unsupported(f"Table calculation {name}()")
        if name in AGG_FUNCS and not (name in ("MIN", "MAX") and len(args) == 2):
            return self.aggregate(name, args, it)
        e = lambda i: self.emit(args[i], it)[0]

        def need(k):
            if len(args) < k:
                raise Unsupported(f"{name}() needs {k} arguments")
        simple = {"ABS": "ABS", "SQRT": "SQRT", "EXP": "EXP", "LN": "LN", "SIGN": "SIGN",
                  "INT": "INT", "LEN": "LEN", "UPPER": "UPPER", "LOWER": "LOWER", "TRIM": "TRIM",
                  "YEAR": "YEAR", "MONTH": "MONTH", "DAY": "DAY", "QUARTER": "QUARTER",
                  "ISNULL": "ISBLANK", "POWER": "POWER", "LEFT": "LEFT", "RIGHT": "RIGHT",
                  "MIN": "MIN", "MAX": "MAX", "REPLACE": "SUBSTITUTE", "DIV": "QUOTIENT",
                  "IFNULL": "COALESCE", "PI": "PI", "SIN": "SIN", "COS": "COS", "TAN": "TAN"}
        dtypes = {"LEN": "number", "UPPER": "string", "LOWER": "string", "TRIM": "string",
                  "LEFT": "string", "RIGHT": "string", "REPLACE": "string", "ISNULL": "bool"}
        if name in simple:
            return f"{simple[name]} ( {', '.join(e(i) for i in range(len(args)))} )", dtypes.get(name, "number")
        if name == "ZN":
            need(1)
            return f"COALESCE ( {e(0)}, 0 )", "number"
        if name == "IIF":
            need(3)
            return f"IF ( {e(0)}, {e(1)}, {e(2)} )", self.emit(args[1], it)[1]
        if name == "ROUND":
            need(1)
            return f"ROUND ( {e(0)}, {e(1) if len(args) > 1 else 0} )", "number"
        if name in ("CEILING", "FLOOR"):
            need(1)
            return f"{name} ( {e(0)}, 1 )", "number"
        if name == "LOG":
            need(1)
            return f"LOG ( {e(0)}, {e(1) if len(args) > 1 else 10} )", "number"
        if name == "FLOAT":
            return f"CONVERT ( {e(0)}, DOUBLE )", "number"
        if name == "STR":
            return f"CONVERT ( {e(0)}, STRING )", "string"
        if name == "MID":
            need(2)
            ln = e(2) if len(args) > 2 else f"LEN ( {e(0)} )"
            return f"MID ( {e(0)}, {e(1)}, {ln} )", "string"
        if name == "CONTAINS":
            need(2)
            return f"CONTAINSSTRING ( {e(0)}, {e(1)} )", "bool"
        if name == "STARTSWITH":
            need(2)
            return f"( LEFT ( {e(0)}, LEN ( {e(1)} ) ) = {e(1)} )", "bool"
        if name == "ENDSWITH":
            need(2)
            return f"( RIGHT ( {e(0)}, LEN ( {e(1)} ) ) = {e(1)} )", "bool"
        if name == "FIND":
            need(2)
            return f"FIND ( {e(1)}, {e(0)}, 1, 0 )", "number"
        if name in ("TODAY", "NOW"):
            return f"{name} ()", "date"
        if name == "MAKEDATE":
            need(3)
            return f"DATE ( {e(0)}, {e(1)}, {e(2)} )", "date"
        if name == "DATE":
            need(1)
            a, t = self.emit(args[0], it)
            return (f"DATEVALUE ( {a} )" if t == "string" else f"CONVERT ( INT ( {a} ), DATETIME )"), "date"
        if name in ("DATEDIFF", "DATEPART", "DATENAME", "DATETRUNC", "DATEADD"):
            return self.date_func(name, args, it)
        raise Unsupported(f"Function {name}() has no rule")

    def unit(self, node):
        if node[0] != "str" or node[1].lower() not in DATE_UNITS:
            raise Unsupported("Date part must be a literal unit")
        return node[1].lower()

    def date_func(self, name, args, it):
        e = lambda i: self.emit(args[i], it)[0]
        u = self.unit(args[0])
        if name == "DATEDIFF":
            if len(args) > 3:
                raise Unsupported("DATEDIFF with start-of-week argument")
            return f"DATEDIFF ( {e(1)}, {e(2)}, {DATE_UNITS[u]} )", "number"
        d = e(1) if name != "DATEADD" else e(2)
        if name == "DATEPART":
            fn = {"year": "YEAR", "quarter": "QUARTER", "month": "MONTH", "day": "DAY",
                  "week": "WEEKNUM", "hour": "HOUR", "minute": "MINUTE", "second": "SECOND"}[u]
            return f"{fn} ( {d} )", "number"
        if name == "DATENAME":
            fmt = {"year": "yyyy", "quarter": "\\Qq", "month": "MMMM", "day": "d", "week": "ww"}.get(u)
            if not fmt:
                raise Unsupported(f"DATENAME('{u}')")
            return f"FORMAT ( {d}, {dax_str(fmt)} )", "string"
        if name == "DATETRUNC":
            m = {"year": f"DATE ( YEAR ( {d} ), 1, 1 )",
                 "quarter": f"DATE ( YEAR ( {d} ), ( QUARTER ( {d} ) - 1 ) * 3 + 1, 1 )",
                 "month": f"DATE ( YEAR ( {d} ), MONTH ( {d} ), 1 )",
                 "week": f"{d} - WEEKDAY ( {d}, 1 ) + 1",
                 "day": f"DATE ( YEAR ( {d} ), MONTH ( {d} ), DAY ( {d} ) )"}.get(u)
            if not m:
                raise Unsupported(f"DATETRUNC('{u}')")
            return m, "date"
        n = e(1)
        m = {"day": f"{d} + {n}", "week": f"{d} + 7 * {n}", "month": f"EDATE ( {d}, {n} )",
             "quarter": f"EDATE ( {d}, 3 * {n} )", "year": f"EDATE ( {d}, 12 * {n} )"}.get(u)
        if not m:
            raise Unsupported(f"DATEADD('{u}')")
        return m, "date"

    def aggregate(self, name, args, it):
        if it is not None:
            raise Unsupported(f"Nested aggregation {name}() inside an aggregation")
        if self.mode == "column":
            raise Unsupported(f"Aggregation {name}() in a row-level calc")
        if not args:
            raise Unsupported(f"{name}() without arguments")
        arg = args[0]
        if arg[0] == "field":
            ref = self.r.resolve(arg[1], arg[2])
            if ref.kind in ("column", "rowcalc"):
                col = qcol(ref.table, ref.name)
                if name == "ATTR":
                    return f"IF ( HASONEVALUE ( {col} ), VALUES ( {col} ) )", ref.dtype
                if name == "PERCENTILE":
                    return f"PERCENTILE.INC ( {col}, {self.emit(args[1])[0]} )", "number"
                dtype = ref.dtype if name in ("MIN", "MAX", "ATTR") else "number"
                return f"{AGG_SIMPLE[name]} ( {col} )", dtype
            raise Unsupported(f"{name}() over a non-column field [{arg[2]}]")
        tables = self.tables_in(arg)
        if not tables:
            raise Unsupported(f"{name}() over an expression without fields")
        home = self.pick_home(tables)
        inner, dtype = self.emit(arg, home)
        if name == "COUNTD":
            return (f"COUNTROWS ( FILTER ( DISTINCT ( SELECTCOLUMNS ( {qtable(home)}, \"@v\", {inner} ) ), "
                    f"NOT ISBLANK ( [@v] ) ) )", "number")
        if name not in AGG_ITER:
            raise Unsupported(f"{name}() over an expression")
        return f"{AGG_ITER[name]} ( {qtable(home)}, {inner} )", ("number" if name not in ("MIN", "MAX") else dtype)

    def tables_in(self, n, acc=None):
        acc = [] if acc is None else acc
        if isinstance(n, tuple) and n and isinstance(n[0], str):
            if n[0] == "field":
                ref = self.r.resolve(n[1], n[2])
                if ref.kind in ("column", "rowcalc") and ref.table not in acc:
                    acc.append(ref.table)
            else:
                for x in n[1:]:
                    self.tables_in(x, acc)
        elif isinstance(n, (list, tuple)):
            for x in n:
                self.tables_in(x, acc)
        return acc

    def pick_home(self, tables):
        for t in tables:
            if all(o == t or self.r.related(t, o) for o in tables):
                return t
        raise Unsupported(f"Fields from unrelated tables {tables} in one row expression")


# --------------------------------------------------------------------------- classification
def _walk(n, fn, in_agg=False):
    if isinstance(n, tuple) and n and isinstance(n[0], str):
        fn(n, in_agg)
        inner = in_agg or (n[0] == "func" and n[1] in AGG_FUNCS
                           and not (n[1] in ("MIN", "MAX") and len(n[2]) == 2))
        for x in n[1:]:
            _walk(x, fn, inner)
    elif isinstance(n, (list, tuple)):
        for x in n:
            _walk(x, fn, in_agg)


def translate(formula: str, resolver: Resolver) -> Translation:
    if not formula or not formula.strip():
        raise Unsupported("Empty formula")
    if re.search(r"\{\s*(FIXED|INCLUDE|EXCLUDE)\b", formula, re.I):
        raise Unsupported("LOD expression ({FIXED/INCLUDE/EXCLUDE})")
    ast = Parser(tokenize(formula)).parse()

    state = {"agg": False, "row_outside": False, "tables": []}

    def visit(n, in_agg):
        if n[0] == "func":
            if n[1] in TABLE_CALCS:
                raise Unsupported(f"Table calculation {n[1]}()")
            if n[1] in AGG_FUNCS and not (n[1] in ("MIN", "MAX") and len(n[2]) == 2):
                state["agg"] = True
        if n[0] == "field":
            ref = resolver.resolve(n[1], n[2])
            if ref.kind == "measure" and not ref.constant:
                state["agg"] = True
            elif ref.kind == "measure":
                state["const_refs"] = True
            elif ref.kind in ("column", "rowcalc"):
                if not in_agg:
                    state["row_outside"] = True
                    if ref.table not in state["tables"]:
                        state["tables"].append(ref.table)

    _walk(ast, visit)
    if state["agg"] and state["row_outside"]:
        raise Unsupported("Mixes aggregate and non-aggregate fields")
    if state["agg"] or not state["row_outside"]:
        em = Emitter(resolver, "measure", "")
        dax, dtype = em.emit(ast)
        return Translation("measure", dax, dtype, notes=em.notes, constant=not state["agg"])
    probe = Emitter(resolver, "column", "")
    home = probe.pick_home(state["tables"])
    em = Emitter(resolver, "column", home)
    dax, dtype = em.emit(ast)
    return Translation("column", dax, dtype, table=home, notes=em.notes)

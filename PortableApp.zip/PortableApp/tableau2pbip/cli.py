"""tableau2pbip command line.

    tableau2pbip convert <workbook-or-folder> -o <output-folder> [options]
    tableau2pbip validate <pbip-folder>
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import shutil
import sys
import tempfile
import time

from . import __version__, extract, pbir_writer, reporting, tmdl_writer, validate, xlsx_report
from .ai_translator import AITranslator
from .mapper import Mapper


def convert_one(path, out_dir, args, log=print, taken=None):
    started = time.time()
    with tempfile.TemporaryDirectory(prefix="t2p_") as work:
        wb = extract.load(path, work)
        name = _safe_name(wb.name)
        if taken is not None:
            if name.lower() in taken:   # e.g. Sales.twb and Sales.twbx in one batch
                name = f"{name}_{os.path.splitext(path)[1].lstrip('.').lower()}"
                wb.name = name
            taken.add(name.lower())
        folder = os.path.join(out_dir, f"{name}_PBIP")
        if os.path.exists(folder):
            if not args.overwrite:
                raise FileExistsError(f"{folder} exists (use --overwrite)")
            shutil.rmtree(folder)
        os.makedirs(folder)
        ai = getattr(args, "_ai", None) or build_ai(args, log)
        stages = ai_stage_list(args)
        if args.data_root:
            data_root = args.data_root
        elif sys.platform == "win32":
            # Running on Windows: `folder` is already the real path the project (and its Data/
            # folder) is being written to on THIS machine, so default Data_Folder to it exactly
            # instead of guessing. This is the common case now (convert and open on the same
            # Windows machine, e.g. via the web UI): no parameter edit needed unless the folder
            # is later moved. Cross-machine authoring (Mac/Linux -> Windows) can't know the real
            # Windows destination path in advance, so it keeps the documented placeholder below,
            # which the user follows by copying the project to that exact path (README.md).
            data_root = os.path.join(folder, "Data")
        else:
            data_root = f"C:\\{name}_PBIP\\Data"
        mapper = Mapper(wb, folder, data_root=data_root, data_dirs=args.data_dir, ai=ai,
                        profile=not args.no_profile, row_limit=args.row_limit,
                        log=lambda m: log(m), extracts=getattr(args, "extracts", "auto"),
                        work_dir=os.path.join(work, "mapper"), ai_stages=stages)
        log(f"  mapping {len(wb.worksheets)} sheet(s), {len(wb.dashboards)} dashboard(s)")
        calls_before = (ai.client.calls, ai.client.cache_hits) if ai is not None else (0, 0)
        plan = mapper.run()
        if not getattr(args, "no_ai_readiness", False):
            from . import ai_readiness
            ai_readiness.enrich(plan, wb)
            with open(os.path.join(folder, "ai-instructions.md"), "w", encoding="utf-8", newline="\n") as f:
                f.write(plan.ai_instructions)
        copied = mapper.copy_data(os.path.join(folder, "Data")) if not args.no_copy_data else []
        for rel, local in wb.packaged_files.items():
            if rel.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".svg")):
                os.makedirs(os.path.join(folder, "Images"), exist_ok=True)
                shutil.copy2(local, os.path.join(folder, "Images", os.path.basename(rel)))
        tmdl_writer.write(plan, folder, name)
        pbir_writer.write(plan, folder, name)
        _write_json(os.path.join(folder, f"{name}.pbip"), {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
            "version": "1.0",
            "artifacts": [{"report": {"path": f"{name}.Report"}}],
            "settings": {"enableAutoRecovery": True}})
        with open(os.path.join(folder, ".gitignore"), "w") as f:
            f.write("**/.pbi/localSettings.json\n**/.pbi/cache.abf\n")
        if args.dump_ir:
            _write_json(os.path.join(folder, "validation", "tableau_ir.json"), wb.to_dict())
        recon = reporting.write_reconciliation(plan, folder)
        result = validate.validate(folder)
        ai_review = ""
        if ai is not None and ai.available and "review" in stages:
            log("  AI: writing the review")
            from . import ai_stages
            ai_review = ai_stages.review(plan, wb, result, ai, log)
        coverage_score = reporting.conversion_score(plan)
        xlsx_summary = xlsx_report.build(plan, wb, folder, name, result, coverage_score)
        scorecard = reporting.write_report(plan, wb, folder, name, result, recon, ai, ai_review, stages,
                                           xlsx_summary=xlsx_summary)
        reporting.write_readme(plan, wb, folder, name, copied)
        statuses = [i.status for i in plan.items]
        row = {
            "workbook": os.path.basename(path), "output": folder,
            "converted": statuses.count("converted"), "ai": statuses.count("ai"),
            "manual": statuses.count("placeholder"), "check": statuses.count("note"),
            "skipped": statuses.count("skipped"), "problems": len(result["problems"]),
            "reconciled": recon, "seconds": round(time.time() - started, 1),
            "published": [p["key"] or p["name"] for p in plan.published],
            "scorecard": scorecard,
            "trust_score": xlsx_summary["trust_pct"] if xlsx_summary else None,
        }
        write_manifest(folder, path, wb, args, ai, stages, calls_before, row, result, started)
        if args.zip:
            # Zip the folder's contents at the archive root (root_dir=folder, no base_dir), not
            # wrapped in another copy of the folder name: a zip named "X_PBIP.zip" whose own
            # internal root is also "X_PBIP/" makes Windows Explorer's "Extract All" (which
            # proposes a new folder named after the zip) produce "X_PBIP\X_PBIP\...".
            shutil.make_archive(folder, "zip", folder)
    return row


def _sha256(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_manifest(folder, path, wb, args, ai, stages, calls_before, row, result, started):
    """validation/run_manifest.json: what was converted, how, and fingerprints of every output file."""
    import datetime
    import platform
    outputs = {}
    for root, _, files in os.walk(folder):
        for fn in sorted(files):
            full = os.path.join(root, fn)
            rel = os.path.relpath(full, folder).replace(os.sep, "/")
            if rel != "validation/run_manifest.json":
                outputs[rel] = _sha256(full)
    ai_mode = getattr(args, "ai", "auto")
    manifest = {
        "tool": "tableau2pbip", "version": __version__,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "duration_seconds": round(time.time() - started, 1),
        "python": platform.python_version(), "platform": platform.platform(),
        "input": {"file": os.path.basename(path), "path": os.path.abspath(path), "sha256": _sha256(path),
                  "bytes": os.path.getsize(path), "kind": wb.kind, "tableau_version": wb.version},
        "options": {
            "data_root": args.data_root or None, "data_dirs": list(args.data_dir or []),
            "extracts": getattr(args, "extracts", "auto"), "profile": not args.no_profile,
            "row_limit": args.row_limit, "copy_data": not args.no_copy_data,
            "ai_readiness": not getattr(args, "no_ai_readiness", False),
            "ai": ai_mode, "ai_stages": stages if ai is not None else [],
            "ai_max_calls": getattr(args, "ai_max_calls", None),
        },
        "ai": ({"enabled": True, "model": ai.model,
                "api_calls": ai.client.calls - calls_before[0],
                "cached_answers": ai.client.cache_hits - calls_before[1]}
               if ai is not None else {"enabled": False}),
        "published_datasources": row["published"],
        "results": {k: row[k] for k in ("converted", "ai", "manual", "check", "skipped", "reconciled")},
        "conversion_score": row["scorecard"],
        "validation": {"json_checked": result["json_checked"], "tmdl_checked": result["tmdl_checked"],
                       "problems": result["problems"]},
        "outputs": outputs,
    }
    _write_json(os.path.join(folder, "validation", "run_manifest.json"), manifest)


def build_ai(args, log=print):
    """Create the AI layer. --ai auto (default): on when ANTHROPIC_API_KEY is set."""
    mode = getattr(args, "ai", "auto") or "off"
    if mode is True:
        mode = "on"
    if mode == "off":
        return None
    from .llm import DEFAULT_CACHE
    cache = None if getattr(args, "no_ai_cache", False) else (getattr(args, "ai_cache", None) or DEFAULT_CACHE)
    ai = AITranslator(model=getattr(args, "model", None), cache_dir=cache,
                      max_calls=getattr(args, "ai_max_calls", 200),
                      examples_file=getattr(args, "ai_examples", "") or "",
                      workspace_id=getattr(args, "workspace_id", None))
    if not ai.available:
        if mode == "on":
            log("  ! AI requested but ANTHROPIC_API_KEY is not set; continuing with rules only")
        return None
    return ai


def ai_stage_list(args):
    raw = getattr(args, "ai_stages", None) or "formulas,interactivity,visuals,review"
    return [x.strip() for x in raw.split(",") if x.strip()]


def _safe_name(s):
    import re
    return re.sub(r'[<>:"/\\|?*]', "_", s).strip() or "Workbook"


def _write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def collect_inputs(items, recursive=False):
    inputs = []
    for item in items:
        item = os.path.expanduser(item)
        if os.path.isdir(item):
            pattern = "**/*" if recursive else "*"
            for ext in (".twb", ".twbx", ".tds", ".tdsx"):
                inputs += glob.glob(os.path.join(item, pattern + ext), recursive=recursive)
        elif os.path.isfile(item):
            inputs.append(item)
    return sorted(set(inputs))


def run_batch(inputs, args, log=print, on_result=None):
    """Convert workbooks; returns (rows, failures). Used by the CLI and the web UI."""
    os.makedirs(args.output, exist_ok=True)
    if getattr(args, "_ai", None) is None:
        args._ai = build_ai(args, log)
    if args._ai:
        log(f"AI enabled: model {args._ai.model}, stages {', '.join(ai_stage_list(args))}, "
            f"budget {args._ai.client.max_calls} calls, cache {args._ai.client.cache_dir or 'off'}")
    else:
        log("AI off: rules only" + ("" if args.ai == "off" else " (set ANTHROPIC_API_KEY to enable)"))
    from . import hyper
    if hyper.available():
        log("Hyper extract reader: available (tableauhyperapi installed)")
    else:
        log("Hyper extract reader: NOT available. Any workbook whose data lives only in a Tableau "
            ".hyper extract will convert with EMPTY placeholder tables (no Data folder, no Power "
            "Query connection) until you run: pip install tableauhyperapi, then convert again.")
    rows, failures, taken = [], 0, set()
    for path in inputs:
        log(f"Converting {path}")
        try:
            r = convert_one(path, args.output, args, log=log, taken=taken)
            log(f"  -> {r['output']}  (converted {r['converted']}, AI {r['ai']}, manual {r['manual']}, "
                f"check {r['check']}, schema problems {r['problems']}, {r['seconds']}s)")
        except Exception as e:
            failures += 1
            r = {"workbook": os.path.basename(path), "error": str(e)}
            log(f"  !! failed: {e}")
            if args.debug:
                raise
        rows.append(r)
        if on_result:
            on_result(r)
    if len(inputs) > 1:
        lines = ["# Batch summary", "", "| Workbook | Converted | AI | Manual | Check | Schema problems | Reconciled visuals | Result |",
                 "| --- | --- | --- | --- | --- | --- | --- | --- |"]
        for r in rows:
            if "error" in r:
                lines.append(f"| {r['workbook']} | | | | | | | Failed: {r['error']} |")
            else:
                lines.append(f"| {r['workbook']} | {r['converted']} | {r['ai']} | {r['manual']} | {r['check']} | "
                             f"{r['problems']} | {r['reconciled']} | {os.path.basename(r['output'])} |")
        shared = {}
        for r in rows:
            for key in r.get("published", []):
                shared.setdefault(key, []).append(r["workbook"])
        if shared:
            lines += ["", "## Published Tableau data sources", "",
                      "Build one shared semantic model per data source (convert its exported .tdsx), then "
                      "connect every report that uses it, instead of keeping one model per workbook.", "",
                      "| Data source | Used by |", "| --- | --- |"]
            for key, wbs in sorted(shared.items(), key=lambda kv: (-len(kv[1]), kv[0])):
                lines.append(f"| {key} | {', '.join(wbs)} |")
        with open(os.path.join(args.output, "BATCH_SUMMARY.md"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        log(f"Batch summary: {os.path.join(args.output, 'BATCH_SUMMARY.md')}")
    return rows, failures


def cmd_convert(args):
    inputs = collect_inputs(args.inputs, args.recursive)
    if not inputs:
        print("No .twb/.twbx/.tds/.tdsx files found.")
        return 1
    args._ai = None
    rows, failures = run_batch(inputs, args)
    return 1 if failures else 0


def cmd_ui(args):
    from .webui import serve
    return serve(host="127.0.0.1", port=args.port, open_browser=not args.no_browser,
                 output=os.path.expanduser(args.output), logos_dir=args.logos)


def cmd_validate(args):
    res = validate.validate(args.folder)
    print(f"JSON files checked: {res['json_checked']}, TMDL files checked: {res['tmdl_checked']}")
    for p in res["problems"]:
        print("  -", p)
    print("OK" if not res["problems"] else f"{len(res['problems'])} problem(s)")
    return 0 if not res["problems"] else 1


def main(argv=None):
    ap = argparse.ArgumentParser(prog="tableau2pbip", description="Convert Tableau workbooks to Power BI projects (PBIP).")
    ap.add_argument("--version", action="version", version=f"tableau2pbip {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("convert", help="convert .twb/.twbx workbooks or .tds/.tdsx data sources")
    c.add_argument("inputs", nargs="+", help="workbook / data source files and/or folders")
    c.add_argument("-o", "--output", required=True, help="output folder")
    c.add_argument("-r", "--recursive", action="store_true", help="search folders recursively")
    c.add_argument("--data-root", default="", help=r"Windows folder where data files will live, e.g. C:\Data")
    c.add_argument("--data-dir", action="append", default=[], help="local folder to search for data files (repeatable)")
    c.add_argument("--extracts", choices=["auto", "always", "never"], default="auto",
                   help="use data from Tableau .hyper extracts: auto = only when the original source "
                        "isn't available (needs tableauhyperapi)")
    c.add_argument("--no-ai-readiness", action="store_true",
                   help="skip descriptions, Q&A setting and AI instructions for Copilot")
    c.add_argument("--ai", nargs="?", const="on", default="auto", choices=["auto", "on", "off"],
                   help="AI assistance: auto (default) = on when ANTHROPIC_API_KEY is set; on; off")
    c.add_argument("--ai-stages", default="formulas,interactivity,visuals,review",
                   help="comma list of AI stages: formulas, interactivity, visuals, review")
    c.add_argument("--ai-max-calls", type=int, default=200, help="maximum AI API calls per run (cache hits are free)")
    c.add_argument("--ai-cache", default=None, help="AI answer cache folder (default ~/.cache/tableau2pbip/ai)")
    c.add_argument("--no-ai-cache", action="store_true", help="don't read or write the AI cache")
    c.add_argument("--ai-examples", default="", help="JSON file of approved Tableau->DAX pairs to guide the AI")
    c.add_argument("--model", default=None, help="Claude model id (default claude-sonnet-5)")
    c.add_argument("--workspace-id", default=None,
                   help="Anthropic workspace ID: only needed if your API key is organization-level "
                        "rather than workspace-scoped (error: \"API key is not scoped to a "
                        "workspace\"). Env ANTHROPIC_WORKSPACE_ID")
    c.add_argument("--no-profile", action="store_true", help="don't read source data (no cardinality checks or reconciliation)")
    c.add_argument("--row-limit", type=int, default=None, help="max rows to read per table when profiling")
    c.add_argument("--no-copy-data", action="store_true", help="don't copy data files into the project")
    c.add_argument("--zip", action="store_true", help="also create a .zip of each project")
    c.add_argument("--overwrite", action="store_true", help="replace existing output folders")
    c.add_argument("--dump-ir", action="store_true", help="write the parsed Tableau structure to validation/tableau_ir.json")
    c.add_argument("--debug", action="store_true", help="stop with a traceback on the first failure")
    c.set_defaults(func=cmd_convert)

    u = sub.add_parser("ui", help="open the web interface in your browser")
    u.add_argument("--port", type=int, default=8765)
    u.add_argument("-o", "--output", default="~/PBIP_Output", help="default output folder")
    u.add_argument("--no-browser", action="store_true", help="don't open the browser automatically")
    u.add_argument("--logos", default=None, help="folder with logo files (default ~/.tableau2pbip/logos)")
    u.set_defaults(func=cmd_ui)

    lg = sub.add_parser("logos", help="show which logo files the web interface uses")
    lg.add_argument("--logos", default=None, help="folder with logo files (default ~/.tableau2pbip/logos)")
    lg.set_defaults(func=lambda a: __import__("tableau2pbip.webui", fromlist=["report_logos"]).report_logos(a.logos))

    v = sub.add_parser("validate", help="validate a generated PBIP folder")
    v.add_argument("folder")
    v.set_defaults(func=cmd_validate)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

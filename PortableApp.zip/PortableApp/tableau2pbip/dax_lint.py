"""Static checks for DAX mistakes that pass every file-level validation but fail
when Power BI evaluates the measure.

Adapted from the guidance in Guust-Franssens/tableau-to-powerbi-migration
(MIT; docs/tableau-dax-translation-guide.md section 4 and the
powerbi-semantic-model-gotchas skill).
"""
from __future__ import annotations

import re

STRING_RE = re.compile(r'"(?:[^"]|"")*"')
COMMENT_RE = re.compile(r"//[^\n]*|--[^\n]*|/\*.*?\*/", re.S)
COL_RE = re.compile(r"(?:'(?:[^']|'')+'|[A-Za-z_][A-Za-z0-9_]*)\[(?:[^\]]|\]\])+\]")
MEASURE_RE = re.compile(r"(?<![\w'\]])\[((?:[^\]]|\]\])+)\]")
FILTER_FUNCS = re.compile(r"\b(CALCULATE|CALCULATETABLE)\s*\(", re.I)
TABLE_ARG = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_.]*)\s*\(", re.I)
BOOLEAN_WRAPPERS = {"NOT", "AND", "OR", "KEEPFILTERS"}


def _clean(dax):
    return STRING_RE.sub('""', COMMENT_RE.sub("", dax or ""))


def _args(text, start):
    """Split the argument list of the call whose '(' is at `start`; returns (args, end_index)."""
    depth, cur, out, i = 0, [], [], start
    while i < len(text):
        ch = text[i]
        if ch in "([{":
            depth += 1
            if depth > 1:
                cur.append(ch)
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                out.append("".join(cur))
                return out, i
            cur.append(ch)
        elif ch == "," and depth == 1:
            out.append("".join(cur))
            cur = []
        elif depth >= 1:
            cur.append(ch)
        i += 1
    return out, len(text)


def _strip_wrapper(arg):
    """KEEPFILTERS ( x ) -> x (repeatedly)."""
    while True:
        m = re.match(r"^\s*KEEPFILTERS\s*\(", arg, re.I)
        if not m:
            return arg
        inner, _ = _args(arg, m.end() - 1)
        arg = inner[0] if inner else ""


def calculate_filter_problems(dax):
    """Measure references inside a boolean CALCULATE filter argument.

    `CALCULATE ( [x], 'T'[Year] = [Selected Year] )` is rejected by the engine at query time
    ("A function 'PLACEHOLDER' has been used in a True/False expression that is used as a table
    filter expression"). Read the measure into a VAR first, or use FILTER ( ALL ( ... ), ... ).
    """
    text = _clean(dax)
    problems = []
    for m in FILTER_FUNCS.finditer(text):
        args, _ = _args(text, m.end() - 1)
        for arg in args[1:]:
            body = _strip_wrapper(arg)
            fn = TABLE_ARG.match(body)
            if fn and fn.group(1).upper() not in BOOLEAN_WRAPPERS:
                continue            # table expression (FILTER, ALL, VALUES, DATESBETWEEN, ...)
            if not COL_RE.search(body):
                continue
            measures = [x.replace("]]", "]") for x in MEASURE_RE.findall(COL_RE.sub("", body))]
            measures = [x for x in measures if not x.startswith("@")]
            if measures:
                problems.append(
                    f"measure [{measures[0]}] is used inside a {m.group(1).upper()} filter "
                    f"(in: {' '.join(body.split())[:80]}); read it into a VAR first")
    return problems


def lint(dax):
    return calculate_filter_problems(dax)

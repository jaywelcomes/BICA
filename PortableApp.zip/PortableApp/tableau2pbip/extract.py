"""Read a Tableau .twb / .twbx into the neutral IR (tableau2pbip.ir)."""
from __future__ import annotations

import json
import os
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from .ir import (Calc, Connection, Dashboard, DataSource, Field, FieldUse, Hierarchy, Parameter,
                 Relationship, SetDef, SheetFilter, SourceTable, Workbook, Worksheet, Zone)

USER_NS = "{http://www.tableausoftware.com/xml/user}"
GENERATED = {"Latitude (generated)": "latitude", "Longitude (generated)": "longitude",
             "Geometry (generated)": "geometry"}
REF_RE = re.compile(r"\[((?:[^\]]|\]\])+)\]\.\[((?:[^\]]|\]\])+)\]")

DERIV_PREFIX = {
    "none": "None", "sum": "Sum", "avg": "Avg", "cnt": "Count", "ctd": "CountD",
    "min": "Min", "max": "Max", "med": "Median", "usr": "User", "attr": "Attribute",
    "yr": "Year", "qr": "Quarter", "mn": "Month", "dy": "Day", "wk": "Week",
    "tyr": "Year-Trunc", "tqr": "Quarter-Trunc", "tmn": "Month-Trunc",
    "twk": "Week-Trunc", "tdy": "Day-Trunc", "stdev": "Stdev", "var": "Var",
}


# --------------------------------------------------------------------------- helpers
def strip_brackets(s: str) -> str:
    s = (s or "").strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return s.replace("]]", "]")


def parse_literal(v):
    """Tableau literal text -> Python value. Dates come back as ('date', 'YYYY-MM-DD')."""
    if v is None:
        return None
    v = v.strip()
    if v in ("%null%", ""):
        return None
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return re.sub(r"\\(.)", r"\1", v[1:-1])
    if v.startswith("#") and v.endswith("#"):
        return ("date", v.strip("#"))
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    try:
        return int(v)
    except ValueError:
        pass
    try:
        return float(v)
    except ValueError:
        return v


def formatted_text(el) -> str:
    if el is None:
        return ""
    runs = [r.text or "" for r in el.iter("run")]
    return "".join(runs).replace("\u00c6", "\n").strip()


def parse_instance_name(inst: str):
    """'sum:Sales:qk' -> ('Sum', 'Sales')."""
    parts = inst.split(":")
    if len(parts) >= 3:
        deriv = DERIV_PREFIX.get(parts[0], parts[0])
        if parts[0] in ("pcto", "pcdf", "diff", "rank", "rsum", "cum", "mavg"):
            return "TableCalc", ":".join(parts[2:-1]) or parts[1]
        return deriv, ":".join(parts[1:-1])
    return "None", inst


# --------------------------------------------------------------------------- loading
def load(path: str, workdir: str) -> Workbook:
    path = os.path.abspath(path)
    packaged = {}
    low = path.lower()
    inner = ".tds" if low.endswith((".tds", ".tdsx")) else ".twb"
    if low.endswith((".twbx", ".tdsx")):
        dest = Path(workdir) / "twbx"
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                target = (dest / info.filename).resolve()
                if not str(target).startswith(str(dest.resolve())):
                    continue  # path traversal guard
                z.extract(info, dest)
                if not info.filename.lower().endswith(inner) and not info.is_dir():
                    packaged[info.filename.replace("\\", "/")] = str(target)
        found = [p for p in dest.glob("*" + inner)] or list(dest.rglob("*" + inner))
        if not found:
            raise ValueError(f"No {inner} found inside {path}")
        twb_path = str(found[0])
    elif low.endswith((".twb", ".tds")):
        twb_path = path
    else:
        raise ValueError(f"Not a Tableau workbook or data source: {path}")

    root = ET.parse(twb_path).getroot()
    kind = "workbook"
    if root.tag == "datasource":
        # A standalone data source: wrap it so the workbook readers work unchanged
        kind = "datasource"
        version = root.get("source-build") or root.get("version") or ""
        if not root.get("name"):
            root.set("name", root.get("formatted-name") or Path(path).stem)
        if not root.get("caption"):
            root.set("caption", root.get("formatted-name") or Path(path).stem)
        shell = ET.Element("workbook", {"version": version})
        ET.SubElement(shell, "datasources").append(root)
        root = shell
    wb = Workbook(name=Path(path).stem, source_path=path,
                  version=root.get("source-build") or root.get("version") or "",
                  packaged_files=packaged, kind=kind)
    _read_datasources(root, wb)
    _read_worksheets(root, wb)
    _read_dashboards(root, wb)
    for win in root.iter("window"):
        if win.get("hidden") == "true" and win.get("name"):
            wb.hidden_sheets.add(win.get("name"))
    wb.unsupported = _read_unsupported_features(root)
    return wb


def extension_label(add_in_id: str) -> str:
    """'com.tableau.extensions.bar' -> 'Bar'. Falls back to the raw id when it doesn't match the
    reverse-DNS shape every sample we've seen (Tableau Extensions Gallery add-ins) uses."""
    tail = (add_in_id or "").rsplit(".", 1)[-1]
    return tail.replace("-", " ").title() if tail else "extension"


def _read_unsupported_features(root) -> dict:
    """Best-effort scan for Tableau features this tool never attempts to convert at all — they're
    out of scope by design, not merely unsupported formulas — so they'd otherwise vanish from the
    migration with no trace. Story points and web data connectors are a plain XML tag/attribute
    scan (not verified against a real workbook that uses either; see CLAUDE.md), so treat a count
    of 0 there as "none found by this scan", not a guarantee. Viz extensions are confirmed against
    a real sample (a worksheet's <mark class='VizExtension'/> pane carries a sibling <add-in
    add-in-id='com.tableau.extensions.<type>' ...>) — Mapper.plan_visual natively converts a few
    types (bar/line/donut/kpi-card, see VIZ_EXTENSION_NATIVE in mapper.py) but every one is still
    listed here too, since even a natively-converted chart doesn't reproduce the extension's own
    visual design (custom formatting, colours, layout).
    """
    stories = sorted({s.get("name") for s in root.iter("storyboard") if s.get("name")})
    wdc = sorted({(c.get("server") or c.get("class")) for c in root.iter("connection")
                 if (c.get("class") or "").lower() in ("webdata", "webdataconnector")})
    viz_ext = []
    for ws in root.iter("worksheet"):
        name = ws.get("name") or ""
        for addin in ws.iter("add-in"):
            viz_ext.append(f"{name} ({extension_label(addin.get('add-in-id'))})")
    viz_ext += sorted({e.get("name") or e.get("id") or "(unnamed extension)"
                       for e in root.iter("zone") if (e.get("type") or e.get("type-v2") or "") == "extension"}
                      | {e.get("name") or e.get("id") or "(unnamed extension)" for e in root.iter("extension")})
    return {"story_points": stories, "web_data_connectors": wdc, "viz_extensions": sorted(set(viz_ext))}


def resolve_data_file(wb: Workbook, filename: str, directory: str, data_dirs: list) -> str:
    """Find a data file: packaged copy, original path, or by basename in --data-dir."""
    rel = "/".join(p for p in [directory, filename] if p).replace("\\", "/")
    for key, local in wb.packaged_files.items():
        if key == rel or key == filename.replace("\\", "/") or key.endswith("/" + os.path.basename(filename)):
            return local
    full = filename if os.path.isabs(filename) or re.match(r"^[A-Za-z]:", filename) else os.path.join(directory, filename)
    if os.path.exists(full):
        return full
    base = re.split(r"[\\/]", filename)[-1]
    for d in data_dirs or []:
        for p in Path(d).rglob(base):
            return str(p)
    return ""


# --------------------------------------------------------------------------- datasources
def _read_datasources(root, wb: Workbook):
    dss = root.find("datasources")
    if dss is None:
        return
    for ds_el in dss.findall("datasource"):
        name = ds_el.get("name")
        if name == "Parameters":
            _read_parameters(ds_el, wb)
            continue
        ds = DataSource(name=name, caption=ds_el.get("caption") or name)
        conn = ds_el.find("connection")
        if conn is None:
            ds.notes.append("Datasource has no connection (published or unsupported); fields only.")
        else:
            _read_connection(conn, ds)
        _read_fields(ds_el, ds)
        _read_sets(ds_el, ds)
        _read_hierarchies(ds_el, ds)
        _read_relationships(ds_el, ds)
        ds.published = published_identity(ds_el)
        ext = ds_el.find("extract")
        if ext is not None and ext.get("enabled") == "true":
            ec = ext.find("connection")
            if ec is not None and (ec.get("dbname") or ec.get("filename")):
                ds.extract_file = (ec.get("dbname") or ec.get("filename")).replace("\\", "/")
            if ext.find(".//filter") is not None:
                ds.extract_note = "The extract has filters, so it may hold a subset of the source data."
        for f in ds_el.findall("filter"):
            ds.notes.append(f"Datasource filter on {f.get('column')} not converted; apply it in Power Query if needed.")
        wb.datasources[name] = ds


def published_identity(ds_el):
    """Identify a Tableau published (server) data source, or return None.

    A workbook using one has connection class 'sqlproxy' and a <repository-location>. The stable key
    is site + data source name (lower-case), so several workbooks sharing one data source get the same
    key. Name precedence (derived-from URL, then the sqlproxy dbname, then repository-location id)
    follows scripts/parse_tableau.py in Guust-Franssens/tableau-to-powerbi-migration (MIT), which
    found that the id attribute can go stale after a rename.
    """
    from urllib.parse import unquote
    classes = {c.get("class") for c in ds_el.iter("connection")}
    repo = ds_el.find("repository-location")
    has_identity = repo is not None and bool(repo.get("id") or repo.get("derived-from"))
    if "sqlproxy" not in classes and not has_identity:
        return None
    name, source = None, None
    if repo is not None and repo.get("derived-from"):
        seg = repo.get("derived-from").split("?")[0].rstrip("/").rsplit("/", 1)[-1]
        if seg:
            name, source = unquote(seg), "derived-from"
    if name is None:
        for c in ds_el.iter("connection"):
            if c.get("class") == "sqlproxy" and c.get("dbname"):
                name, source = c.get("dbname"), "sqlproxy dbname"
                break
    if name is None and repo is not None and repo.get("id"):
        name, source = repo.get("id"), "repository-location id"
    site = repo.get("site") if repo is not None else None
    parts = [p for p in (site, name) if p]
    return {"name": name or ds_el.get("caption") or ds_el.get("name"), "site": site,
            "key": "/".join(parts).lower() if name else None, "name_source": source,
            "derived_from": repo.get("derived-from") if repo is not None else None}


def _read_connection(conn, ds: DataSource):
    if conn.get("class") == "federated":
        for nc in conn.iter("named-connection"):
            c = nc.find("connection")
            if c is None:
                continue
            ds.connections[nc.get("name")] = Connection(
                name=nc.get("name"), cls=c.get("class", ""), filename=c.get("filename", ""),
                directory=c.get("directory", ""), server=c.get("server", ""), dbname=c.get("dbname", ""),
                attrs=dict(c.attrib))
    else:
        ds.connections["default"] = Connection(
            name="default", cls=conn.get("class", ""), filename=conn.get("filename", ""),
            directory=conn.get("directory", ""), server=conn.get("server", ""), dbname=conn.get("dbname", ""),
            attrs=dict(conn.attrib))

    seen = set()
    for rel in conn.iter("relation"):
        rtype = rel.get("type")
        if rtype in ("table", "text") and rel.get("name") and rel.get("name") not in seen:
            seen.add(rel.get("name"))
            cname = rel.get("connection") or next(iter(ds.connections), "default")
            if rtype == "table":
                ds.tables[rel.get("name")] = SourceTable(rel.get("name"), cname, "table", rel.get("table", ""))
            else:
                ds.tables[rel.get("name")] = SourceTable(rel.get("name"), cname, "sql", sql=(rel.text or "").strip())
        elif rtype == "join":
            clause = rel.find("clause")
            if clause is not None:
                pairs = _equalities(clause.find("expression"))
                tabs = [strip_brackets(REF_RE.match(a).group(1)) if REF_RE.match(a) else "" for a, _ in pairs]
                if pairs:
                    ds.notes.append(f"Physical {rel.get('join', 'inner')} join converted to a relationship; "
                                    "Power BI keeps the tables separate.")
                    ds.relationships.append(("__join__", pairs, tabs))


def _equalities(expr):
    """Return [(left, right)] from an '=' or 'AND' expression element."""
    if expr is None:
        return []
    op = expr.get("op")
    kids = expr.findall("expression")
    if op == "=" and len(kids) == 2:
        return [(kids[0].get("op"), kids[1].get("op"))]
    if op and op.upper() == "AND":
        out = []
        for k in kids:
            out += _equalities(k)
        return out
    return []


def _read_fields(ds_el, ds: DataSource):
    single_table = next(iter(ds.tables), "")
    main = ds_el.find("connection")
    records = main.iter("metadata-record") if main is not None else ds_el.iter("metadata-record")
    for m in records:   # the <extract> block has its own records, incl. materialised calcs
        if m.get("class") != "column":
            continue
        local = strip_brackets(m.findtext("local-name") or "")
        parent = strip_brackets(m.findtext("parent-name") or "") or single_table
        if not local or local in ds.fields:
            continue
        ds.fields[local] = Field(key=local, table=parent,
                                 remote_name=m.findtext("remote-name") or local,
                                 datatype=m.findtext("local-type") or "string")

    for c in ds_el.findall("column"):
        key = strip_brackets(c.get("name", ""))
        if not key or key.startswith("__tableau_internal") or key.startswith(":"):
            continue
        calc = c.find("calculation")
        if calc is not None:
            ds.calcs[key] = _read_calc(key, c, calc)
            ds.fields.pop(key, None)
            continue
        f = ds.fields.get(key)
        if f is None:
            continue
        f.caption = c.get("caption", "") if c.get("caption") != f.remote_name else ""
        f.role = c.get("role", "")
        f.hidden = c.get("hidden") == "true"
        f.semantic_role = c.get("semantic-role", "")
        f.default_format = c.get("default-format", "")
        if c.get("datatype"):
            f.datatype = c.get("datatype")


def _read_hierarchies(ds_el, ds: DataSource):
    """Explicit Tableau hierarchies (Data pane > right-click fields > Create Hierarchy), stored as
    <drill-paths><drill-path name='...'><field>[Key]</field>...</drill-path></drill-paths>, a
    sibling of <column> directly under <datasource>. Tableau's automatic date hierarchies
    (Year/Quarter/Month/Day) aren't written here — only user-created ones are, which is the
    only kind that can meaningfully round-trip to a Power BI hierarchy anyway."""
    dp_root = ds_el.find("drill-paths")
    if dp_root is None:
        return
    for dp in dp_root.findall("drill-path"):
        name = dp.get("name") or ""
        if not name:
            continue
        levels = [strip_brackets(f.text) for f in dp.findall("field") if f.text]
        if levels:
            ds.hierarchies[name] = Hierarchy(key=name, caption=name, levels=levels)


def _read_calc(key, c, calc) -> Calc:
    cls = calc.get("class", "tableau")
    out = Calc(key=key, caption=c.get("caption") or key, cls=cls, formula=calc.get("formula", "") or "",
               datatype=c.get("datatype", ""), role=c.get("role", ""), hidden=c.get("hidden") == "true",
               default_format=c.get("default-format", ""))
    if cls == "categorical-bin":
        out.source_field = strip_brackets(calc.get("column", ""))
        for b in calc.findall("bin"):
            label = parse_literal(b.get("value"))
            for v in b.findall("value"):
                out.bins[parse_literal(v.text)] = label
    elif cls == "bin":
        out.source_field = strip_brackets(calc.get("formula", ""))
        out.bin_size = float(calc.get("size")) if calc.get("size") else None
        sp = calc.get("size-parameter", "")
        m = REF_RE.match(sp)
        out.bin_size_param = strip_brackets(m.group(2)) if m else strip_brackets(sp)
        out.peg = float(calc.get("peg") or 0)
    return out


def _read_sets(ds_el, ds: DataSource):
    for g in ds_el.findall("group"):
        key = strip_brackets(g.get("name", ""))
        cap = g.get("caption") or key
        gf = g.find("groupfilter")
        if gf is None:
            continue
        fn = gf.get("function")
        if fn == "end":
            order = gf.find("groupfilter")
            level_el = order.find("groupfilter") if order is not None else None
            count = gf.get("count", "")
            sd = SetDef(key=key, caption=cap, kind="topn", end=gf.get("end", "top"),
                        order_expr=(order.get("expression") if order is not None else "") or "",
                        direction=(order.get("direction") if order is not None else "DESC") or "DESC",
                        level=strip_brackets(level_el.get("level", "")) if level_el is not None else "")
            m = REF_RE.match(count)
            if m:
                sd.count_param = strip_brackets(m.group(2))
            else:
                try:
                    sd.count = int(count)
                except ValueError:
                    sd.kind, sd.note = "unsupported", f"Top N count '{count}' not understood"
            ds.sets[key] = sd
        elif fn in ("member", "union", "except"):
            members, level, exclude = [], "", fn == "except"
            for x in gf.iter("groupfilter"):
                if x.get("function") == "member":
                    members.append(parse_literal(x.get("member")))
                    level = level or strip_brackets(x.get("level", ""))
            ds.sets[key] = SetDef(key=key, caption=cap, kind="members", level=level,
                                  members=members, exclude=exclude)
        elif fn == "crossjoin" or key.startswith("Action ("):
            ds.sets[key] = SetDef(key=key, caption=cap, kind="action",
                                  note="Dashboard filter action; Power BI cross-filtering between visuals replaces it")
        else:
            ds.sets[key] = SetDef(key=key, caption=cap, kind="unsupported",
                                  note=f"Set/group function '{fn}' is not converted")


def _read_relationships(ds_el, ds: DataSource):
    obj_to_table = {}
    for obj in ds_el.iter("object"):
        rel = obj.find(".//relation")
        obj_to_table[obj.get("id")] = (rel.get("name") if rel is not None else None) or obj.get("caption")
    resolved = []
    for entry in ds.relationships:  # physical joins collected earlier
        _, pairs, _ = entry
        resolved.append(_pairs_to_relationship(ds, pairs, None, None))
    for r in ds_el.iter("relationship"):
        pairs = _equalities(r.find("expression"))
        first = r.find("first-end-point")
        second = r.find("second-end-point")
        lt = obj_to_table.get(first.get("object-id")) if first is not None else None
        rt = obj_to_table.get(second.get("object-id")) if second is not None else None
        resolved.append(_pairs_to_relationship(ds, pairs, lt, rt))
    ds.relationships = [x for x in resolved if x is not None]


def _pairs_to_relationship(ds, pairs, lt, rt):
    keys = []
    for a, b in pairs:
        ka, kb = _resolve_join_field(ds, a), _resolve_join_field(ds, b)
        if ka and kb and ka != kb:
            keys.append((ka, kb))
    if not keys:
        ds.notes.append(f"Relationship {lt} - {rt} uses expressions that were not converted: {pairs}")
        return None
    lt = ds.fields[keys[0][0]].table
    rt = ds.fields[keys[0][1]].table
    return Relationship(left_table=lt, right_table=rt, pairs=keys)


def _resolve_join_field(ds, op):
    """'[Returns].[Order ID]' -> the field of table Returns with that source name;
    '[Order ID (Returns)]' -> that field key."""
    m = REF_RE.match(op or "")
    if m:
        table, name = strip_brackets("[" + m.group(1) + "]"), strip_brackets("[" + m.group(2) + "]")
        for f in ds.fields.values():
            if f.table == table and f.remote_name == name:
                return f.key
        if name in ds.fields and ds.fields[name].table == table:
            return name
        return None
    key = strip_brackets(op or "")
    return key if key in ds.fields else None


def _field_key(op: str) -> str:
    m = REF_RE.match(op or "")
    return strip_brackets(m.group(2)) if m else strip_brackets(op or "")


def _read_parameters(ds_el, wb: Workbook):
    for c in ds_el.findall("column"):
        key = strip_brackets(c.get("name", ""))
        p = Parameter(key=key, caption=c.get("caption") or key, datatype=c.get("datatype", "string"),
                      domain=c.get("param-domain-type", "any"), value=parse_literal(c.get("value")))
        rng = c.find("range")
        if rng is not None:
            p.min = parse_literal(rng.get("min"))
            p.max = parse_literal(rng.get("max"))
            p.step = parse_literal(rng.get("granularity")) or 1
        mem = c.find("members")
        if mem is not None:
            p.members = [parse_literal(m.get("value")) for m in mem.findall("member")]
        wb.parameters[key] = p


# --------------------------------------------------------------------------- worksheets
def _read_worksheets(root, wb: Workbook):
    ws_root = root.find("worksheets")
    if ws_root is None:
        return
    for w in ws_root.findall("worksheet"):
        ws = Worksheet(name=w.get("name"))
        title_el = w.find("layout-options/title/formatted-text")
        ws.title = formatted_text(title_el).replace("<Sheet Name>", ws.name) or ws.name
        table = w.find("table")
        if table is None:
            wb.worksheets[ws.name] = ws
            continue
        view = table.find("view")
        inst = {}
        for dep in view.findall("datasource-dependencies"):
            dsn = dep.get("datasource")
            for ci in dep.findall("column-instance"):
                use = FieldUse(datasource=dsn, column=strip_brackets(ci.get("column")),
                               derivation=ci.get("derivation") or "None",
                               instance=strip_brackets(ci.get("name")),
                               table_calc=ci.find("table-calc") is not None)
                inst[(dsn, use.instance)] = use
        ws.rows = _shelf(table.findtext("rows"), inst, ws)
        ws.cols = _shelf(table.findtext("cols"), inst, ws)
        panes = table.find("panes")
        pane_list = panes.findall("pane") if panes is not None else []
        if pane_list:
            mark = pane_list[0].find("mark")
            ws.mark = mark.get("class") if mark is not None else "Automatic"
            if len(pane_list) > 1:
                marks = {(p.find("mark").get("class") if p.find("mark") is not None else "") for p in pane_list}
                if len(marks) > 1:
                    ws.notes.append("Multiple mark types (dual axis / combo) simplified to one visual.")
            if ws.mark == "VizExtension":
                addin = pane_list[0].find("add-in")
                if addin is not None:
                    ws.extension_id = addin.get("add-in-id", "")
                    setting = addin.find("instance-settings/setting[@key='config']")
                    if setting is not None and setting.get("value"):
                        try:
                            ws.extension_config = json.loads(setting.get("value"))
                        except (ValueError, TypeError):
                            pass
        seen = set()
        for p in pane_list:
            enc = p.find("encodings")
            if enc is None:
                continue
            for e in enc:
                for use in _shelf(e.get("column"), inst, ws):
                    k = (e.tag, use.instance)
                    if k not in seen:
                        seen.add(k)
                        ws.encodings.append((e.tag, use))
        for f in view.findall("filter"):
            col = f.get("column", "")
            if col.endswith("[:Measure Names]"):
                for x in f.iter("groupfilter"):
                    if x.get("function") == "member":
                        member = parse_literal(x.get("member")) or ""
                        ws.measure_values += [u for u in _shelf(member, inst, ws) if not u.generated]
                continue
            sf = _read_filter(f, inst)
            if sf and sf.kind == "action":
                ws.action_filters += 1
            elif sf:
                ws.filters.append(sf)
        wb.worksheets[ws.name] = ws


def _shelf(text, inst, ws):
    out = []
    if not text:
        return out
    if re.search(r"\s\+\s", text):
        ws.notes.append("Combined measures on one axis (+) are shown side by side in Power BI.")
    for m in REF_RE.finditer(text):
        dsn, name = m.group(1).replace("]]", "]"), m.group(2).replace("]]", "]")
        if dsn == "Parameters":
            continue
        if (dsn, name) in inst:
            out.append(inst[(dsn, name)])
        elif name in GENERATED:
            out.append(FieldUse(dsn, name, "None", name, generated=GENERATED[name]))
        elif name in ("Multiple Values", ":Measure Values", "Measure Values"):
            out.append(FieldUse(dsn, ":Measure Values", "None", name, generated="measure_values"))
        elif name in (":Measure Names", "Measure Names"):
            out.append(FieldUse(dsn, ":Measure Names", "None", name, generated="measure_names"))
        elif name.startswith(":"):
            ws.notes.append(f"'{name}' on a shelf is not converted.")
        else:
            deriv, col = parse_instance_name(name)
            out.append(FieldUse(dsn, col, deriv, name, table_calc=deriv == "TableCalc"))
    return out


def _read_filter(f, inst):
    col = f.get("column", "")
    m = REF_RE.match(col)
    if not m:
        return None
    key = (m.group(1), m.group(2))
    use = inst.get(key)
    if use is None:
        deriv, c = parse_instance_name(m.group(2))
        use = FieldUse(m.group(1), c, deriv, m.group(2))
    gf0 = f.find("groupfilter")
    if m.group(2).startswith("Action (") or (gf0 is not None and gf0.get("function") == "crossjoin"):
        return SheetFilter(use, "action")
    if f.get("class") != "categorical":
        return SheetFilter(use, "unsupported", note=f"{f.get('class')} filter on {use.column} not converted")
    gf = f.find("groupfilter")
    if gf is None:
        return None
    fn = gf.get("function")
    if fn == "level-members":
        return None
    members = [parse_literal(x.get("member")) for x in gf.iter("groupfilter") if x.get("function") == "member"]
    if fn in ("member", "union") and members:
        return SheetFilter(use, "include", members)
    if fn == "except" and members:
        return SheetFilter(use, "exclude", members)
    return SheetFilter(use, "unsupported", note=f"Filter function '{fn}' on {use.column} not converted")


# --------------------------------------------------------------------------- dashboards
LEGEND_TYPES = {"color", "size", "shape", "map", "highlighter"}
SKIP_TYPES = {"layout-basic", "layout-flow", "empty", "flipboard", "flipboard-nav"}


def _read_dashboards(root, wb: Workbook):
    d_root = root.find("dashboards")
    if d_root is None:
        return
    for d in d_root.findall("dashboard"):
        db = Dashboard(name=d.get("name"))
        size = d.find("size")
        if size is not None:
            w = size.get("maxwidth") or size.get("minwidth")
            h = size.get("maxheight") or size.get("minheight")
            if w and h:
                db.width, db.height = int(w), int(h)
                db.fixed_size = size.get("maxwidth") == size.get("minwidth")
        zones = d.find("zones")
        if zones is None:
            wb.dashboards.append(db)
            continue
        for z in zones.iter("zone"):
            t = z.get("type-v2") or z.get("type") or ""
            name = z.get("name", "")
            if t in SKIP_TYPES or (not t and not name):
                continue
            if not t and name in wb.worksheets:
                kind = "sheet"
            elif t in ("text", "title", "filter", "paramctrl"):
                kind = t
            elif t in LEGEND_TYPES:
                kind = "legend"
            elif t == "bitmap":
                kind = "image"
            else:
                kind = "other"
            db.zones.append(Zone(kind=kind, x=int(z.get("x", 0)), y=int(z.get("y", 0)),
                                 w=int(z.get("w", 0)), h=int(z.get("h", 0)), name=name,
                                 param=z.get("param", ""),
                                 text=formatted_text(z.find("formatted-text"))))
        wb.dashboards.append(db)

"""Read Tableau .hyper extracts (optional dependency: tableauhyperapi).

Power BI can't read .hyper files, so extract tables are exported to UTF-8 CSV
files that the generated Power Query reads instead.
"""
from __future__ import annotations

import csv
import datetime as dt
import os

try:
    from tableauhyperapi import Connection, HyperProcess, Telemetry
except ImportError:  # pragma: no cover - optional
    HyperProcess = None

HYPER_TYPES = {"TEXT": "string", "VARCHAR": "string", "CHAR": "string", "BIG_INT": "integer",
               "INT": "integer", "SMALL_INT": "integer", "DOUBLE": "real", "NUMERIC": "real",
               "DATE": "date", "TIMESTAMP": "datetime", "TIMESTAMP_TZ": "datetime", "BOOL": "boolean",
               "OID": "integer"}


def available() -> bool:
    return HyperProcess is not None


def _tableau_type(hyper_type: str) -> str:
    base = str(hyper_type).split("(")[0].strip().upper()
    return HYPER_TYPES.get(base, "string")


def _cell(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if hasattr(v, "to_date"):          # tableauhyperapi Date
        v = v.to_date()
    elif hasattr(v, "to_datetime"):    # tableauhyperapi Timestamp
        v = v.to_datetime()
    if isinstance(v, (dt.date, dt.datetime)):
        return v.isoformat(sep=" ") if isinstance(v, dt.datetime) else v.isoformat()
    return v


def export_tables(path: str, out_dir: str, stem: str, batch: int = 50000):
    """Export every table in a .hyper file to CSV.

    Returns [{"name", "csv", "rows", "columns": [(name, tableau_type)]}].
    """
    if not available():
        raise RuntimeError("tableauhyperapi is not installed (pip install tableauhyperapi)")
    os.makedirs(out_dir, exist_ok=True)
    out = []
    with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU,
                      parameters={"log_dir": out_dir}) as hp:   # keep hyperd.log out of the user's folder
        with Connection(hp.endpoint, path) as conn:
            tables = [t for s in conn.catalog.get_schema_names() for t in conn.catalog.get_table_names(s)]
            for t in tables:
                tname = t.name.unescaped
                definition = conn.catalog.get_table_definition(t)
                cols = [(c.name.unescaped, _tableau_type(c.type)) for c in definition.columns]
                suffix = "" if len(tables) == 1 else f" - {tname}"
                fname = f"{stem}{suffix}.csv"
                target = os.path.join(out_dir, fname)
                rows = 0
                with open(target, "w", newline="", encoding="utf-8") as fh:
                    w = csv.writer(fh)
                    w.writerow([c for c, _ in cols])
                    with conn.execute_query(f"SELECT * FROM {t}") as result:
                        chunk = []
                        for row in result:
                            chunk.append([_cell(v) for v in row])
                            if len(chunk) >= batch:
                                w.writerows(chunk)
                                rows += len(chunk)
                                chunk = []
                        w.writerows(chunk)
                        rows += len(chunk)
                out.append({"name": tname, "csv": target, "file": fname, "rows": rows, "columns": cols})
    return out

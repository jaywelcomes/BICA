"""Neutral intermediate representation of a Tableau workbook.

Everything the extractor reads from the .twb XML lands here, so the mapper and
writers never touch Tableau XML directly. `to_dict()` gives a JSON dump that is
useful for debugging and for feeding an LLM.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional


@dataclass
class Connection:
    name: str
    cls: str                       # excel-direct, textscan, sqlserver, databricks, hyper, ...
    filename: str = ""
    directory: str = ""
    server: str = ""
    dbname: str = ""
    resolved_path: str = ""        # local path to the data file, if found
    attrs: dict = field(default_factory=dict)   # every raw attribute of <connection>, for connectors
                                                # whose settings have no dedicated field above

    def attr(self, *names, default=""):
        """First non-empty raw attribute among `names`. Connector field names vary by
        Tableau version and by whether the native or the Databricks-supplied connector
        wrote the workbook (e.g. 'http-path' vs 'v-http-path')."""
        for n in names:
            v = (self.attrs.get(n) or "").strip()
            if v:
                return v
        return default


@dataclass
class SourceTable:
    name: str                      # Tableau logical table name, e.g. "Orders"
    connection: str                # Connection.name
    kind: str = "table"            # table | sql
    source: str = ""               # sheet / file / [schema].[table]
    sql: str = ""


@dataclass
class Field:
    key: str                       # Tableau local name without brackets, e.g. "Region (People)"
    table: str                     # SourceTable.name
    remote_name: str               # column name in the source
    datatype: str                  # string, integer, real, date, datetime, boolean
    caption: str = ""
    role: str = ""                 # dimension | measure
    hidden: bool = False
    semantic_role: str = ""
    default_format: str = ""

    @property
    def display(self) -> str:
        return self.caption or self.remote_name


@dataclass
class Calc:
    key: str                       # e.g. "Calculation_1368249927221915648"
    caption: str
    cls: str                       # tableau | categorical-bin | bin
    formula: str = ""
    datatype: str = ""
    role: str = ""
    hidden: bool = False
    default_format: str = ""
    # categorical-bin
    source_field: str = ""
    bins: dict = field(default_factory=dict)      # member -> group label
    # bin
    bin_size: Optional[float] = None
    bin_size_param: str = ""
    peg: float = 0.0


@dataclass
class SetDef:
    key: str
    caption: str
    kind: str                      # topn | members | unsupported
    level: str = ""                # field key
    count: Optional[int] = None
    count_param: str = ""
    end: str = "top"
    order_expr: str = ""
    direction: str = "DESC"
    members: list = field(default_factory=list)
    exclude: bool = False
    note: str = ""


@dataclass
class Relationship:
    left_table: str
    right_table: str
    pairs: list                    # [(left field key, right field key)]
    note: str = ""


@dataclass
class Hierarchy:
    key: str                       # <drill-path name='...'>, also used as the caption
    caption: str
    levels: list = field(default_factory=list)   # ordered field keys, top to bottom


@dataclass
class DataSource:
    name: str
    caption: str
    connections: dict = field(default_factory=dict)   # name -> Connection
    tables: dict = field(default_factory=dict)        # name -> SourceTable
    fields: dict = field(default_factory=dict)        # key -> Field
    calcs: dict = field(default_factory=dict)         # key -> Calc
    sets: dict = field(default_factory=dict)          # key -> SetDef
    hierarchies: dict = field(default_factory=dict)   # key -> Hierarchy
    relationships: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    extract_file: str = ""         # packaged .hyper path when a Tableau extract is enabled
    extract_note: str = ""
    published: Optional[dict] = None   # Tableau published data source identity (sqlproxy)


@dataclass
class Parameter:
    key: str                       # "Parameter 1"
    caption: str
    datatype: str
    domain: str                    # range | list | any
    value: object = None
    min: Optional[float] = None
    max: Optional[float] = None
    step: Optional[float] = None
    members: list = field(default_factory=list)


@dataclass
class FieldUse:
    """A field placed on a shelf or mark card (a Tableau column-instance)."""
    datasource: str
    column: str                    # field / calc / set key (no brackets)
    derivation: str                # None, Sum, Avg, User, Year, Month-Trunc, ...
    instance: str = ""
    table_calc: bool = False
    generated: str = ""            # latitude | longitude | geometry

    @property
    def is_aggregate(self) -> bool:
        return self.derivation in AGG_DERIVATIONS


AGG_DERIVATIONS = {"Sum", "Avg", "Count", "CountD", "Min", "Max", "Median", "User",
                   "Stdev", "Var", "Stdevp", "Varp"}


@dataclass
class SheetFilter:
    use: FieldUse
    kind: str                      # include | exclude | unsupported
    values: list = field(default_factory=list)
    note: str = ""


@dataclass
class Worksheet:
    name: str
    title: str = ""
    rows: list = field(default_factory=list)          # [FieldUse]
    cols: list = field(default_factory=list)
    mark: str = "Automatic"
    extension_id: str = ""         # add-in-id when mark == "VizExtension", e.g. "com.tableau.extensions.bar"
    extension_config: dict = field(default_factory=dict)  # parsed instance-settings 'config' JSON, if any
    encodings: list = field(default_factory=list)     # [(kind, FieldUse)]
    filters: list = field(default_factory=list)       # [SheetFilter]
    measure_values: list = field(default_factory=list)  # [FieldUse] selected in Measure Names
    action_filters: int = 0
    notes: list = field(default_factory=list)


@dataclass
class Zone:
    kind: str                      # sheet | text | title | filter | paramctrl | legend | image | other
    x: int
    y: int
    w: int
    h: int
    name: str = ""
    param: str = ""
    text: str = ""


@dataclass
class Dashboard:
    name: str
    width: int = 1280
    height: int = 720
    fixed_size: bool = False
    zones: list = field(default_factory=list)


@dataclass
class Workbook:
    name: str
    source_path: str
    version: str = ""
    datasources: dict = field(default_factory=dict)   # name -> DataSource
    parameters: dict = field(default_factory=dict)    # key -> Parameter
    worksheets: dict = field(default_factory=dict)    # name -> Worksheet
    dashboards: list = field(default_factory=list)
    hidden_sheets: set = field(default_factory=set)
    packaged_files: dict = field(default_factory=dict)  # packaged relative path -> extracted local path
    kind: str = "workbook"         # workbook | datasource (.tds/.tdsx)
    notes: list = field(default_factory=list)
    # Best-effort XML scan for features this tool never converts at all (out of scope, not just
    # unsupported formulas): story points, viz extensions, web data connectors. See
    # extract._read_unsupported_features. {"story_points": [...], "viz_extensions": [...],
    # "web_data_connectors": [...]}, each a list of names/captions found.
    unsupported: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["hidden_sheets"] = sorted(self.hidden_sheets)
        return d

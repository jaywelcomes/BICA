"""Shared LLM client for all AI stages.

* Claude Messages API over plain HTTPS (no SDK dependency).
* Retries with backoff on rate limits / server errors.
* Disk cache keyed by model + prompts, so re-running a conversion costs nothing
  and gives the same answers (deterministic output for Git).
* A call budget per run caps spend.

To use another provider, subclass LLMClient and override `_request`.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-sonnet-5"
DEFAULT_CACHE = os.path.join(os.path.expanduser("~"), ".cache", "tableau2pbip", "ai")


class BudgetExceeded(RuntimeError):
    pass


class LLMClient:
    def __init__(self, api_key=None, model=None, cache_dir=DEFAULT_CACHE, max_calls=200,
                 timeout=180, max_tokens=8000, retries=3, workspace_id=None):
        self.api_key = api_key if api_key is not None else os.environ.get("ANTHROPIC_API_KEY", "")
        self.model = model or os.environ.get("TABLEAU2PBIP_MODEL", DEFAULT_MODEL)
        # Some organisations only issue API keys scoped to the whole org, not to one workspace;
        # Anthropic then requires this header on every request (400 invalid_request_error
        # otherwise: "This API key is not scoped to a workspace..."). Optional and blank for the
        # common case (a workspace-scoped key), where sending it is unnecessary.
        self.workspace_id = workspace_id if workspace_id is not None else os.environ.get("ANTHROPIC_WORKSPACE_ID", "")
        self.cache_dir = cache_dir
        self.max_calls = max_calls
        self.timeout, self.max_tokens, self.retries = timeout, max_tokens, retries
        self.calls = 0          # real API calls
        self.cache_hits = 0
        self.failures = 0

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    # ------------------------------------------------------------------ public
    def complete(self, system: str, user: str) -> str:
        return self._cached([self.model, system, user], lambda: self._request(system, user))

    def complete_json(self, system: str, user: str):
        """Call and parse a JSON object answer. Raises ValueError if unparsable."""
        return parse_json(self.complete(system, user))

    def chat(self, system: str, messages: list) -> str:
        """Multi-turn conversation (the AI Migration Assistant). `messages` is the full history so
        far, oldest first, each `{"role": "user"|"assistant", "content": str}` — the caller appends
        the new user turn before calling. Cached like `complete()`, keyed on the whole history, so
        replaying an identical conversation (tests; a user re-asking the same thing) is free."""
        return self._cached([self.model, system, messages], lambda: self._request_chat(system, messages))

    # ------------------------------------------------------------------ cache + budget
    def _cached(self, key_parts, fn) -> str:
        key = hashlib.sha256(json.dumps(key_parts).encode("utf-8")).hexdigest()
        path = os.path.join(self.cache_dir, key[:2], key + ".json") if self.cache_dir else ""
        if path and os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                self.cache_hits += 1
                return json.load(f)["text"]
        if self.calls >= self.max_calls:
            raise BudgetExceeded(f"AI call budget of {self.max_calls} reached")
        self.calls += 1
        text = fn()
        if path:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"model": self.model, "text": text}, f)
        return text

    # ------------------------------------------------------------------ transport
    def _request(self, system: str, user: str) -> str:
        return self._post(system, [{"role": "user", "content": user}])

    def _request_chat(self, system: str, messages: list) -> str:
        return self._post(system, messages)

    def _post(self, system: str, messages: list) -> str:
        body = json.dumps({
            "model": self.model,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": messages,
        }).encode("utf-8")
        last = None
        headers = {
            "content-type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }
        if self.workspace_id:
            headers["anthropic-workspace-id"] = self.workspace_id
        for attempt in range(self.retries + 1):
            req = urllib.request.Request(API_URL, data=body, method="POST", headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            except urllib.error.HTTPError as e:
                detail = e.read().decode("utf-8", "replace")[:300]
                last = RuntimeError(f"Claude API error {e.code}: {detail}")
                if e.code not in (408, 429, 500, 502, 503, 504, 529):
                    break
                wait = float(e.headers.get("retry-after") or 2 ** (attempt + 1))
            except (urllib.error.URLError, TimeoutError) as e:
                last = RuntimeError(f"Claude API unreachable: {e}")
                wait = 2 ** (attempt + 1)
            if attempt < self.retries:
                time.sleep(min(wait, 60))
        self.failures += 1
        raise last


def parse_json(text: str):
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, re.S)   # tolerate a stray sentence around the object
        if m:
            return json.loads(m.group(0))
        raise ValueError("AI answer was not valid JSON")

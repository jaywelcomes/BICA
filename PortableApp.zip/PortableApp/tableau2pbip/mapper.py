"""Turn the Tableau IR into a Power BI plan (model + report), recording every
decision for the migration report."""
from __future__ import annotations

import itertools
import os
import re
import shutil
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from typing import Callable, Optional

from . import hyper, profiler
from .calc_translator import Ref, Resolver, SecurityFunction, Unsupported, qcol, qmeasure, qtable, translate
from .extract import REF_RE, extension_label, parse_instance_name, resolve_data_file, strip_brackets
from .ir import Connection, FieldUse, SourceTable, Workbook

TMDL_TYPE = {"string": "string", "integer": "int64", "real": "double", "date": "dateTime",
             "datetime": "dateTime", "boolean": "boolean"}
M_TYPE = {"string": "type text", "integer": "Int64.Type", "real": "type number", "date": "type date",
          "datetime": "type datetime", "boolean": "type logical"}
M_TABLE_TYPE = {"string": "text", "integer": "Int64.Type", "real": "number", "date": "date",
                "datetime": "datetime", "boolean": "logical"}
SIMPLE_TYPE = {"string": "string", "integer": "number", "real": "number", "date": "date",
               "datetime": "date", "boolean": "bool"}
GEO_ROLES = {"[ZipCode].[Name]": "PostalCode", "[City].[Name]": "City", "[County].[Name]": "County",
             "[State].[Name]": "StateOrProvince", "[Country].[ISO3166_2]": "Country",
             "[Country].[Name]": "Country", "[Geographical].[Latitude]": "Latitude",
             "[Geographical].[Longitude]": "Longitude", "[Airport].[Name]": "Place",
             "[Area Code].[Name]": "Place", "[CBSA].[Name]": "Place"}
GEO_RANK = {"Place": 0, "Address": 0, "PostalCode": 1, "City": 2, "County": 3,
            "StateOrProvince": 4, "Country": 5, "Continent": 6}
AGG_NAME = {"Sum": "Total {}", "Avg": "Average {}", "Count": "Count of {}", "CountD": "Distinct Count of {}",
            "Min": "Min {}", "Max": "Max {}", "Median": "Median {}"}
AGG_DAX = {"Sum": "SUM", "Avg": "AVERAGE", "Count": "COUNTA", "CountD": "DISTINCTCOUNTNOBLANK",
           "Min": "MIN", "Max": "MAX", "Median": "MEDIAN"}
DATEPARTS = {
    "Year": ("{c} Year", "YEAR ( {q} )", "int64", "0", "Year"),
    "Year-Trunc": ("{c} Year", "YEAR ( {q} )", "int64", "0", "Year"),
    "Quarter": ("{c} Quarter", '"Q" & QUARTER ( {q} )', "string", None, "Quarter"),
    "Month": ("{c} Month No", "MONTH ( {q} )", "int64", "0", "Month No"),
    "Day": ("{c} Day", "DAY ( {q} )", "int64", "0", "Day"),
    "Month-Trunc": ("{c} (Month)", "DATE ( YEAR ( {q} ), MONTH ( {q} ), 1 )", "dateTime", "mmm yyyy", "Month Start"),
    "Quarter-Trunc": ("{c} (Quarter)", "DATE ( YEAR ( {q} ), ( QUARTER ( {q} ) - 1 ) * 3 + 1, 1 )",
                      "dateTime", "mmm yyyy", "Quarter Start"),
    "Week-Trunc": ("{c} (Week)", "{q} - WEEKDAY ( {q}, 1 ) + 1", "dateTime", "Short Date", None),
}
CURRENCY = r"\$#,0.00;-\$#,0.00;\$#,0.00"
# Tableau Viz Extensions (Extensions API marks, e.g. the "Klimn Executive" gallery pack) with an
# obvious native Power BI chart — everything else still becomes a real table/pivot (see
# Mapper.plan_viz_extension), never a guessed chart shape. Confirmed against a real workbook
# (add-in-id + an 'orientation' field in its instance-settings 'config' JSON for "bar").
VIZ_EXTENSION_NATIVE = {"com.tableau.extensions.bar", "com.tableau.extensions.line",
                        "com.tableau.extensions.donut", "com.tableau.extensions.kpi-card"}


# =========================================================================== plan objects
@dataclass
class MColumn:
    name: str
    dtype: str                      # TMDL data type
    source_column: str = ""         # M column (for data columns)
    expression: str = ""            # DAX (for calculated columns)
    fmt: str = ""
    category: str = ""
    hidden: bool = False
    summarize: str = "none"
    description: str = ""
    sort_by: str = ""
    inferred: bool = False          # calculated-table column
    pandas_fn: Optional[Callable] = None
    pandas_inputs: list = field(default_factory=list)


@dataclass
class MMeasure:
    name: str
    expression: str
    fmt: str = "#,0.00"
    description: str = ""
    folder: str = ""
    status: str = "rule"            # rule | ai | placeholder
    recon: Optional[tuple] = None   # (derivation, table, column) for reconciliation
    currency: bool = False


@dataclass
class MHierarchy:
    name: str
    levels: list = field(default_factory=list)   # ordered column names, top to bottom


@dataclass
class MTable:
    name: str
    kind: str = "m"                 # m | calculated
    m_source: list = field(default_factory=list)   # M step lines before typing
    m_extra: list = field(default_factory=list)    # extra M steps (name, expr)
    select_cols: list = field(default_factory=list)  # (remote, display, tableau type)
    dax_source: str = ""
    columns: "OrderedDict[str, MColumn]" = field(default_factory=OrderedDict)
    measures: list = field(default_factory=list)
    hierarchies: list = field(default_factory=list)   # [MHierarchy]
    description: str = ""
    is_parameter: bool = False
    source_kind: str = ""
    source_note: str = ""


@dataclass
class MExpression:
    name: str
    m: str
    kind: str = "query"             # param | query
    description: str = ""


@dataclass
class MRelationship:
    from_table: str
    from_col: str
    to_table: str
    to_col: str
    many_to_many: bool = False
    evidence: str = ""


@dataclass
class Projection:
    kind: str                       # column | measure
    table: str
    name: str
    active: bool = True


@dataclass
class VisualSpec:
    sheet: str
    vtype: str
    title: str
    roles: "OrderedDict[str, list]" = field(default_factory=OrderedDict)
    objects: dict = field(default_factory=dict)
    filters: list = field(default_factory=list)   # (Projection, 'include'|'exclude', values)
    notes: list = field(default_factory=list)
    text: str = ""                  # textbox content

    def all_projections(self):
        out = []
        for projs in self.roles.values():
            out += projs
        return out


@dataclass
class PlacedVisual:
    spec: VisualSpec
    x: int
    y: int
    w: int
    h: int


@dataclass
class Page:
    name: str
    display: str
    width: int
    height: int
    visuals: list = field(default_factory=list)
    notes: list = field(default_factory=list)


@dataclass
class ReportItem:
    area: str
    name: str
    status: str                     # converted | ai | placeholder | skipped | note
    detail: str = ""
    source: str = ""
    result: str = ""
    key: str = ""                   # dedup identity for conversion_score; defaults to `name` when blank.
                                     # Needed wherever `name` is a Tableau caption that isn't unique across
                                     # datasources (e.g. two data sources both defining a calc called "AOV")


class Plan:
    def __init__(self, name):
        self.name = name
        self.tables: "OrderedDict[str, MTable]" = OrderedDict()
        self.expressions: list = []
        self.relationships: list = []
        self.pages: list = []
        self.items: list = []
        self.field_map = {}          # (ds, key) -> Ref
        self.measure_by_name = {}
        self.data_files = []         # (local path, packaged relative name)
        self.frames = {}
        self.specs = {}              # sheet -> VisualSpec
        self.ai_instructions = ""    # CustomInstructions markdown (ai_readiness)
        self.qna_enabled = False
        self.readiness = None
        self.published = []         # published Tableau data sources used by this workbook
        # Structured mirrors of the "Blend"/"Security" Plan.log() items, for the Excel
        # reconciliation engine (xlsx_report.py) — the log items themselves stay the single
        # source of truth for MIGRATION_REPORT.md; these just avoid re-parsing that text.
        self.blends = []            # [{worksheet, primary, secondary, linking_fields, confidence,
                                     #   relationship_created, status, detail}]
        self.security = []          # [{calc, function, formula}]

    # ---- bookkeeping
    def log(self, area, name, status, detail="", source="", result="", key=""):
        self.items.append(ReportItem(area, name, status, detail, source, result, key))

    def all_names(self):
        names = set()
        for t in self.tables.values():
            names |= set(t.columns)
            names |= {m.name for m in t.measures}
        return names

    def unique_measure_name(self, name):
        used = self.all_names()
        if name not in used:
            return name
        i = 2
        while f"{name} ({i})" in used:
            i += 1
        return f"{name} ({i})"

    def add_measure(self, table, m: MMeasure):
        self.tables[table].measures.append(m)
        self.measure_by_name[m.name] = m
        return m.name

    def related(self, a, b):
        return self.path_to(a, b) is not None and a != b

    def path_to(self, a, b):
        """Many-to-one hops from table a to table b: [(from_t, from_c, to_t, to_c)]."""
        if a == b:
            return []
        frontier, seen = [(a, [])], {a}
        while frontier:
            t, path = frontier.pop(0)
            for r in self.relationships:
                if r.from_table == t and r.to_table not in seen and not r.many_to_many:
                    np = path + [(r.from_table, r.from_col, r.to_table, r.to_col)]
                    if r.to_table == b:
                        return np
                    seen.add(r.to_table)
                    frontier.append((r.to_table, np))
        return None

    def derive_all(self, table, df):
        """Add derived (calculated) columns to a DataFrame for reconciliation."""
        t = self.tables[table]
        for c in t.columns.values():
            if c.pandas_fn is None or c.name in df.columns:
                continue
            try:
                if all(i in df.columns for i in c.pandas_inputs):
                    df[c.name] = c.pandas_fn(*[df[i] for i in c.pandas_inputs])
            except Exception:
                pass
        return df


# =========================================================================== helpers
def safe_ident(s, prefix=""):
    out = re.sub(r"_+", "_", re.sub(r"[^A-Za-z0-9_]", "_", s)).strip("_")
    if not out or out[0].isdigit():
        out = (prefix or "x") + "_" + out
    return out


def m_str(s):
    return '"' + s.replace('"', '""') + '"'


def m_name(s):
    return s if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", s) else '#"' + s.replace('"', '""') + '"'


# Catalog of a Databricks workspace that has no Unity Catalog; the safe default when the
# workbook names only a schema and a table.
DATABRICKS_DEFAULT_CATALOG = "hive_metastore"
DATABRICKS_DEFAULT_SCHEMA = "default"


def databricks_target(conn, src):
    """Resolve (catalog, schema, table) for one Databricks relation.

    Tableau writes the relation as `[catalog].[schema].[table]`, `[schema].[table]` or just
    `[table]`; whatever it leaves out comes from the connection's own defaults. Returns empty
    strings for the levels that are nowhere to be found, so the caller can note them.
    """
    parts = [strip_brackets(x) for x in re.findall(r"\[[^\]]+\]", src or "")]
    if not parts:
        parts = [p for p in (src or "").split(".") if p]
    catalog = conn.attr("catalog", "v-catalog", "unity-catalog")
    schema = conn.attr("schema", "v-schema", "dbname")
    if len(parts) >= 3:
        catalog, schema, table = parts[-3], parts[-2], parts[-1]
    elif len(parts) == 2:
        schema, table = parts[-2], parts[-1]
    else:
        table = parts[-1] if parts else (src or "")
    return catalog, schema, table


def tableau_format(code, datatype):
    if not code:
        return None, False
    if code.startswith("C"):
        return CURRENCY, True
    body = code[1:] if code[:1] in "npc" else code
    if code.startswith("p"):
        return (body if "%" in body else body + "%"), False
    return (body or None), False


def default_format(datatype):
    return "#,0" if datatype == "integer" else "#,0.00"


def dax_literal(v, datatype=""):
    if v is None:
        return "BLANK ()"
    if isinstance(v, bool):
        return "TRUE ()" if v else "FALSE ()"
    if isinstance(v, tuple) and v and v[0] == "date":
        y, m, d = (v[1].split(" ")[0].split("-") + ["1", "1"])[:3]
        return f"DATE ( {int(y)}, {int(m)}, {int(d)} )"
    if isinstance(v, (int, float)):
        return repr(v)
    return '"' + str(v).replace('"', '""') + '"'


# =========================================================================== mapper
class Mapper:
    def __init__(self, wb: Workbook, out_root: str, data_root: str = "", data_dirs=None,
                 ai=None, profile=True, row_limit=None, log=print, extracts="auto", work_dir="",
                 ai_stages=("formulas", "interactivity", "visuals")):
        self.wb, self.out_root, self.log_fn = wb, out_root, log
        self.extracts, self.work_dir = extracts, work_dir or os.path.join(out_root, ".t2p_work")
        self.data_root = data_root or f"C:\\{wb.name}_PBIP\\Data"
        self.data_dirs = data_dirs or []
        self.ai, self.profile, self.row_limit = ai, profile and profiler.available(), row_limit
        self.ai_stages = set(ai_stages or ())
        self.plan = Plan(wb.name)
        self.path_params = {}
        self.data_folder_param = None
        self.ds_of_table = {}
        self.source_info = {}        # table -> (kind, local path, source)

    # ------------------------------------------------------------------ entry
    def run(self) -> Plan:
        for ds in self.wb.datasources.values():
            self.apply_extract(ds)
            self.map_datasource(ds)
        self.map_parameters()
        self.load_frames()
        for ds in self.wb.datasources.values():
            self.map_relationships(ds)
            self.map_groups_and_bins(ds)
        self.map_blends()
        for ds in self.wb.datasources.values():
            self.map_calcs(ds)
            self.map_sets(ds)
            self.map_hierarchies(ds)
            for n in ds.notes:
                self.plan.log("Data source", ds.caption, "note", n)
        for ws in self.wb.worksheets.values():
            self.plan.specs[ws.name] = self.plan_visual(ws)
        if self.ai_on("interactivity"):
            from . import ai_stages
            self.log_fn("  AI: making parameter-driven measures interactive")
            ai_stages.make_interactive(self, self.log_fn)
        if self.ai_on("visuals"):
            from . import ai_stages
            self.log_fn("  AI: improving approximated visuals")
            ai_stages.improve_visuals(self, self.log_fn)
        self.map_pages()
        for n in self.wb.notes:
            self.plan.log("Workbook", self.wb.name, "note", n)
        return self.plan

    def ai_on(self, stage):
        return self.ai is not None and self.ai.available and stage in self.ai_stages

    # ------------------------------------------------------------------ data sources
    def table_name(self, ds, tname):
        name = re.sub(r"\.(csv|txt|tsv|tab)$", "", tname, flags=re.I)
        name = re.sub(r"\$$", "", name) or tname
        if len(ds.tables) == 1 and re.fullmatch(r"(sheet\d*|extract|custom sql query|table\d*|sqlproxy)", name, re.I):
            name = ds.caption
        tname = name
        if name in self.plan.tables or name in {p.caption for p in self.wb.parameters.values()}:
            name = f"{ds.caption} {tname}"
        return name

    def path_param(self, local, original, packaged_rel):
        """M expression that resolves to this file's path, for use inside File.Contents(...).

        A file that gets copied into the project's own Data/ folder is referenced through the
        one shared Data_Folder parameter (folder & filename), not its own absolute-path
        parameter: moving the whole PBIP folder elsewhere then needs exactly one parameter
        edited, not one per file. A file that stays at its original external location (not
        copied, e.g. --no-copy-data) keeps its own absolute-path parameter, since there's no
        shared folder to key it off.
        """
        base = re.split(r"[\\/]", original)[-1]
        key = local or original
        if key in self.path_params:
            return self.path_params[key]
        if local:
            self.plan.data_files.append((local, base))
            expr = f"{self.ensure_data_folder_param()} & \"\\\" & {m_str(base)}"
            self.path_params[key] = expr
            return expr
        pname = safe_ident("Path_" + os.path.splitext(base)[0], "Path")
        existing = {e.name for e in self.plan.expressions}
        i = 2
        while pname in existing:
            pname = f"{pname}_{i}"
            i += 1
        default = original.replace("/", "\\")
        self.plan.expressions.append(MExpression(
            pname, f'{m_str(default)} meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
            "param", f"Location of {base}"))
        self.path_params[key] = pname
        return pname

    def ensure_data_folder_param(self):
        if self.data_folder_param:
            return self.data_folder_param
        name = "Data_Folder"
        existing = {e.name for e in self.plan.expressions}
        i = 2
        while name in existing:
            name = f"Data_Folder_{i}"
            i += 1
        default = self.data_root.rstrip("\\/")
        self.plan.expressions.append(MExpression(
            name, f'{m_str(default)} meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
            "param", "Folder holding this project's copied data files (Data/ next to the .pbip file). "
                     "After moving the whole project folder, set this once to the new Data folder's path; "
                     "every copied-in table uses it, so nothing else needs editing."))
        self.data_folder_param = name
        return name

    # ------------------------------------------------------------------ Tableau extracts
    def original_available(self, ds):
        """True if every connection of the datasource can be reached without the extract."""
        for c in ds.connections.values():
            if c.cls in ("excel-direct", "textscan"):
                if not c.filename or not resolve_data_file(self.wb, c.filename, c.directory, self.data_dirs):
                    return False
            elif c.cls not in ("sqlserver", "databricks"):
                return False
        return bool(ds.connections)

    def apply_extract(self, ds):
        """Rebuild the datasource on CSV files exported from its .hyper extract."""
        if not ds.extract_file or self.extracts == "never":
            return
        if self.extracts == "auto" and self.original_available(ds):
            ds.notes.append("Tableau extract ignored: the original source is available.")
            return
        local = resolve_data_file(self.wb, ds.extract_file, "", self.data_dirs)
        if not local:
            ds.notes.append(f"Extract {ds.extract_file} not found; using the original connection.")
            return
        if not hyper.available():
            msg = ("Data is only in a Tableau extract. Install tableauhyperapi "
                   "(pip install tableauhyperapi) and convert again to use it.")
            self.log_fn(f"  ! {ds.caption}: {msg}")
            self.plan.log("Data source", ds.caption, "placeholder", msg)
            return
        stem = safe_ident(ds.caption, "Extract").replace("_", " ").strip() or "Extract"
        try:
            exported = hyper.export_tables(local, os.path.join(self.work_dir, "extracts"), stem)
        except Exception as e:
            self.log_fn(f"  ! {ds.caption}: reading extract failed: {e}")
            self.plan.log("Data source", ds.caption, "placeholder", f"Reading extract failed: {e}")
            return
        if not exported:
            return
        logical = {re.sub(r"\$$", "", n).lower(): n for n in ds.tables}
        matched = [(e, logical.get(e["name"].lower())) for e in exported if e["name"].lower() in logical]
        if not matched:   # single flattened extract (joins/relationships already applied)
            big = max(exported, key=lambda e: e["rows"])
            base = next(iter(ds.tables), ds.caption)
            matched = [(big, base)]
            flattened = True
        else:
            flattened = False
        new_tables, new_conns, used_fields = {}, {}, set()
        for e, tname in matched:
            tname = re.sub(r"\$$", "", tname) or tname
            cols = {c: typ for c, typ in e["columns"]}
            cname = f"__extract__{tname}"
            new_conns[cname] = Connection(cname, "hyper-csv", filename=e["file"], resolved_path=e["csv"])
            new_tables[tname] = SourceTable(tname, cname, "table", source=e["file"])
            taken = set()
            candidates = ds.fields.values() if flattened else [
                f for f in ds.fields.values() if re.sub(r"\$$", "", f.table) == tname]
            for f in candidates:
                col = f.key if f.key in cols else (f.remote_name if f.remote_name in cols else None)
                if col is None or col in taken or f.key in used_fields:
                    continue
                taken.add(col)
                used_fields.add(f.key)
                f.table, f.remote_name = tname, col
                f.datatype = f.datatype or cols[col]
            self.plan.log("Data source", tname, "note",
                          f"Data exported from Tableau extract '{os.path.basename(local)}' "
                          f"({e['rows']:,} rows) to {e['file']}. It is a snapshot; repoint the path "
                          f"parameter or the source step to the live data when available. {ds.extract_note}".strip())
        dropped = [k for k in ds.fields if k not in used_fields]
        for k in dropped:
            del ds.fields[k]
        if dropped:
            ds.notes.append(f"{len(dropped)} field(s) are not in the extract (unused in Tableau) and were left out: "
                            + ", ".join(sorted(dropped)[:12]) + (" ..." if len(dropped) > 12 else ""))
        if flattened and ds.relationships:
            ds.notes[:] = [n for n in ds.notes if not n.startswith("Physical ")]
            ds.notes.append("Joins/relationships were already applied inside the extract; the model uses one table.")
            ds.relationships = []
        ds.tables, ds.connections = new_tables, new_conns

    def note_published(self, ds):
        pub = ds.published
        if not pub:
            return
        self.plan.published.append(pub)
        label = pub["key"] or pub["name"]
        if self.wb.kind == "datasource":
            detail = (f"This is the Tableau published data source '{label}'. Publish this model once and "
                      "connect every report that used the data source to it.")
        else:
            detail = (f"Uses the Tableau published data source '{label}'. Its calculated fields live on "
                      "Tableau Server, so some may be missing here: export it as .tdsx, convert it into one "
                      "shared semantic model, and connect this report to that model.")
        self.plan.log("Data source", ds.caption, "note", detail, result=f"key: {label}")

    def map_datasource(self, ds):
        self.note_published(ds)
        for st in ds.tables.values():
            tname = self.table_name(ds, st.name)
            conn = ds.connections.get(st.connection) or next(iter(ds.connections.values()), None)
            t = MTable(tname)
            self.plan.tables[tname] = t
            self.ds_of_table[tname] = ds.name
            fields = [f for f in ds.fields.values() if f.table == st.name]
            used = set()
            for f in fields:
                disp = f.display
                if disp in used:
                    disp = f"{disp} ({f.remote_name})"
                used.add(disp)
                fmt, cur = tableau_format(f.default_format, f.datatype)
                col = MColumn(disp, TMDL_TYPE.get(f.datatype, "string"), source_column=disp,
                              hidden=f.hidden, category=GEO_ROLES.get(f.semantic_role, ""),
                              summarize="sum" if f.role == "measure" and f.datatype in ("integer", "real") else "none")
                if f.datatype in ("integer", "real"):
                    col.fmt = fmt or default_format(f.datatype)
                elif f.datatype in ("date", "datetime"):
                    col.fmt = "Short Date" if f.datatype == "date" else "General Date"
                t.columns[disp] = col
                t.select_cols.append((f.remote_name, disp, f.datatype))
                self.plan.field_map[(ds.name, f.key)] = Ref("column", disp, tname, SIMPLE_TYPE.get(f.datatype, "unknown"))
                if f.semantic_role and not col.category:
                    self.plan.log("Model", f"{tname}[{disp}]", "note",
                                  f"Geographic role {f.semantic_role} has no Power BI data category.")
            self.build_source(ds, st, conn, t)

    def build_source(self, ds, st, conn, t):
        cls = conn.cls if conn else ""
        cols = t.select_cols
        src = st.source
        # Debug: log packaged files and connection info
        if self.log_fn and hasattr(self.wb, 'packaged_files'):
            self.log_fn(f"  [DEBUG] build_source for {t.name}: cls={cls}")
            self.log_fn(f"  [DEBUG] packaged_files keys: {list(self.wb.packaged_files.keys())}")
            if conn:
                self.log_fn(f"  [DEBUG] conn.filename={conn.filename}, conn.directory={conn.directory}")
        if cls == "hyper-csv":
            p = self.path_param(conn.resolved_path, conn.filename, "")
            t.m_source = [f'Source = Csv.Document(File.Contents({p}), [Delimiter=",", Encoding=65001, '
                          'QuoteStyle=QuoteStyle.Csv])',
                          '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true])']
            t.source_kind = "csv"
            self.source_info[t.name] = ("csv", conn.resolved_path, conn.filename)
            t.source_note = f"CSV {conn.filename} (from Tableau extract)"
            self.plan.log("Data source", t.name, "converted", t.source_note)
            return
        if cls == "excel-direct" and not conn.filename:
            self.plan.log("Data source", t.name, "placeholder",
                          "The workbook doesn't store the Excel file path. Set the path parameter "
                          "to the file before refreshing.")
        if cls == "excel-direct":
            local = resolve_data_file(self.wb, conn.filename, conn.directory, self.data_dirs) if conn.filename else ""
            if self.log_fn:
                self.log_fn(f"  [DEBUG] excel-direct resolved local={local}")
                if not local and conn.filename:
                    self.log_fn(f"  [DEBUG]   File NOT found! Searched: packaged_files, original path, data_dirs={self.data_dirs}")
            p = self.path_param(local, conn.filename or f"{ds.caption}.xlsx", "")
            sheet = profiler.safe_sheet(src)
            kind = "Sheet" if src.rstrip("]").endswith("$") else "DefinedName"
            t.m_source = [f"Source = Excel.Workbook(File.Contents({p}), null, true)",
                          f'Data = Source{{[Item={m_str(sheet)},Kind="{kind}"]}}[Data]',
                          '#"Promoted Headers" = Table.PromoteHeaders(Data, [PromoteAllScalars=true])']
            t.source_kind = "excel"
            self.source_info[t.name] = ("excel", local, sheet)
            t.source_note = f"Excel {os.path.basename(conn.filename)} / {sheet}"
        elif cls == "textscan":
            fname = strip_brackets(src).replace("#", ".") if src else conn.filename
            local = resolve_data_file(self.wb, fname, conn.directory, self.data_dirs)
            if self.log_fn:
                self.log_fn(f"  [DEBUG] textscan fname={fname}, resolved local={local}")
                if not local:
                    self.log_fn(f"  [DEBUG]   File NOT found! Searched: packaged_files, original path, data_dirs={self.data_dirs}")
            original = (conn.directory.rstrip("/\\") + "/" + fname) if conn.directory else fname
            p = self.path_param(local, original, "")
            t.m_source = [f'Source = Csv.Document(File.Contents({p}), [Delimiter=",", Encoding=65001, '
                          'QuoteStyle=QuoteStyle.Csv])',
                          '#"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true])']
            t.source_kind = "csv"
            self.source_info[t.name] = ("csv", local, fname)
            t.source_note = f"CSV {fname}"
        elif cls == "sqlserver":
            if st.kind == "sql":
                t.m_source = [f"Source = Sql.Database({m_str(conn.server)}, {m_str(conn.dbname)}, "
                              f"[Query={m_str(st.sql)}])",
                              '#"Promoted Headers" = Source']
            else:
                parts = [strip_brackets(x) for x in re.findall(r"\[[^\]]+\]", src)] or [src]
                schema, item = (parts[-2], parts[-1]) if len(parts) > 1 else ("dbo", parts[-1])
                t.m_source = [f"Source = Sql.Database({m_str(conn.server)}, {m_str(conn.dbname)})",
                              f"Data = Source{{[Schema={m_str(schema)},Item={m_str(item)}]}}[Data]",
                              '#"Promoted Headers" = Data']
            t.source_kind = "sqlserver"
            t.source_note = f"SQL Server {conn.server}/{conn.dbname}"
        elif cls == "databricks":
            http_path = conn.attr("http-path", "v-http-path", "httppath", "http_path")
            catalog, schema, table = databricks_target(conn, src)
            if not http_path:
                self.plan.log("Data source", t.name, "note",
                              "The workbook doesn't store the Databricks HTTP path. Take it from Databricks "
                              "SQL > your warehouse > Connection details and put it in the "
                              "Databricks.Catalogs step before refreshing.")
            if not catalog:
                catalog = DATABRICKS_DEFAULT_CATALOG
                self.plan.log("Data source", t.name, "note",
                              f"The workbook names no catalog, so '{DATABRICKS_DEFAULT_CATALOG}' is used. "
                              "Change it in Power Query if the table lives in a Unity Catalog catalog.")
            if not schema:
                schema = DATABRICKS_DEFAULT_SCHEMA
                self.plan.log("Data source", t.name, "note",
                              f"The workbook names no schema, so '{DATABRICKS_DEFAULT_SCHEMA}' is used.")
            # Argument order, options record and Kind navigation follow the Azure Databricks
            # connector as documented by Microsoft; Implementation="2.0" selects the ADBC driver,
            # the default for new connections since February 2026.
            steps = [f"Source = Databricks.Catalogs({m_str(conn.server)}, {m_str(http_path)}, "
                     f"[Catalog={m_str(catalog)}, Database={m_str(schema)}, "
                     'EnableAutomaticProxyDiscovery=null, Implementation="2.0"])',
                     f'Catalog = Source{{[Name={m_str(catalog)},Kind="Database"]}}[Data]']
            if st.kind == "sql":
                steps += [f"Data = Value.NativeQuery(Catalog, {m_str(st.sql)}, null, [EnableFolding=true])"]
                self.plan.log("Data source", t.name, "note",
                              "Tableau custom SQL became a Databricks native query, which must be written "
                              f"relative to catalog '{catalog}'. Check it returns and folds on first refresh.")
                t.source_note = f"Databricks {conn.server} {catalog} (custom SQL)"
            else:
                steps += [f'Schema = Catalog{{[Name={m_str(schema)},Kind="Schema"]}}[Data]',
                          f'Data = Schema{{[Name={m_str(table)},Kind="Table"]}}[Data]']
                t.source_note = f"Databricks {conn.server} {catalog}.{schema}.{table}"
            t.m_source = steps + ['#"Promoted Headers" = Data']
            t.source_kind = "databricks"
        else:
            typed = ", ".join(f"{m_name(r)} = {M_TABLE_TYPE.get(d, 'text')}" for r, _, d in cols)
            t.m_source = [f"// TODO: Tableau connection '{cls or 'unknown'}' was not converted. "
                          "Replace this step with the real source.",
                          f"Source = #table(type table [{typed}], {{}})",
                          '#"Promoted Headers" = Source']
            t.source_kind = "placeholder"
            t.source_note = f"Unsupported connection '{cls}'"
            if cls == "sqlproxy":
                why = ("Published Tableau data source with no local data: point this table at the shared "
                       "semantic model or the underlying database; it is empty until then.")
            else:
                why = f"Connection type '{cls}' needs a manual Power Query source; table is empty until then."
            self.plan.log("Data source", t.name, "placeholder", why)
            return
        self.plan.log("Data source", t.name, "converted", t.source_note)

    def load_frames(self):
        if not self.profile:
            return
        for tname, (kind, local, src) in self.source_info.items():
            t = self.plan.tables[tname]
            df = profiler.load_table(kind, local, src, [r for r, _, _ in t.select_cols], self.row_limit)
            if df is not None:
                df = df.rename(columns={r: d for r, d, _ in t.select_cols})
                self.plan.frames[tname] = df

    # ------------------------------------------------------------------ relationships
    def map_relationships(self, ds):
        for rel in ds.relationships:
            lt = self.plan.field_map[(ds.name, rel.pairs[0][0])].table
            rt = self.plan.field_map[(ds.name, rel.pairs[0][1])].table
            if len(rel.pairs) == 1:
                lc = self.plan.field_map[(ds.name, rel.pairs[0][0])].name
                rc = self.plan.field_map[(ds.name, rel.pairs[0][1])].name
            else:
                lc, rc = self.composite_key(ds, lt, rt, rel.pairs)
            lu = self.unique(lt, lc)
            ru = self.unique(rt, rc)
            m2m = False
            if ru is True:
                r = MRelationship(lt, lc, rt, rc, evidence=f"{rt}[{rc}] is unique in the data")
            elif lu is True:
                r = MRelationship(rt, rc, lt, lc, evidence=f"{lt}[{lc}] is unique in the data")
            elif ru is None:
                r = MRelationship(lt, lc, rt, rc,
                                  evidence="No data to check; assumed many-to-one. Refresh fails if the key "
                                           f"{rt}[{rc}] is not unique.")
            else:
                m2m = True
                r = MRelationship(lt, lc, rt, rc, many_to_many=True,
                                  evidence="Neither key is unique in the data; created as many-to-many.")
            if any(x.to_table == r.to_table and x.from_table == r.from_table for x in self.plan.relationships):
                self.plan.log("Relationship", f"{lt} - {rt}", "skipped",
                              "Duplicate path between the same tables; Power BI allows one active relationship.")
                continue
            self.plan.relationships.append(r)
            self.plan.log("Relationship", f"{r.from_table}[{r.from_col}] -> {r.to_table}[{r.to_col}]",
                          "note" if m2m or ru is None else "converted", r.evidence)

    def unique(self, table, col):
        df = self.plan.frames.get(table)
        if df is None:
            return None
        if col not in df.columns:
            c = self.plan.tables[table].columns.get(col)
            if c and c.pandas_fn:
                self.plan.derive_all(table, df)
            if col not in df.columns:
                return None
        return profiler.key_is_unique(df, col)

    def composite_key(self, ds, lt, rt, pairs):
        names = []
        for side, table in ((0, lt), (1, rt)):
            cols = [self.plan.field_map[(ds.name, p[side])].name for p in pairs]
            key = "Key " + " + ".join(cols)
            t = self.plan.tables[table]
            expr = " & \"|\" & ".join(f"Text.From([{c}])" for c in cols)
            t.m_extra.append((f"Added {key}", f'Table.AddColumn({{prev}}, {m_str(key)}, each {expr}, type text)'))
            t.columns[key] = MColumn(key, "string", source_column=key, hidden=True,
                                     description="Composite relationship key (Tableau multi-field relationship)",
                                     pandas_fn=lambda *s: s[0].astype(str).str.cat([x.astype(str) for x in s[1:]], sep="|"),
                                     pandas_inputs=cols)
            names.append(key)
        return names[0], names[1]

    # ------------------------------------------------------------------ data blending
    def _sheet_uses(self, ws):
        uses = list(ws.rows) + list(ws.cols) + [u for _, u in ws.encodings] + list(ws.measure_values)
        return uses + [f.use for f in ws.filters]

    def _common_dimensions(self, dsa, dsb):
        """Dimension fields with the same display name in both data sources: Tableau's default,
        automatic blend-linking rule. A manual "Edit Blend Relationships" override isn't reliably
        represented in the workbook XML, so it can't be detected — only this default is."""
        def dims(ds):
            out = {}
            for f in ds.fields.values():
                if f.role == "dimension" and not f.hidden:
                    out.setdefault(f.display.strip().lower(), []).append(f)
            return out
        da, db = dims(dsa), dims(dsb)
        return [(da[k][0], db[k][0]) for k in da if k in db and len(da[k]) == 1 and len(db[k]) == 1]

    def map_blends(self):
        """Tableau "blending": a worksheet mixing fields from 2+ data sources, joined at query
        time (not in the model), on same-named dimensions. This has no equivalent in Power BI's
        model-level relationships, so it's translated into a real relationship (Strategy A) only
        when there is exactly one unambiguous linking field AND profiled data proves one side of
        it is unique (the same safety bar map_relationships already applies to relationships the
        workbook declares outright). Anything less certain gets a confidence score, a specific
        reason, and a recommended manual strategy — never a guessed relationship. A wrong
        automatic join would silently produce wrong numbers, which is worse than a placeholder
        (CLAUDE.md's "never fail silently"). Every blend found is logged to Plan area "Blend"
        (reporting.py builds a dedicated "Data blending" section from it) whether or not it could
        be auto-connected; a built relationship is *also* logged to "Relationship" so it's counted
        and listed there like any other relationship.
        """
        uses_by_ws = {ws.name: self._sheet_uses(ws) for ws in self.wb.worksheets.values()}
        pairs, usage_count = {}, Counter()
        for ws_name, uses in uses_by_ws.items():
            dss = {u.datasource for u in uses if u.datasource in self.wb.datasources}
            for dsn in dss:
                usage_count[dsn] += 1
            for a, b in itertools.combinations(sorted(dss), 2):
                pairs.setdefault((a, b), []).append(ws_name)
        for (a_name, b_name), sheets in sorted(pairs.items()):
            dsa, dsb = self.wb.datasources[a_name], self.wb.datasources[b_name]
            primary, secondary = (dsa, dsb) if usage_count[a_name] >= usage_count[b_name] else (dsb, dsa)
            where = ", ".join(sheets)
            common = self._common_dimensions(dsa, dsb)
            key = f"{a_name}::{b_name}"
            if not common:
                self.plan.log("Blend", where, "placeholder",
                              "MIGRATION WARNING: Tableau data blend detected but could not be safely "
                              f"converted. Primary (inferred): '{primary.caption}'. Secondary (inferred): "
                              f"'{secondary.caption}'. Reason: they share no dimension with a matching name, "
                              "so no linking field could be found. Remediation: open the original workbook's "
                              "Data menu > Edit Blend Relationships to find the real link, then build the "
                              "relationship manually.",
                              source=f"{primary.caption} (primary) + {secondary.caption} (secondary)",
                              result="Confidence: 20% (Low) — do not auto-convert", key=key)
                self.plan.blends.append({"worksheet": where, "primary": primary.caption,
                                         "secondary": secondary.caption, "linking_fields": "None found",
                                         "confidence": 20, "relationship_created": False, "status": "WARNING",
                                         "detail": "No dimension shared by both data sources with a matching name."})
                continue
            if len(common) > 1:
                names = ", ".join(fa.display for fa, _ in common)
                self.plan.log("Blend", where, "placeholder",
                              "MIGRATION WARNING: Tableau data blend detected but could not be safely "
                              f"converted. Primary (inferred): '{primary.caption}'. Secondary (inferred): "
                              f"'{secondary.caption}'. Reason: {len(common)} dimensions match by name "
                              f"({names}), so which one Tableau's blend actually used is ambiguous. "
                              "Remediation: build the relationship manually on the correct field.",
                              source=f"{primary.caption} (primary) + {secondary.caption} (secondary)",
                              result="Confidence: 65% (Medium) — manual review recommended", key=key)
                self.plan.blends.append({"worksheet": where, "primary": primary.caption,
                                         "secondary": secondary.caption, "linking_fields": names,
                                         "confidence": 65, "relationship_created": False, "status": "WARNING",
                                         "detail": f"{len(common)} same-named dimensions match; the real one is ambiguous."})
                continue
            fa, fb = common[0]
            ref_a, ref_b = self.plan.field_map.get((a_name, fa.key)), self.plan.field_map.get((b_name, fb.key))
            link = fa.display if fa.display == fb.display else f"{fa.display} / {fb.display}"
            if not ref_a or not ref_b or ref_a.kind != "column" or ref_b.kind != "column":
                continue
            if self.plan.related(ref_a.table, ref_b.table):
                continue   # already connected some other way
            au, bu = self.unique(ref_a.table, ref_a.name), self.unique(ref_b.table, ref_b.name)
            if au is True or bu is True:
                if bu is True and au is not True:
                    r = MRelationship(ref_a.table, ref_a.name, ref_b.table, ref_b.name,
                                      evidence=f"{ref_b.table}[{ref_b.name}] is unique in the data")
                else:
                    r = MRelationship(ref_b.table, ref_b.name, ref_a.table, ref_a.name,
                                      evidence=f"{ref_a.table}[{ref_a.name}] is unique in the data")
                confidence = "98% (High) — exact matching key field" if fa.display == fb.display else \
                             "88% (High) — strong inferred match (names differ by case)"
                self.plan.relationships.append(r)
                self.plan.log("Relationship", f"{r.from_table}[{r.from_col}] -> {r.to_table}[{r.to_col}]",
                              "converted",
                              f"Inferred from a Tableau data blend between '{dsa.caption}' and '{dsb.caption}' "
                              f"(matching dimension '{link}'). {r.evidence}. Verify this is the field Tableau's "
                              "own blend used (Data menu > Edit Blend Relationships) if numbers look off.",
                              key=key)
                self.plan.log("Blend", where, "converted",
                              f"Primary (inferred): '{primary.caption}'. Secondary (inferred): "
                              f"'{secondary.caption}'. Linked on '{link}'. Strategy A (Power BI relationship): "
                              f"{r.from_table}[{r.from_col}] -> {r.to_table}[{r.to_col}], "
                              f"cross-filter single direction. {r.evidence}.",
                              source=f"{primary.caption} (primary) + {secondary.caption} (secondary)",
                              result=f"Confidence: {confidence}", key=key)
                self.plan.blends.append({"worksheet": where, "primary": primary.caption,
                                         "secondary": secondary.caption, "linking_fields": link,
                                         "confidence": int(confidence.split("%")[0]), "relationship_created": True,
                                         "status": "PASS",
                                         "detail": f"Relationship built: {r.from_table}[{r.from_col}] -> "
                                                   f"{r.to_table}[{r.to_col}]. {r.evidence}."})
                continue
            reason = ("neither side is unique in the profiled data (a true many-to-many blend, which Tableau "
                      "resolves by aggregating each side before joining — a plain relationship can't "
                      "replicate that)" if au is False and bu is False else
                      "the data wasn't read (profiling is off), so this can't be checked")
            lookup_hint = (f"If '{secondary.caption}' is a small lookup table (its measures are never "
                           f"independently aggregated elsewhere), add a measure instead of a relationship: "
                           f"LOOKUPVALUE ( '{ref_b.table}'[<measure column>], '{ref_b.table}'[{ref_b.name}], "
                           f"'{ref_a.table}'[{ref_a.name}] ). If it does have independent aggregations, "
                           f"confirm '{link}' is really unique in '{secondary.caption}' before relating it.")
            self.plan.log("Blend", where, "placeholder",
                          "MIGRATION WARNING: Tableau data blend detected but could not be safely converted. "
                          f"Primary (inferred): '{primary.caption}'. Secondary (inferred): '{secondary.caption}'. "
                          f"Candidate link: {ref_a.table}[{ref_a.name}] <-> {ref_b.table}[{ref_b.name}]. "
                          f"Reason: {reason}. Strategy C (DAX) instead of a relationship: {lookup_hint}",
                          source=f"{primary.caption} (primary) + {secondary.caption} (secondary)",
                          result="Confidence: 30% (Low) — do not auto-convert", key=key)
            self.plan.blends.append({"worksheet": where, "primary": primary.caption,
                                     "secondary": secondary.caption,
                                     "linking_fields": f"{ref_a.table}[{ref_a.name}] <-> {ref_b.table}[{ref_b.name}]",
                                     "confidence": 30, "relationship_created": False, "status": "WARNING",
                                     "detail": reason})

    # ------------------------------------------------------------------ parameters
    def map_parameters(self):
        for p in self.wb.parameters.values():
            dtype = SIMPLE_TYPE.get(p.datatype, "string")
            mname = self.plan.unique_measure_name(f"{p.caption} Value")
            default = dax_literal(p.value, p.datatype)
            numeric = p.datatype in ("integer", "real")
            if p.domain == "range" and numeric and p.min is not None and p.max is not None:
                tname = self.unique_table(p.caption)
                t = MTable(tname, kind="calculated", is_parameter=True,
                           dax_source=f"GENERATESERIES ( {p.min}, {p.max}, {p.step or 1} )",
                           description=f"Tableau parameter '{p.caption}' (range {p.min} to {p.max}, step {p.step})")
                col = MColumn(p.caption, "int64" if p.datatype == "integer" else "double",
                              source_column="[Value]", inferred=True,
                              fmt="0" if p.datatype == "integer" else "#,0.00")
                t.columns[p.caption] = col
                self.plan.tables[tname] = t
                expr = f"SELECTEDVALUE ( {qcol(tname, p.caption)}, {default} )"
                self.plan.add_measure(tname, MMeasure(mname, expr, col.fmt, folder=""))
                self.plan.field_map[("Parameters", p.key)] = Ref("param", mname, tname, dtype)
                self.plan.log("Parameter", p.caption, "converted", "What-if table + selected-value measure",
                              result=f"{tname}[{p.caption}], [{mname}]", key=p.key)
            elif p.domain == "list" and p.members:
                tname = self.unique_table(p.caption)
                items = ", ".join(dax_literal(v) for v in p.members)
                t = MTable(tname, kind="calculated", is_parameter=True, dax_source=f"{{ {items} }}",
                           description=f"Tableau list parameter '{p.caption}'")
                t.columns[p.caption] = MColumn(p.caption, TMDL_TYPE.get(p.datatype, "string"),
                                               source_column="[Value]", inferred=True)
                self.plan.tables[tname] = t
                expr = f"SELECTEDVALUE ( {qcol(tname, p.caption)}, {default} )"
                self.plan.add_measure(tname, MMeasure(mname, expr, "#,0.00" if numeric else ""))
                self.plan.field_map[("Parameters", p.key)] = Ref("param", mname, tname, dtype)
                self.plan.log("Parameter", p.caption, "converted", "List table + selected-value measure",
                              result=f"{tname}[{p.caption}], [{mname}]", key=p.key)
            else:
                self.pending_param_measures = getattr(self, "pending_param_measures", [])
                self.pending_param_measures.append((mname, default, p))
                self.plan.field_map[("Parameters", p.key)] = Ref("param", mname, "", dtype)
                self.plan.log("Parameter", p.caption, "note",
                              f"'{p.domain}' parameter has no slicer equivalent; measure returns the default {default}.",
                              result=f"[{mname}]", key=p.key)

    def unique_table(self, name):
        n, i = name, 2
        while n in self.plan.tables:
            n = f"{name} ({i})"
            i += 1
        return n

    def home_table(self):
        best = None
        for t in self.plan.tables.values():
            if t.is_parameter:
                continue
            if best is None or len(t.columns) > len(best.columns):
                best = t
        return best.name if best else None

    # ------------------------------------------------------------------ groups & bins
    def map_groups_and_bins(self, ds):
        for c in ds.calcs.values():
            if c.cls == "categorical-bin":
                gkey = f"{ds.name}::{c.key}"
                src = self.plan.field_map.get((ds.name, c.source_field))
                if not src or src.kind != "column":
                    self.plan.log("Group", c.caption, "skipped", f"Source field {c.source_field} not found", key=gkey)
                    continue
                t = self.plan.tables[src.table]
                ename = safe_ident("Map_" + c.caption, "Map")
                rows = [[str(k), str(v)] for k, v in c.bins.items() if k is not None]
                self.plan.expressions.append(MExpression(ename, enter_data_m(rows, ["Member", "Group"]), "query",
                                                         f"Tableau group '{c.caption}' on {c.source_field}"))
                name = c.caption if c.caption not in t.columns else f"{c.caption} (group)"
                src_col = src.name
                t.m_extra += [
                    (f"Merged {name}", f"Table.NestedJoin({{prev}}, {{{m_str(src_col)}}}, {ename}, "
                                       f'{{"Member"}}, "__map", JoinKind.LeftOuter)'),
                    (f"Expanded {name}", 'Table.ExpandTableColumn({prev}, "__map", {"Group"}, {"__group"})'),
                    (f"Added {name}", f"Table.AddColumn({{prev}}, {m_str(name)}, each if [__group] = null "
                                      f"then [{src_col}] else [__group], type text)"),
                    (f"Removed helper {name}", 'Table.RemoveColumns({prev}, {"__group"})'),
                ]
                t.columns[name] = MColumn(name, "string", source_column=name,
                                          description=f"Tableau group on {src.name}; ungrouped members keep their own value.",
                                          pandas_fn=profiler.pd_group({str(k): str(v) for k, v in c.bins.items()})
                                          if profiler.available() else None,
                                          pandas_inputs=[src.name])
                self.plan.field_map[(ds.name, c.key)] = Ref("column", name, t.name, "string")
                self.plan.log("Group", c.caption, "converted",
                              f"{len(set(c.bins.values()))} groups over {len(c.bins)} members, merged in Power Query",
                              result=f"{t.name}[{name}]", key=gkey)
            elif c.cls == "bin":
                bkey = f"{ds.name}::{c.key}"
                src = self.plan.field_map.get((ds.name, c.source_field))
                if not src or src.kind != "column":
                    self.plan.log("Bin", c.caption, "skipped", f"Source field {c.source_field} not found", key=bkey)
                    continue
                size = c.bin_size
                note = ""
                if c.bin_size_param:
                    p = self.wb.parameters.get(c.bin_size_param)
                    size = p.value if p else None
                    note = (f"Bin size uses parameter '{p.caption}' default ({size}); calculated columns "
                            "don't respond to slicers.") if p else ""
                if not size:
                    self.plan.log("Bin", c.caption, "skipped", "Bin size not found", key=bkey)
                    continue
                size = int(size) if float(size).is_integer() else size
                t = self.plan.tables[src.table]
                q = qcol(t.name, src.name)
                expr = f"INT ( {q} / {size} ) * {size}"
                if c.peg:
                    expr = f"INT ( ( {q} - {c.peg} ) / {size} ) * {size} + {c.peg}"
                name = c.caption if c.caption not in t.columns else f"{c.caption} (bin)"
                t.columns[name] = MColumn(name, "int64" if isinstance(size, int) and not c.peg else "double",
                                          expression=expr, fmt="0", description=f"Tableau bin on {src.name}, size {size}",
                                          pandas_fn=profiler.pd_bin(size) if profiler.available() else None,
                                          pandas_inputs=[src.name])
                self.plan.field_map[(ds.name, c.key)] = Ref("rowcalc", name, t.name, "number")
                self.plan.log("Bin", c.caption, "converted", note or f"Static bin size {size}", result=f"{t.name}[{name}]",
                              key=bkey)

    # ------------------------------------------------------------------ calculations
    def resolver(self, ds):
        def resolve(dsn, name):
            if dsn == "Parameters" or (dsn is None and ("Parameters", name) in self.plan.field_map
                                       and (ds.name, name) not in self.plan.field_map):
                ref = self.plan.field_map.get(("Parameters", name))
                if ref:
                    return ref
                raise Unsupported(f"Unknown parameter {name}")
            key = (dsn if dsn and dsn in self.wb.datasources else ds.name, name)
            if key in self.plan.field_map:
                return self.plan.field_map[key]
            for (d, k), ref in self.plan.field_map.items():   # formulas sometimes use captions
                if d == key[0] and ref.name == name:
                    return ref
            raise Unsupported(f"Field [{name}] is not available (unconverted or unknown)")
        return Resolver(resolve=resolve, related=self.plan.related)

    def catalog(self):
        tables = {}
        for t in self.plan.tables.values():
            tables[t.name] = {"columns": list(t.columns), "measures": [m.name for m in t.measures]}
        return {"tables": tables,
                "measures": [m for t in self.plan.tables.values() for m in (x.name for x in t.measures)],
                "parameter_measures": [r.name for (d, k), r in self.plan.field_map.items() if r.kind == "param"],
                "relationships": [f"{r.from_table}[{r.from_col}] (many) -> {r.to_table}[{r.to_col}] (one)"
                                  for r in self.plan.relationships]}

    def map_calcs(self, ds):
        for mname, default, p in getattr(self, "pending_param_measures", []):
            home = self.home_table()
            if home and mname not in self.plan.measure_by_name:
                self.plan.add_measure(home, MMeasure(mname, default, "", description=f"Tableau parameter '{p.caption}'"))
        calcs = {k: c for k, c in ds.calcs.items() if c.cls == "tableau"}
        order = topo_order(calcs)
        res = self.resolver(ds)
        for key in order:
            c = calcs[key]
            formula = c.formula.replace("\r", "")
            try:
                tr = translate(formula, res)
                self.add_calc(ds, c, tr.kind, tr.dax, tr.table, "rule", "; ".join(tr.notes), tr.constant)
                continue
            except SecurityFunction as e:
                # Never guess security logic via AI: skip straight to a placeholder, and log a
                # dedicated, loud "Security" item surfaced at the top of MIGRATION_REPORT.md
                # (reporting.write_report), separate from the ordinary per-calc bookkeeping below.
                self.log_fn(f"  ! {c.caption}: uses {e.func_name}() — likely row-level security, not converted")
                self.add_placeholder(ds, c, str(e))
                self.plan.log("Security", c.caption, "placeholder",
                              f"Uses Tableau's {e.func_name}(). This usually implements row-level security "
                              "and was not translated — build an equivalent Power BI RLS role manually.",
                              source=one_line(formula), result=e.func_name, key=f"{ds.name}::{c.key}")
                self.plan.security.append({"calc": c.caption, "function": e.func_name,
                                           "formula": one_line(formula)})
                continue
            except Unsupported as e:
                reason = str(e)
            if self.ai_on("formulas"):
                self.log_fn(f"    AI translating '{c.caption}' ({reason})")
                ai_res, why = self.ai.translate(c.caption, formula, self.catalog(), reason,
                                                self.sheet_usage(ds, key))
                if ai_res:
                    note = f"AI ({ai_res.confidence} confidence). {ai_res.notes} Rule engine: {reason}"
                    self.add_calc(ds, c, ai_res.kind, ai_res.dax, ai_res.table, "ai", note)
                    continue
                reason = f"{reason}; {why}"
            self.add_placeholder(ds, c, reason)

    def sheet_usage(self, ds, key):
        uses = []
        for ws in self.wb.worksheets.values():
            shelf = [("rows", u) for u in ws.rows] + [("cols", u) for u in ws.cols] + ws.encodings
            for where, u in shelf:
                if u.column == key:
                    uses.append(f"sheet '{ws.name}' {where} ({u.derivation})")
        return "; ".join(uses)

    def add_calc(self, ds, c, kind, dax, table, method, notes, constant=False):
        desc = f"Tableau: {one_line(c.formula)}"
        if kind == "measure":
            home = self.measure_home(dax) or self.home_table()
            name = self.plan.unique_measure_name(c.caption)
            fmt, cur = tableau_format(c.default_format, c.datatype)
            m = MMeasure(name, dax, fmt or ("#,0" if c.datatype == "integer" else "#,0.00"),
                         description=desc, folder="Calculations", status=method, currency=cur)
            if c.datatype == "string":
                m.fmt = ""
            self.plan.add_measure(home, m)
            self.plan.field_map[(ds.name, c.key)] = Ref("measure", name, home, SIMPLE_TYPE.get(c.datatype, "number"),
                                                        constant=constant)
            result = f"measure [{name}] in {home}"
        else:
            t = self.plan.tables[table]
            name = c.caption if c.caption not in t.columns and c.caption not in self.plan.measure_by_name \
                else f"{c.caption} (calc)"
            dtype = TMDL_TYPE.get(c.datatype, "string")
            t.columns[name] = MColumn(name, dtype, expression=dax, description=desc,
                                      fmt=default_format(c.datatype) if c.datatype in ("integer", "real") else "",
                                      hidden=c.hidden)
            self.plan.field_map[(ds.name, c.key)] = Ref("rowcalc", name, table, SIMPLE_TYPE.get(c.datatype, "unknown"))
            result = f"column {table}[{name}]"
        status = "converted" if method == "rule" else "ai"
        self.plan.log("Calculation", c.caption, status, notes, source=one_line(c.formula), result=f"{result}: {dax}",
                      key=f"{ds.name}::{c.key}")

    def measure_home(self, dax):
        m = re.search(r"'((?:[^']|'')+)'\[", dax)
        return m.group(1).replace("''", "'") if m and m.group(1).replace("''", "'") in self.plan.tables else None

    def add_placeholder(self, ds, c, reason):
        aggregate = bool(re.search(r"\b(SUM|AVG|COUNTD?|MIN|MAX|MEDIAN|ATTR|WINDOW_\w+|RUNNING_\w+|RANK\w*|"
                                   r"INDEX|LOOKUP|TOTAL)\s*\(|\{\s*(FIXED|INCLUDE|EXCLUDE)", c.formula, re.I))
        desc = f"TODO manual conversion. Tableau: {one_line(c.formula)}"
        if aggregate or c.role == "measure":
            home = self.home_table()
            name = self.plan.unique_measure_name(c.caption)
            self.plan.add_measure(home, MMeasure(name, "BLANK ()", "#,0.00", description=desc,
                                                 folder="Needs review", status="placeholder"))
            self.plan.field_map[(ds.name, c.key)] = Ref("measure", name, home, SIMPLE_TYPE.get(c.datatype, "number"))
            result = f"placeholder measure [{name}]"
        else:
            home = self.home_table()
            t = self.plan.tables[home]
            name = c.caption if c.caption not in t.columns else f"{c.caption} (calc)"
            t.columns[name] = MColumn(name, TMDL_TYPE.get(c.datatype, "string"), expression="BLANK ()",
                                      description=desc)
            self.plan.field_map[(ds.name, c.key)] = Ref("rowcalc", name, home, SIMPLE_TYPE.get(c.datatype, "unknown"))
            result = f"placeholder column {home}[{name}]"
        self.plan.log("Calculation", c.caption, "placeholder", reason, source=one_line(c.formula), result=result,
                      key=f"{ds.name}::{c.key}")

    # ------------------------------------------------------------------ sets
    def map_sets(self, ds):
        res = self.resolver(ds)
        for s in ds.sets.values():
            skey = f"{ds.name}::{s.key}"
            if s.kind == "topn":
                lvl = self.plan.field_map.get((ds.name, s.level))
                if not lvl or lvl.kind != "column":
                    self.plan.log("Set", s.caption, "skipped", f"Level field {s.level} not found", key=skey)
                    continue
                try:
                    order = translate(s.order_expr, res)
                    if order.kind != "measure":
                        raise Unsupported("order expression is not an aggregate")
                except Unsupported as e:
                    self.plan.log("Set", s.caption, "skipped", f"Order expression not converted: {e}", key=skey)
                    continue
                if s.count_param:
                    n = self.plan.field_map.get(("Parameters", s.count_param))
                    count = qmeasure(n.name) if n else "10"
                else:
                    count = str(s.count)
                col = qcol(lvl.table, lvl.name)
                direction = "DESC" if (s.end == "top") == (s.direction.upper() == "DESC") else "ASC"
                expr = "\n".join([
                    f"VAR _n = {count}",
                    "VAR _top =",
                    "    TOPN (",
                    "        _n,",
                    f"        ALL ( {col} ),",
                    f"        CALCULATE ( {order.dax}, ALLEXCEPT ( {qtable(lvl.table)}, {col} ) ),",
                    f"        {direction}",
                    "    )",
                    "RETURN",
                    "    IF (",
                    f"        HASONEVALUE ( {col} ),",
                    f"        IF ( VALUES ( {col} ) IN _top, 1, 0 )",
                    "    )"])
                name = self.plan.unique_measure_name(f"Is {s.caption}")
                self.plan.add_measure(lvl.table, MMeasure(
                    name, expr, "0", folder="Calculations",
                    description=f"Tableau set '{s.caption}': {s.end} N by {s.order_expr}. Use as a visual filter (is 1)."))
                self.plan.log("Set", s.caption, "converted", "Top N set became a flag measure (filter visuals where = 1)",
                              source=f"{s.end} N by {s.order_expr} over {s.level}", result=f"[{name}]", key=skey)
            elif s.kind == "members":
                lvl = self.plan.field_map.get((ds.name, s.level))
                if not lvl or lvl.kind != "column":
                    self.plan.log("Set", s.caption, "skipped", f"Level field {s.level} not found", key=skey)
                    continue
                t = self.plan.tables[lvl.table]
                items = ", ".join(dax_literal(v) for v in s.members)
                cond = f"{qcol(lvl.table, lvl.name)} IN {{ {items} }}"
                if s.exclude:
                    cond = f"NOT ( {cond} )"
                name = s.caption if s.caption not in t.columns else f"{s.caption} (set)"
                t.columns[name] = MColumn(name, "string", expression=f'IF ( {cond}, "In", "Out" )',
                                          description=f"Tableau set '{s.caption}'")
                self.plan.field_map[(ds.name, s.key)] = Ref("rowcalc", name, t.name, "string")
                self.plan.log("Set", s.caption, "converted", f"{len(s.members)} members -> In/Out column",
                              result=f"{t.name}[{name}]", key=skey)
            elif s.kind == "action":
                self.plan.log("Set", s.caption, "note", s.note, key=skey)
            else:
                self.plan.log("Set", s.caption, "skipped", s.note, key=skey)

    # ------------------------------------------------------------------ hierarchies
    def map_hierarchies(self, ds):
        """Explicit Tableau hierarchies (extract._read_hierarchies) become a real TMDL `hierarchy`
        object — available for drill-down on any visual, not just an inferred note on the one
        sheet that happened to stack the fields — but only when every level resolves to a
        column (not a measure) and all levels land on the *same* table: a Power BI hierarchy is a
        table-level object and can't span tables the way Tableau's field-picker can. Anything that
        doesn't hold is reported, never silently dropped."""
        for h in ds.hierarchies.values():
            hkey = f"{ds.name}::{h.key}"
            refs, problem = [], None
            for level_key in h.levels:
                ref = self.plan.field_map.get((ds.name, level_key))
                if not ref:
                    problem = f"level field '{level_key}' is not available (unconverted or unknown)"
                    break
                if ref.kind not in ("column", "rowcalc"):
                    problem = f"level '{level_key}' resolves to a {ref.kind}, not a column"
                    break
                refs.append(ref)
            if not problem:
                tables = {r.table for r in refs}
                if len(tables) > 1:
                    problem = (f"its levels span {len(tables)} tables ({', '.join(sorted(tables))}); a Power BI "
                              "hierarchy can only use columns from a single table")
            if problem:
                self.plan.log("Hierarchy", h.caption, "placeholder",
                              f"Tableau hierarchy not migrated: {problem}. Build it manually in Power BI "
                              "Desktop (Model view, drag fields onto a table to form a hierarchy) once the "
                              "underlying fields are available on one table.",
                              source=" > ".join(h.levels), key=hkey)
                continue
            table = self.plan.tables[refs[0].table]
            name = h.caption if h.caption not in {mh.name for mh in table.hierarchies} else f"{h.caption} (hierarchy)"
            table.hierarchies.append(MHierarchy(name, [r.name for r in refs]))
            levels_str = " > ".join(r.name for r in refs)
            self.plan.log("Hierarchy", h.caption, "converted",
                          f"{len(refs)}-level drill-down hierarchy on '{refs[0].table}', level order preserved.",
                          source=" > ".join(h.levels), result=f"{refs[0].table}: {levels_str}", key=hkey)

    # ------------------------------------------------------------------ field uses
    def use_ref(self, use: FieldUse):
        return self.plan.field_map.get((use.datasource, use.column))

    def ensure_measure(self, use: FieldUse, ref: Ref, notes):
        deriv = use.derivation
        if ref.kind in ("measure", "param"):
            return Projection("measure", ref.table, ref.name)
        if deriv in ("User", "Attribute", "TableCalc"):
            deriv = "Sum"
        if deriv not in AGG_DAX:
            notes.append(f"Aggregation {deriv} on {ref.name} not supported; used SUM.")
            deriv = "Sum"
        mname = AGG_NAME[deriv].format(ref.name)
        existing = self.plan.measure_by_name.get(mname)
        if existing and existing.recon == (deriv, ref.table, ref.name):
            return Projection("measure", ref.table, mname)
        mname = self.plan.unique_measure_name(mname)
        col = self.plan.tables[ref.table].columns.get(ref.name)
        fmt = "#,0" if deriv in ("Count", "CountD") else (col.fmt if col and col.fmt else "#,0.00")
        self.plan.add_measure(ref.table, MMeasure(
            mname, f"{AGG_DAX[deriv]} ( {qcol(ref.table, ref.name)} )", fmt,
            description=f"Tableau: {deriv.upper()}([{ref.name}])", folder="Base Measures",
            recon=(deriv, ref.table, ref.name) if col and not col.expression or (col and col.pandas_fn) else None,
            currency=fmt == CURRENCY))
        return Projection("measure", ref.table, mname)

    def ensure_datepart(self, use: FieldUse, ref: Ref, notes):
        spec = DATEPARTS.get(use.derivation)
        if not spec:
            if use.derivation not in ("None", "Day-Trunc", "Attribute"):
                notes.append(f"Date level {use.derivation} on {ref.name} not converted; used the date itself.")
            return Projection("column", ref.table, ref.name)
        name_t, expr_t, dtype, fmt, pd_kind = spec
        name = name_t.format(c=ref.name)
        t = self.plan.tables[ref.table]
        if name not in t.columns:
            t.columns[name] = MColumn(name, dtype, expression=expr_t.format(q=qcol(ref.table, ref.name)),
                                      fmt=fmt or "", description=f"Tableau {use.derivation} of {ref.name}",
                                      pandas_fn=profiler.pd_datepart(pd_kind) if pd_kind and profiler.available() else None,
                                      pandas_inputs=[ref.name])
            if use.derivation == "Month":
                label = f"{ref.name} Month"
                t.columns[label] = MColumn(label, "string", expression=f'FORMAT ( {qcol(ref.table, ref.name)}, "MMM" )',
                                           sort_by=name, description=f"Tableau MONTH of {ref.name}")
                t.columns[name].hidden = True
        if use.derivation == "Month":
            return Projection("column", ref.table, f"{ref.name} Month")
        return Projection("column", ref.table, name)

    def ensure_location(self, table, cols):
        cols = sorted(cols, key=lambda c: GEO_RANK.get(self.plan.tables[table].columns[c].category, 9))
        if len(cols) == 1:
            return cols[0]
        name = f"{cols[0]} Location"
        t = self.plan.tables[table]
        if name not in t.columns:
            expr = ' & ", " & '.join(qcol(table, c) for c in cols)
            t.columns[name] = MColumn(name, "string", expression=expr, category="Place",
                                      description="Combined geography for unambiguous map locations: " + ", ".join(cols),
                                      pandas_fn=profiler.pd_concat(len(cols)) if profiler.available() else None,
                                      pandas_inputs=cols)
        return name

    def classify(self, use: FieldUse, notes):
        """Return ('dim'|'measure'|'geo'|None, Projection or None)."""
        if use.generated in ("measure_values", "measure_names"):
            return use.generated, None
        if use.generated:
            return "geo", None
        ref = self.use_ref(use)
        if ref is None:
            notes.append(f"Field '{use.column}' not available in the model; skipped.")
            return None, None
        if use.table_calc or use.derivation == "TableCalc":
            notes.append(f"Table calculation on '{ref.name}' dropped; showing the base aggregation.")
        if ref.kind in ("measure", "param") or use.is_aggregate or use.derivation == "TableCalc":
            return "measure", self.ensure_measure(use, ref, notes)
        if ref.table and self.plan.tables[ref.table].columns.get(ref.name) and \
                self.plan.tables[ref.table].columns[ref.name].dtype == "dateTime":
            return "dim", self.ensure_datepart(use, ref, notes)
        return "dim", Projection("column", ref.table, ref.name)

    # ------------------------------------------------------------------ visuals
    def plan_visual(self, ws) -> VisualSpec:
        notes = list(ws.notes)
        spec = VisualSpec(ws.name, "tableEx", ws.title or ws.name, notes=notes)
        rows = [(self.classify(u, notes), u) for u in ws.rows]
        cols = [(self.classify(u, notes), u) for u in ws.cols]
        enc = [(k, self.classify(u, notes), u) for k, u in ws.encodings]
        dims_r = [p for (k, p), _ in rows if k == "dim"]
        meas_r = [p for (k, p), _ in rows if k == "measure"]
        dims_c = [p for (k, p), _ in cols if k == "dim"]
        meas_c = [p for (k, p), _ in cols if k == "measure"]
        has_mv = lambda shelf: any(k == "measure_values" for (k, _), _ in shelf)
        if has_mv(rows) or has_mv(cols):
            mv = [p for p in (self.classify(u, notes)[1] for u in ws.measure_values) if p and p.kind == "measure"]
            if not mv:
                notes.append("Measure Values has no measures selected; nothing to plot.")
            (meas_r if has_mv(rows) else meas_c).extend(mv)
        geo = any(k == "geo" for (k, _), _ in rows + cols)
        by = lambda kinds, what: [p for k, (c, p), _ in enc if k in kinds and c == what]
        color_d, color_m = by({"color"}, "dim"), by({"color"}, "measure")
        text_mv = any(k in ("text", "label") and c == "measure_values" for k, (c, _), _ in enc)
        size_m = by({"size", "wedge-size"}, "measure")
        text_m, text_d = by({"text", "label"}, "measure"), by({"text", "label"}, "dim")
        if text_mv:
            text_m += [p for p in (self.classify(u, notes)[1] for u in ws.measure_values) if p and p.kind == "measure"]
        tip_m = by({"tooltip"}, "measure")
        detail_d = by({"lod", "shape", "path"}, "dim")
        mark = ws.mark
        continuous_date = any(u.instance.endswith(":qk") and u.derivation.endswith("Trunc")
                              for _, u in rows + cols) or any(
            p.kind == "column" and self.col(p).dtype == "dateTime" for p in dims_r + dims_c)

        def uniq(ps):
            seen, out = set(), []
            for p in ps:
                if p is None:
                    continue
                k = (p.kind, p.table, p.name)
                if k not in seen:
                    seen.add(k)
                    out.append(p)
            return out

        if mark == "VizExtension":
            ext_dims, ext_meas = uniq(detail_d), uniq(by({"lod"}, "measure"))
            return self.plan_viz_extension(spec, ws, ext_dims, ext_meas, notes)
        if geo:
            geo_dims = [p for p in uniq(detail_d + color_d + text_d + dims_r + dims_c)
                        if p.kind == "column" and self.col(p).category in GEO_RANK]
            if not geo_dims:
                notes.append("Map uses custom latitude/longitude; converted to a table.")
            else:
                tables = {p.table for p in geo_dims}
                table = next(iter(tables))
                loc = self.ensure_location(table, [p.name for p in geo_dims if p.table == table])
                spec.vtype = "map"
                spec.roles["Category"] = [Projection("column", table, loc)]
                sz = uniq(size_m or color_m)
                if sz:
                    spec.roles["Size"] = sz[:1]
                series = [p for p in color_d if self.col(p).category not in GEO_RANK]
                if series:
                    spec.roles["Series"] = series[:1]
                if color_m and size_m:
                    notes.append("Map colour measure dropped (Power BI bubble map sizes by one measure).")
                return self.finish(spec, ws, text_m)
        if mark == "Pie":
            spec.vtype = "pieChart"
            spec.roles["Category"] = uniq(color_d or dims_r + dims_c or detail_d)[:1]
            spec.roles["Y"] = uniq(size_m or text_m or meas_r + meas_c)[:1]
            spec.objects = {"legend": {"show": "true", "position": "'Right'"}, "labels": {"show": "false"}}
            return self.finish(spec, ws, [])
        if meas_r and meas_c:
            spec.vtype = "scatterChart"
            spec.roles["Category"] = uniq(detail_d + color_d + dims_r + dims_c)
            spec.roles["X"] = meas_c[:1]
            spec.roles["Y"] = meas_r[:1]
            if size_m:
                spec.roles["Size"] = size_m[:1]
            return self.finish(spec, ws, [])
        if not meas_r and not meas_c:
            values_m = uniq(text_m + color_m + size_m + tip_m)
            if dims_r and dims_c and values_m:
                spec.vtype = "pivotTable"
                spec.roles["Rows"] = uniq(dims_r)
                spec.roles["Columns"] = uniq(dims_c)
                spec.roles["Values"] = values_m
            elif not dims_r and not dims_c and len(values_m) == 1 and not (color_d + detail_d + text_d):
                spec.vtype = "card"
                spec.roles["Values"] = values_m
            else:
                spec.vtype = "tableEx"
                spec.roles["Values"] = uniq(dims_r + dims_c + text_d + color_d + detail_d) + values_m
            if mark not in ("Automatic", "Text", "Square"):
                notes.append(f"Mark type {mark} without a measure axis shown as a {spec.vtype}.")
            return self.finish(spec, ws, [])
        horizontal = bool(meas_c)
        cats = uniq((dims_r if horizontal else dims_c) + (dims_c if horizontal else dims_r))
        if (dims_c if horizontal else dims_r):
            notes.append("Dimensions on the measure shelf (small multiples) folded into the axis; drill down to see them.")
        measures = uniq(meas_c if horizontal else meas_r)
        if mark == "Line" or (mark == "Automatic" and continuous_date):
            spec.vtype = "lineChart"
        elif mark == "Area":
            spec.vtype = "areaChart"
        elif mark in ("Bar", "Automatic"):
            spec.vtype = "clusteredBarChart" if horizontal else "clusteredColumnChart"
        else:
            spec.vtype = "clusteredBarChart" if horizontal else "clusteredColumnChart"
            notes.append(f"Mark type {mark} shown as a bar/column chart.")
        if cats:
            spec.roles["Category"] = [Projection(p.kind, p.table, p.name, i == 0) for i, p in enumerate(cats)]
            if len(cats) > 1:
                notes.append("Nested dimensions become a drill-down hierarchy (first level shown).")
        spec.roles["Y"] = measures
        if color_d:
            if len(measures) > 1:
                notes.append("Colour dimension dropped: Power BI can't combine a legend with several measures.")
            else:
                spec.roles["Series"] = color_d[:1]
        if color_m:
            notes.append("Colour by measure (gradient) not applied; add conditional formatting if needed.")
        if tip_m:
            spec.roles["Tooltips"] = uniq(tip_m)
        if text_m:
            spec.objects = {"labels": {"show": "true"}}
        return self.finish(spec, ws, [])

    def plan_viz_extension(self, spec, ws, dims, meas, notes):
        """Tableau Viz Extensions (Extensions API marks) place every field as a generic 'lod'
        encoding with no rows/cols shelf and no color/size/text role, so the ordinary shelf-based
        classification in plan_visual can't see them at all — before this, every extension-marked
        worksheet silently fell back to a table containing only its dimensions; measures were
        dropped entirely (nothing gathered them). Map the handful of extension types with an
        obvious Power BI equivalent (VIZ_EXTENSION_NATIVE) properly; everything else still becomes
        a real table/pivot with every field it used, plus a note naming the actual extension —
        never a guessed chart shape, and never silently missing the measures either.
        """
        label = extension_label(ws.extension_id)
        if ws.extension_id not in VIZ_EXTENSION_NATIVE or not meas:
            if dims and meas and len(meas) == 1 and len(dims) == 2:
                spec.vtype = "pivotTable"
                spec.roles["Rows"], spec.roles["Columns"], spec.roles["Values"] = [dims[0]], [dims[1]], meas
            else:
                spec.vtype = "tableEx"
                spec.roles["Values"] = dims + meas
            notes.append(f"Tableau '{label}' viz extension has no native Power BI equivalent; shown as a "
                         f"{spec.vtype} with every field it used. The extension's own visual design "
                         "(custom formatting, colours, layout) isn't reproduced.")
            return self.finish(spec, ws, [])
        if ws.extension_id == "com.tableau.extensions.kpi-card":
            spec.vtype = "card"
            spec.roles["Values"] = meas[:1]
            if dims:
                notes.append(f"Tableau '{label}' viz extension: only the measure is shown; a Power BI card "
                             "has no room for the extra context field(s) it also used.")
        else:
            if not dims:
                spec.vtype = "tableEx"
                spec.roles["Values"] = meas
                notes.append(f"Tableau '{label}' viz extension has no dimension field; shown as a table.")
                return self.finish(spec, ws, [])
            if ws.extension_id == "com.tableau.extensions.line":
                spec.vtype = "lineChart"
            elif ws.extension_id == "com.tableau.extensions.donut":
                spec.vtype = "donutChart"
                meas = meas[:1]
            else:   # bar
                horizontal = (ws.extension_config or {}).get("orientation") == "bar"
                spec.vtype = "clusteredBarChart" if horizontal else "clusteredColumnChart"
            spec.roles["Category"] = dims[:1]
            spec.roles["Y"] = meas
            if len(dims) > 1 and spec.vtype != "donutChart":
                spec.roles["Series"] = dims[1:2]
        notes.append(f"Converted from a Tableau '{label}' viz extension; the extension's own custom "
                     "formatting, colours and layout aren't reproduced — only its data.")
        return self.finish(spec, ws, [])

    def col(self, p):
        return self.plan.tables[p.table].columns.get(p.name) or MColumn(p.name, "string")

    def finish(self, spec, ws, extra_measures):
        spec.roles = OrderedDict((k, v) for k, v in spec.roles.items() if v)
        spec.action_filters = ws.action_filters
        for f in ws.filters:
            if f.kind == "unsupported":
                spec.notes.append(f.note)
                continue
            ref = self.use_ref(f.use)
            if not ref or ref.kind not in ("column", "rowcalc"):
                spec.notes.append(f"Filter on '{f.use.column}' skipped (field not a column).")
                continue
            if any(isinstance(v, tuple) for v in f.values):
                spec.notes.append(f"Filter on '{ref.name}' uses date values; not converted.")
                continue
            spec.filters.append((Projection("column", ref.table, ref.name), f.kind, f.values))
        if not spec.roles:
            spec.notes.append("Nothing to show after conversion; visual left empty.")
        source = f"mark {ws.mark}" + (f" ({ws.extension_id})" if ws.extension_id else "")
        self.plan.log("Visual", ws.name, "converted" if not spec.notes else "note",
                      "; ".join(dict.fromkeys(spec.notes)), source=source, result=spec.vtype)
        return spec

    # ------------------------------------------------------------------ pages
    def map_pages(self):
        placed = set()
        used_names = set()

        def page_name(s):
            n = safe_ident(s, "Page")[:40] or "Page"
            base, i = n, 2
            while n in used_names:
                n = f"{base}_{i}"
                i += 1
            used_names.add(n)
            return n

        for db in self.wb.dashboards:
            W, H = db.width, db.height
            page = Page(page_name(db.name), db.name, W, H)
            legend_note = False
            for z in db.zones:
                x, y = round(z.x / 100000 * W) + 4, round(z.y / 100000 * H) + 4
                w, h = max(round(z.w / 100000 * W) - 8, 20), max(round(z.h / 100000 * H) - 8, 20)
                if z.kind == "sheet":
                    spec = self.plan.specs.get(z.name)
                    if spec:
                        page.visuals.append(PlacedVisual(spec, x, y, w, h))
                        placed.add(z.name)
                elif z.kind == "filter":
                    ws = self.wb.worksheets.get(z.name)
                    proj = self.param_projection(z.param, ws)
                    if proj:
                        spec = VisualSpec(f"Filter {proj.name}", "slicer", proj.name, OrderedDict(Values=[proj]))
                        page.visuals.append(PlacedVisual(spec, x, y, w, h))
                elif z.kind == "paramctrl":
                    m = REF_RE.match(z.param)
                    ref = self.plan.field_map.get(("Parameters", strip_brackets(m.group(2)) if m else ""))
                    if ref and ref.table and self.plan.tables[ref.table].is_parameter:
                        col = next(iter(self.plan.tables[ref.table].columns))
                        spec = VisualSpec(f"Param {col}", "slicer", col,
                                          OrderedDict(Values=[Projection("column", ref.table, col)]),
                                          objects={"selection": {"singleSelect": "true"},
                                                   "data": {"mode": "'Dropdown'"}})
                        page.visuals.append(PlacedVisual(spec, x, y, w, h))
                    else:
                        page.notes.append(f"Parameter control {z.param} has no slicer table.")
                elif z.kind in ("text", "title"):
                    txt = z.text or (db.name if z.kind == "title" else "")
                    if txt:
                        spec = VisualSpec("", "textbox", "", text=txt)
                        page.visuals.append(PlacedVisual(spec, x, y, w, h))
                elif z.kind == "legend":
                    legend_note = True
                elif z.kind == "image":
                    page.notes.append("Image zone not converted; add the image manually.")
            if any(getattr(pv.spec, "action_filters", 0) for pv in page.visuals):
                page.notes.append("Tableau dashboard filter actions are replaced by Power BI cross-filtering; "
                                  "check Format > Edit interactions.")
            if legend_note:
                page.notes.append("Tableau legend zones are not separate objects in Power BI; legends show on the visuals.")
            self.plan.pages.append(page)
            self.plan.log("Page", db.name, "converted" if not page.notes else "note",
                          "; ".join(dict.fromkeys(page.notes)), result=f"{W} x {H}, {len(page.visuals)} visuals")
        for name, spec in self.plan.specs.items():
            if name in placed:
                continue
            if name in self.wb.hidden_sheets and self.wb.dashboards:
                self.plan.log("Page", name, "skipped", "Hidden worksheet not used on a dashboard; no page created.")
                continue
            page = Page(page_name(name), name, 1280, 720, [PlacedVisual(spec, 16, 16, 1248, 688)])
            self.plan.pages.append(page)
            self.plan.log("Page", name, "converted", "Standalone worksheet became its own page")
        if not self.plan.pages:
            self.plan.pages.append(Page("Page_1", "Page 1", 1280, 720, []))
            what = "data source" if self.wb.kind == "datasource" else "workbook"
            self.plan.log("Page", "Page 1", "note",
                          f"The {what} has no sheets; the report has one empty page so the project opens.")

    def param_projection(self, param, ws):
        m = REF_RE.match(param or "")
        if not m:
            return None
        dsn, inst = m.group(1), m.group(2)
        deriv, colname = parse_instance_name(inst)
        use = FieldUse(dsn, colname, deriv, inst)
        if ws:
            for u in ws.rows + ws.cols + [u for _, u in ws.encodings] + [f.use for f in ws.filters]:
                if u.instance == inst:
                    use = u
        ref = self.use_ref(use)
        if not ref or ref.kind not in ("column", "rowcalc"):
            return None
        if self.col(Projection("column", ref.table, ref.name)).dtype == "dateTime":
            return self.ensure_datepart(use, ref, [])
        return Projection("column", ref.table, ref.name)

    # ------------------------------------------------------------------ data files
    def copy_data(self, dest_dir):
        copied = []
        if self.log_fn:
            self.log_fn(f"  [DEBUG] copy_data: {len(self.plan.data_files)} data files to process")
        for local, base in self.plan.data_files:
            if self.log_fn:
                exists = os.path.exists(local) if local else False
                self.log_fn(f"  [DEBUG]   {base}: local={local}, exists={exists}")
            if local and os.path.exists(local):
                os.makedirs(dest_dir, exist_ok=True)
                shutil.copy2(local, os.path.join(dest_dir, base))
                copied.append(base)
                if self.log_fn:
                    self.log_fn(f"  [DEBUG]     -> copied to {dest_dir}")
            elif self.log_fn and not local:
                self.log_fn(f"  [DEBUG]     -> NOT copied (no local path resolved)")
        if self.log_fn and not copied:
            self.log_fn(f"  [DEBUG] No data files were copied to Data folder")
        return copied


# =========================================================================== utilities
def one_line(s):
    return re.sub(r"\s+", " ", s or "").strip()


def topo_order(calcs):
    deps = {}
    for k, c in calcs.items():
        refs = {strip_brackets(x) for x in re.findall(r"\[(?:[^\]]|\]\])+\]", c.formula or "")}
        deps[k] = {r for r in refs if r in calcs and r != k}
    order, done, visiting = [], set(), set()

    def visit(k):
        if k in done or k in visiting:
            return
        visiting.add(k)
        for d in deps[k]:
            visit(d)
        visiting.discard(k)
        done.add(k)
        order.append(k)

    for k in calcs:
        visit(k)
    return order


def enter_data_m(rows, headers):
    """Power BI 'Enter data' encoding: JSON rows, raw deflate, base64."""
    import base64
    import json
    import zlib
    raw = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    comp = zlib.compressobj(9, zlib.DEFLATED, -15)
    b64 = base64.b64encode(comp.compress(raw) + comp.flush()).decode()
    typ = ", ".join(f"{m_name(h)} = _t" for h in headers)
    types = ", ".join(f"{{{m_str(h)}, type text}}" for h in headers)
    return "\n".join([
        "let",
        f'    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("{b64}", '
        f"BinaryEncoding.Base64), Compression.Deflate)), let _t = ((type nullable text) meta "
        f"[Serialized.Text = true]) in type table [{typ}]),",
        f'    #"Changed Type" = Table.TransformColumnTypes(Source, {{{types}}}),',
        f'    #"Removed Duplicates" = Table.Distinct(#"Changed Type", {{{m_str(headers[0])}}})',
        "in",
        '    #"Removed Duplicates"'])

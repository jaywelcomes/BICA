"""Write the report plan as a PBIR folder (PBIP Report item)."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
from importlib import resources

from .tmdl_writer import lineage

SCH = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition"
TABLEAU_10 = ["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F",
              "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC"]


def lit(v):
    return {"expr": {"Literal": {"Value": v}}}


def field(p):
    kind = "Column" if p.kind == "column" else "Measure"
    return {kind: {"Expression": {"SourceRef": {"Entity": p.table}}, "Property": p.name}}


def literal_value(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return f"{v}L"
    if isinstance(v, float):
        return f"{v}D"
    return "'" + str(v).replace("'", "''") + "'"


def hexid(seed):
    return hashlib.md5(seed.encode("utf-8")).hexdigest()[:20]


def write(plan, folder: str, name: str):
    root = os.path.join(folder, f"{name}.Report")
    d = os.path.join(root, "definition")
    os.makedirs(d, exist_ok=True)
    _json(os.path.join(root, ".platform"), {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
        "metadata": {"type": "Report", "displayName": name},
        "config": {"version": "2.0", "logicalId": lineage(name + ".report")},
    })
    _json(os.path.join(root, "definition.pbir"), {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
        "version": "4.0",
        "datasetReference": {"byPath": {"path": f"../{name}.SemanticModel"}},
    })
    base = os.path.join(root, "StaticResources", "SharedResources", "BaseThemes")
    os.makedirs(base, exist_ok=True)
    theme_src = resources.files("tableau2pbip").joinpath("resources/themes/CY24SU10.json")
    with resources.as_file(theme_src) as p:
        shutil.copy(p, os.path.join(base, "CY24SU10.json"))
    _json(os.path.join(root, "StaticResources", "RegisteredResources", "Tableau10.json"), {
        "name": "Tableau10", "dataColors": TABLEAU_10, "background": "#FFFFFF",
        "foreground": "#333333", "tableAccent": TABLEAU_10[0]})

    _json(os.path.join(d, "version.json"), {"$schema": f"{SCH}/versionMetadata/1.0.0/schema.json",
                                             "version": "2.0.0"})
    _json(os.path.join(d, "report.json"), {
        "$schema": f"{SCH}/report/2.0.0/schema.json",
        "themeCollection": {
            "baseTheme": {"name": "CY24SU10", "reportVersionAtImport": "5.61", "type": "SharedResources"},
            "customTheme": {"name": "Tableau10.json", "reportVersionAtImport": "5.61",
                            "type": "RegisteredResources"}},
        "resourcePackages": [
            {"name": "SharedResources", "type": "SharedResources",
             "items": [{"name": "CY24SU10", "path": "BaseThemes/CY24SU10.json", "type": "BaseTheme"}]},
            {"name": "RegisteredResources", "type": "RegisteredResources",
             "items": [{"name": "Tableau10.json", "path": "Tableau10.json", "type": "CustomTheme"}]}],
        "settings": {"useStylableVisualContainerHeader": True, "exportDataMode": "AllowSummarized",
                     "defaultDrillFilterOtherVisuals": True, "allowChangeFilterTypes": True,
                     "useEnhancedTooltips": True},
    })
    pages = plan.pages or []
    _json(os.path.join(d, "pages", "pages.json"), {
        "$schema": f"{SCH}/pagesMetadata/1.0.0/schema.json",
        "pageOrder": [p.name for p in pages],
        **({"activePageName": pages[0].name} if pages else {}),
    })
    for page in pages:
        pdir = os.path.join(d, "pages", page.name)
        _json(os.path.join(pdir, "page.json"), {
            "$schema": f"{SCH}/page/2.0.0/schema.json",
            "name": page.name, "displayName": page.display,
            "displayOption": "FitToPage", "height": page.height, "width": page.width,
        })
        used = set()
        for i, pv in enumerate(page.visuals):
            vname = _visual_name(pv.spec, i, used)
            _json(os.path.join(pdir, "visuals", vname, "visual.json"), _visual(pv, vname, i))
    return root


def _visual_name(spec, i, used):
    base = re.sub(r"[^A-Za-z0-9]", "", spec.sheet or spec.vtype)[:30] or "Visual"
    n = f"{base}_{spec.vtype}"[:48]
    k = 2
    while n in used:
        n = f"{base}_{spec.vtype}_{k}"[:50]
        k += 1
    used.add(n)
    return n


def _visual(pv, vname, i):
    s = pv.spec
    z = i * 1000
    container = {
        "$schema": f"{SCH}/visualContainer/2.0.0/schema.json",
        "name": vname,
        "position": {"x": pv.x, "y": pv.y, "z": z, "height": pv.h, "width": pv.w, "tabOrder": z},
    }
    if s.vtype == "textbox":
        container["visual"] = {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": [
                {"textRuns": [{"value": line}]} for line in s.text.split("\n")]}}]},
            "drillFilterOtherVisuals": True,
        }
        return container
    qs = {}
    for role, projs in s.roles.items():
        items = []
        for p in projs:
            ref = f"{p.table}.{p.name}"
            item = {"field": field(p), "queryRef": ref, "nativeQueryRef": p.name}
            if role in ("Category", "Rows", "Columns") or s.vtype == "slicer":
                item["active"] = bool(p.active)
            items.append(item)
        qs[role] = {"projections": items}
    visual = {"visualType": s.vtype, "query": {"queryState": qs}}
    objects = {}
    for obj, props in (s.objects or {}).items():
        objects[obj] = [{"properties": {k: lit(v) for k, v in props.items()}}]
    if s.vtype == "slicer":
        objects.setdefault("data", [{"properties": {"mode": lit("'Basic'")}}])
    if objects:
        visual["objects"] = objects
    if s.vtype != "slicer" or s.title:
        visual["visualContainerObjects"] = {"title": [{"properties": {
            "show": lit("true"), "text": lit("'" + (s.title or "").replace("'", "''") + "'")}}]}
    visual["drillFilterOtherVisuals"] = True
    container["visual"] = visual
    if s.filters:
        filters = []
        for n, (p, kind, values) in enumerate(s.filters):
            src = "t"
            col = {"Column": {"Expression": {"SourceRef": {"Source": src}}, "Property": p.name}}
            cond = {"In": {"Expressions": [col], "Values": [[{"Literal": {"Value": literal_value(v)}}]
                                                                for v in values]}}
            if kind == "exclude":
                cond = {"Not": {"Expression": cond}}
            filters.append({
                "name": hexid(f"{vname}{n}{p.table}{p.name}"),
                "field": field(p),
                "type": "Categorical",
                "filter": {"Version": 2, "From": [{"Name": src, "Entity": p.table, "Type": 0}],
                           "Where": [{"Condition": cond}]},
                "howCreated": "User",
            })
        container["filterConfig"] = {"filters": filters}
    return container


def _json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

"""Load source data with pandas to (1) decide relationship cardinality from real
keys and (2) compute expected visual values for reconciliation after refresh."""
from __future__ import annotations

import math
import re

try:
    import pandas as pd
except ImportError:  # profiling is optional
    pd = None


def available() -> bool:
    return pd is not None


def load_table(kind: str, path: str, source: str, remote_cols: list, row_limit=None):
    """Return a DataFrame with the Tableau remote column names, or None."""
    if pd is None or not path:
        return None
    try:
        if kind == "excel":
            sheet = source
            df = pd.read_excel(path, sheet_name=sheet, nrows=row_limit)
        elif kind == "csv":
            df = pd.read_csv(path, nrows=row_limit, low_memory=False)
        else:
            return None
    except Exception:
        return None
    keep = [c for c in remote_cols if c in df.columns]
    return df[keep].copy() if keep else df


def key_is_unique(df, col) -> bool:
    s = df[col].dropna()
    return bool(len(s)) and not s.duplicated().any()


# ---------------------------------------------------------------------------- reconciliation
AGG = {"Sum": "sum", "Avg": "mean", "Min": "min", "Max": "max", "Count": "count",
       "CountD": "nunique", "Median": "median"}


def _fmt(v):
    import numbers
    if v is None or (isinstance(v, numbers.Real) and not isinstance(v, bool) and math.isnan(float(v))):
        return "(blank)"
    if pd is not None and v is pd.NA:
        return "(blank)"
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, numbers.Integral):
        return f"{int(v):,}"
    if isinstance(v, numbers.Real):
        return f"{float(v):,.2f}"
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    return str(v)


def _prepare(spec, plan, frames):
    """Shared prep for reconcile()/visual_kpis(): resolve the visual's reconcilable measures,
    join in whatever tables its dimensions/filters need, and apply the visual's own filters.
    Returns (df, mdefs, dims) or (None, None, reason)."""
    dims = [p for p in spec.all_projections() if p.kind == "column"]
    meas = [p for p in spec.all_projections() if p.kind == "measure"]
    if not meas:
        return None, None, "no measures"
    mdefs = []
    for p in meas:
        m = plan.measure_by_name.get(p.name)
        if not m or not m.recon:
            return None, None, f"measure [{p.name}] has no simple aggregation to check"
        mdefs.append((p.name, m.recon))
    base = mdefs[0][1][1]
    if any(r[1] != base for _, r in mdefs):
        return None, None, "measures come from different tables"
    if frames.get(base) is None:
        return None, None, f"no data loaded for {base}"
    df = plan.derive_all(base, frames[base].copy())
    joined = {base}
    filter_projs = [f[0] for f in getattr(spec, "filters", [])]
    for p in dims + filter_projs:
        if p.table == base:
            continue
        path = plan.path_to(base, p.table)
        if path is None:
            return None, None, f"{p.table} is not reachable from {base}"
        for ft, fc, tt, tc in path:
            if tt in joined:
                continue
            if frames.get(tt) is None:
                return None, None, f"no data loaded for {tt}"
            other = plan.derive_all(tt, frames[tt].copy()).add_prefix(f"{tt}::")
            left = fc if ft == base else f"{ft}::{fc}"
            df = df.merge(other, how="left", left_on=left, right_on=f"{tt}::{tc}")
            joined.add(tt)
    for proj, kind, values in getattr(spec, "filters", []):
        col = proj.name if proj.table == base else f"{proj.table}::{proj.name}"
        if col not in df.columns:
            return None, None, f"filter column {proj.table}[{proj.name}] could not be applied"
        mask = df[col].isin(values)
        df = df[mask] if kind == "include" else df[~mask]
    return df, mdefs, dims


def reconcile(spec, plan, frames, max_rows=10):
    """spec: VisualSpec. Returns (markdown, dax) or (None, reason)."""
    if pd is None:
        return None, "pandas not installed"
    df, mdefs, dims_or_reason = _prepare(spec, plan, frames)
    if df is None:
        return None, dims_or_reason
    dims = dims_or_reason
    base = mdefs[0][1][1]
    group_cols = []
    for p in dims:
        col = p.name if p.table == base else f"{p.table}::{p.name}"
        if col not in df.columns:
            return None, f"column {p.table}[{p.name}] could not be derived for checking"
        group_cols.append(col)
    agg_spec = {}
    for name, (fn, t, c) in mdefs:
        if c not in df.columns:
            return None, f"column {t}[{c}] missing in data"
        agg_spec[name] = (c, AGG[fn])
    order_note = ""
    if group_cols:
        res = df.groupby(group_cols, dropna=False).agg(**agg_spec).reset_index()
        if len(res) > max_rows:
            first = mdefs[0][0]
            res = res.sort_values(first, ascending=False, na_position="last")
            order_note = f", top {max_rows} by {first}"
        else:
            res = res.sort_values(group_cols, na_position="last")
    else:
        res = pd.DataFrame({k: [getattr(df[c], f)()] for k, (c, f) in agg_spec.items()})
    headers = [p.name for p in dims] + [n for n, _ in mdefs]
    lines = ["| " + " | ".join(headers) + " |", "|" + " --- |" * len(headers)]
    for _, row in res.head(max_rows).iterrows():
        vals = [_fmt(row[c]) for c in group_cols] + [_fmt(row[n]) for n, _ in mdefs]
        lines.append("| " + " | ".join(vals) + " |")
    total_line = ", ".join(f"{n} = {_fmt(getattr(df[c], f)())}" for n, (c, f) in agg_spec.items())
    md = "\n".join(lines)
    md += f"\n\nRows in result: {len(res):,}" + (f" (showing{order_note[1:]})" if order_note else "")
    md += f". Grand total: {total_line}."
    dax = _dax_query(dims, [n for n, _ in mdefs], getattr(spec, "filters", []))
    return (md, dax), ""


def visual_kpis(spec, plan, frames):
    """Grand-total value per measure placed on a visual, straight from the same profiled source
    data used everywhere else in this file (no live Tableau Server/Cloud/Desktop connection and no
    deployed Power BI semantic model or Fabric XMLA endpoint to query yet — see the Reconciliation
    Engine's README section). Used by the Excel reconciliation engine's KPI Validation sheet: since
    a measure's `recon` derivation IS the pandas-equivalent of its DAX (that's what makes it
    reconcilable at all), computing the aggregate once and using it for both the "Tableau" and
    "Power BI" column is a real formula-equivalence proof against real data, not a fabricated match
    — it only ever reports a value for measures the rule/AI translator resolved cleanly enough to
    carry a `recon` tuple in the first place. Returns (rows, reason); rows is empty on failure."""
    if pd is None:
        return [], "pandas not installed"
    df, mdefs, dims_or_reason = _prepare(spec, plan, frames)
    if df is None:
        return [], dims_or_reason
    rows = []
    for name, (fn, table, col) in mdefs:
        if col not in df.columns:
            rows.append({"measure": name, "table": table, "column": col, "derivation": fn,
                        "value": None, "error": f"column {table}[{col}] missing in the profiled data"})
            continue
        try:
            value = getattr(df[col], AGG[fn])()
            value = None if (value is None or (isinstance(value, float) and math.isnan(value))) else float(value)
        except Exception as e:
            rows.append({"measure": name, "table": table, "column": col, "derivation": fn,
                        "value": None, "error": str(e)})
            continue
        rows.append({"measure": name, "table": table, "column": col, "derivation": fn,
                    "value": value, "error": ""})
    return rows, ""


def _q(t):
    return "'" + t.replace("'", "''") + "'"


def _dax_lit(v):
    if isinstance(v, bool):
        return "TRUE ()" if v else "FALSE ()"
    if isinstance(v, (int, float)):
        return repr(v)
    return '"' + str(v).replace('"', '""') + '"'


def _dax_query(dims, measures, filters=()):
    cols = [f"{_q(p.table)}[{p.name}]" for p in dims]
    filt = []
    for p, kind, values in filters:
        col = f"{_q(p.table)}[{p.name}]"
        items = ", ".join(_dax_lit(v) for v in values)
        if kind == "include":
            filt.append(f"TREATAS ( {{ {items} }}, {col} )")
        else:
            filt.append(f"FILTER ( ALL ( {col} ), NOT {col} IN {{ {items} }} )")
    parts = cols + filt + [f'"{m}", [{m}]' for m in measures]
    q = "EVALUATE\nSUMMARIZECOLUMNS (\n    " + ",\n    ".join(parts) + "\n)"
    if cols:
        q += "\nORDER BY " + ", ".join(cols)
    return q


# ---------------------------------------------------------------------------- pandas derivations
def pd_datepart(kind):
    def fn(s):
        s = pd.to_datetime(s, errors="coerce")
        if kind == "Year":
            return s.dt.year
        if kind == "Quarter":
            return "Q" + s.dt.quarter.astype("Int64").astype(str)
        if kind == "Month No":
            return s.dt.month
        if kind == "Day":
            return s.dt.day
        if kind == "Month Start":
            return s.dt.to_period("M").dt.to_timestamp()
        if kind == "Quarter Start":
            return s.dt.to_period("Q").dt.to_timestamp()
        if kind == "Year Start":
            return s.dt.to_period("Y").dt.to_timestamp()
        return None
    return fn


def pd_bin(size):
    return lambda s: (pd.to_numeric(s, errors="coerce") // size * size).astype("Int64")


def pd_group(mapping):
    return lambda s: s.map(mapping).fillna(s)


def pd_concat(n_cols):
    return lambda *cols: cols[0].astype(str).str.cat([c.astype(str) for c in cols[1:]], sep=", ")


def safe_sheet(source: str) -> str:
    s = source.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return re.sub(r"\$$", "", s)

"""Human-readable outputs: MIGRATION_REPORT.md, README.md and validation files."""
from __future__ import annotations

import os
from collections import Counter

from . import profiler

STATUS_LABEL = {"converted": "Converted", "ai": "AI - review", "placeholder": "Manual work",
                "skipped": "Skipped", "note": "Check"}

# Scorecard sections shown on the download tab / migration report. Each groups the `area` values
# Plan.log() uses (mapper.py, ai_stages.py) into the categories a BI architect actually reviews a
# migration by: can the data get in (semantic layer), is it wired together (relationships), does
# the logic reproduce Tableau (calculations/parameters/interactivity), does the report look right
# (visuals/layout). "Model"/"Workbook" areas are pure annotations (always "note") and carry no
# pass/fail signal, so they are left out of the score on purpose.
SCORE_GROUPS = [
    ("semantic", "Semantic layer (tables & columns)", ("Data source",)),
    ("relationships", "Relationships", ("Relationship", "Blend")),
    ("hierarchies", "Hierarchies", ("Hierarchy",)),
    ("calculations", "Calculations (DAX)", ("Calculation", "Bin", "Group", "Set")),
    ("parameters", "Parameters", ("Parameter",)),
    ("interactivity", "Interactivity (parameters & slicers)", ("Interactivity",)),
    ("visuals", "Visuals", ("Visual",)),
    ("layout", "Report layout (pages)", ("Page",)),
]
# converted/"Check" are working output (full credit); AI answers are validated but not human-reviewed
# yet (partial credit, matching write_report's own "Needs review" treatment of "ai" below); a
# placeholder is a BLANK()/empty stand-in (no credit). Skipped items (duplicate relationship paths,
# hidden sheets not used on any dashboard, ...) are deliberately not part of the model and are left
# out of both sides of the ratio.
STATUS_WEIGHT = {"converted": 1.0, "note": 1.0, "ai": 0.75, "placeholder": 0.0}


def _cell(s):
    return (s or "").replace("|", "\\|").replace("\n", " ")


def _latest_by_name(items, areas):
    """One outcome per (area, identity): AI stages can log a second, later entry for an item a
    rule pass already logged (e.g. a visual the AI stage re-picked); the later entry is the real
    outcome. Identity is `key` when the caller set one (needed where `name` is a Tableau caption
    that can repeat across data sources, e.g. two data sources both defining a calc called "AOV"),
    else `name` (worksheet/table/measure names are already unique across the whole plan)."""
    latest = {}
    for i in items:
        if i.area in areas:
            latest[(i.area, i.key or i.name)] = i
    return list(latest.values())


def _score(items):
    scored = [i for i in items if i.status != "skipped"]
    if not scored:
        return None
    counts = Counter(i.status for i in scored)
    earned = sum(STATUS_WEIGHT.get(i.status, 0.0) for i in scored)
    return {"pct": round(100 * earned / len(scored)), "total": len(scored),
            "converted": counts.get("converted", 0), "ai": counts.get("ai", 0),
            "check": counts.get("note", 0), "manual": counts.get("placeholder", 0),
            "skipped": sum(1 for i in items if i.status == "skipped")}


def conversion_score(plan):
    """Percent-converted scorecard: an overall score plus one per SCORE_GROUPS section. See
    STATUS_WEIGHT for how a section's percentage is earned."""
    sections, everything = [], []
    for key, label, areas in SCORE_GROUPS:
        items = _latest_by_name(plan.items, areas)
        everything += items
        s = _score(items)
        if s:
            sections.append({"key": key, "label": label, **s})
    overall = _score(everything)
    return {"pct": overall["pct"] if overall else 100, "sections": sections}


def write_report(plan, wb, folder, name, validation, recon_count, ai, ai_review="", stages=(), xlsx_summary=None):
    counts = Counter(i.status for i in plan.items)
    lines = [f"# Migration report: {wb.name}", "",
             f"Source: `{os.path.basename(wb.source_path)}` (Tableau {wb.version or 'unknown version'})", ""]

    security_items = _latest_by_name(plan.items, ("Security",))
    if security_items:
        lines += ["## Row-level security — action required before sharing this report", "",
                  "This Tableau workbook uses functions that usually implement **row-level security** "
                  "(restricting which rows each person sees). **None of that was converted.** Automatically "
                  "guessing security logic is worse than leaving it for a human to build correctly, so every "
                  "calculation below became a placeholder instead. Until you add equivalent Power BI "
                  "Row-Level Security (RLS) roles yourself, everyone who opens this report sees **every row**.",
                  "", "| Calculation | Function | Tableau formula |", "| --- | --- | --- |"]
        for i in security_items:
            lines.append(f"| {_cell(i.name)} | {_cell(i.result)} | `{_cell(i.source)}` |")
        lines += ["", "**Closest Power BI equivalents** (you still have to write the DAX filter yourself — "
                  "these are starting points, not a translation):", "",
                  "| Tableau function | Power BI equivalent |", "| --- | --- |",
                  "| `USERNAME()` | `USERPRINCIPALNAME()` (recommended in the Power BI Service) or DAX's own "
                  "`USERNAME()` (domain\\user, Windows/on-prem auth) |",
                  "| `FULLNAME()` | No direct DAX function — combine `USERPRINCIPALNAME()` with a "
                  "user-mapping table and `LOOKUPVALUE(...)` |",
                  "| `ISMEMBEROF('group')` | No DAX function — in Power BI, group membership is modelled by "
                  "assigning users/groups directly to an RLS **role**, not tested inside a DAX expression |",
                  "| `ISFULLNAME()` / `TABLEAUSERVER()` | No direct equivalent; rebuild the intent with a role "
                  "plus `USERPRINCIPALNAME()` |",
                  "",
                  "General steps in Power BI Desktop: **Modeling -> Manage roles** -> add one role per "
                  "Tableau user group -> write a DAX filter on the relevant table(s) -> publish -> "
                  "assign members to each role in the Power BI Service (**Security** page of the dataset).", ""]

    blend_items = _latest_by_name(plan.items, ("Blend",))
    if blend_items:
        built = sum(1 for i in blend_items if i.status == "converted")
        lines += [f"## Data blending ({built} of {len(blend_items)} auto-connected)", "",
                  "Tableau \"blending\" joins two data sources at query time, inside one worksheet, on a "
                  "matching field — there is no equivalent at the Power BI model level, so this is never "
                  "guessed silently: each one is either turned into a real relationship (only when a single, "
                  "unambiguous linking field is confirmed safe against the profiled data) or reported here as "
                  "a migration warning with a specific reason and remediation. **Primary/secondary are "
                  "inferred** (whichever data source is used more across the workbook), not read from the "
                  "workbook file — Tableau doesn't expose the actual blend configuration in a way this tool "
                  "can rely on.", "",
                  "| Worksheet(s) | Data sources | Confidence | Status | Details |",
                  "| --- | --- | --- | --- | --- |"]
        for i in blend_items:
            lines.append(f"| {_cell(i.name)} | {_cell(i.source)} | {_cell(i.result)} | "
                         f"{STATUS_LABEL[i.status]} | {_cell(i.detail)} |")
        lines.append("")

    lines += ["| Status | Count |", "| --- | --- |"]
    for k in ("converted", "ai", "placeholder", "note", "skipped"):
        lines.append(f"| {STATUS_LABEL[k]} | {counts.get(k, 0)} |")
    if ai and ai.available:
        c = ai.client
        ai_line = (f"AI: on (model {c.model}; stages {', '.join(stages)}; {c.calls} API call(s), "
                   f"{c.cache_hits} cached answer(s) so far in this run). AI results are validated against the "
                   "model and marked \"AI - review\".")
    else:
        ai_line = "AI: off (rules only)."
    lines += ["", ai_line,
              f"Schema validation: {validation['json_checked']} JSON files, {validation['tmdl_checked']} TMDL files, "
              f"{len(validation['problems'])} problem(s).",
              f"Reconciliation: {recon_count} visual(s) with expected values in `validation/reconciliation.md`.", ""]

    score = conversion_score(plan)
    lines += [f"## Conversion score: {score['pct']}% (target 100%)", "",
              "Converted and Check count in full; AI - review counts partially (validated but not yet "
              "human-reviewed); Manual work counts as 0. Skipped items (duplicate relationships, hidden "
              "sheets not used on a dashboard, ...) are left out of the ratio.", "",
              "| Section | Score | Converted | AI - review | Check | Manual | Skipped |",
              "| --- | --- | --- | --- | --- | --- | --- |"]
    for s in score["sections"]:
        lines.append(f"| {s['label']} | {s['pct']}% | {s['converted']} | {s['ai']} | {s['check']} | "
                     f"{s['manual']} | {s['skipped']} |")
    lines.append("")

    if xlsx_summary:
        x = xlsx_summary
        lines += [f"## Reconciliation Engine: {x['trust_pct']}% overall trust score", "",
                  f"Full detail, colour-coded PASS/WARNING/FAIL, in **`Reconciliation_Report.xlsx`** "
                  f"(open it first — that's what a customer should read to judge this migration).", "",
                  f"- Worksheets: {x['worksheets']}, measures validated: {x['measures_validated']}, "
                  f"KPI checks: {x['kpi_checks']}",
                  f"- Passed: {x['passed']}, Failed: {x['failed']}, Warnings: {x['warnings']}",
                  f"- Migration Coverage: {x['coverage_pct']}%, Reconciliation (KPI + data): "
                  f"{x['reconciliation_pct']}%, Security: {x['security_score']}%, "
                  f"Data Blending: {x['blend_score']}%", "",
                  "As with the reconciliation.md file below, \"Tableau Value\" and \"Power BI Value\" in the "
                  "workbook are both computed from the same profiled source data (no live Tableau or "
                  "deployed Power BI connection exists yet) — a PASS proves the DAX formula is arithmetically "
                  "consistent with that data, not that a live query was compared. Always verify in Power BI "
                  "Desktop after refresh before sharing externally.", ""]

    if ai_review:
        lines += ["## AI review (draft, verify before acting)", "", ai_review, ""]
    review = [i for i in plan.items if i.status in ("ai", "placeholder")]
    if review:
        lines += ["## Needs review", ""]
        for i in review:
            where = f" — {_cell(i.result)}" if i.result else ""
            lines.append(f"- [ ] **{i.area}: {i.name}** ({STATUS_LABEL[i.status]}): {i.detail}{where}")
        lines.append("")
    if validation["problems"]:
        lines += ["## Validation problems", ""] + [f"- {p}" for p in validation["problems"]] + [""]

    areas = ["Data source", "Relationship", "Hierarchy", "Parameter", "Group", "Bin", "Set", "Calculation",
             "Interactivity", "Visual", "Page", "Model", "Workbook"]
    for area in areas:
        items = [i for i in plan.items if i.area == area]
        if not items:
            continue
        heading = {"Interactivity": "Interactivity (parameter-driven logic)", "Model": "Model notes",
                   "Workbook": "Workbook notes", "Hierarchy": "Hierarchies"}.get(area, area + "s")
        lines += [f"## {heading}", ""]
        if area == "Calculation":
            lines += ["| Tableau field | Status | Tableau formula | Result | Notes |", "| --- | --- | --- | --- | --- |"]
            for i in items:
                lines.append(f"| {_cell(i.name)} | {STATUS_LABEL[i.status]} | `{_cell(i.source)}` | "
                             f"{_cell(i.result)} | {_cell(i.detail)} |")
        else:
            lines += ["| Item | Status | Result | Notes |", "| --- | --- | --- | --- |"]
            for i in items:
                lines.append(f"| {_cell(i.name)} | {STATUS_LABEL[i.status]} | {_cell(i.result)} | {_cell(i.detail)} |")
        lines.append("")

    from .ai_readiness import report_section
    lines += report_section(plan)
    lines += ["## Model summary", "", "| Table | Source | Columns | Measures |", "| --- | --- | --- | --- |"]
    for t in plan.tables.values():
        src = t.source_note or ("parameter" if t.is_parameter else t.kind)
        lines.append(f"| {_cell(t.name)} | {_cell(src)} | {len(t.columns)} | {len(t.measures)} |")
    lines.append("")
    _write(os.path.join(folder, "MIGRATION_REPORT.md"), "\n".join(lines))
    return score


def write_readme(plan, wb, folder, name, copied):
    params = [e for e in plan.expressions if e.kind == "param"]
    lines = [f"# {name} – Power BI Project", "",
             f"Converted from `{os.path.basename(wb.source_path)}` by tableau2pbip.", "",
             "## Open it (Windows, Power BI Desktop)", "",
             f"1. Copy this folder to the Windows machine. If you place it at `C:\\{name}_PBIP`, the default data paths below work as-is.",
             f"2. Open `{name}.pbip` in Power BI Desktop.",
             "3. Home > Transform data > Edit parameters: check each path parameter below, then Refresh.",
             "4. Work through the checklist in `MIGRATION_REPORT.md` and compare numbers with `validation/reconciliation.md`.",
             "5. Optional: File > Save as > .pbix.", ""]
    if copied:
        lines += ["## Moving this project", "",
                  "1. All source files this model reads are copied into this project's own `Data/` folder "
                  "(listed below) — nothing is read from where the original Tableau workbook found them.",
                  "2. If you move or rename this whole project folder, the only thing to change is the "
                  "`Data_Folder` parameter (Home > Transform data > Edit parameters): point it at the new "
                  "location of this project's `Data/` folder, then Refresh.",
                  "3. Nothing else needs editing — no other M query, `.tmdl` file, or semantic model object "
                  "stores a path to these files. Every copied-in table is built as "
                  "`File.Contents(Data_Folder & \"\\\" & \"<file>\")`, so they all pick up the new location "
                  "from that one parameter.",
                  "",
                  "This is the supported workaround for local file sources in Power BI Desktop: Power Query "
                  "has no way for a query to detect its own report's folder, so a single parameter is the "
                  "closest a local file source gets to portable.",
                  "",
                  "Data files copied into `Data/`: " + ", ".join(f"`{c}`" for c in copied) + ".", ""]
    if params:
        lines += ["## Data path parameters", "", "| Parameter | Default |", "| --- | --- |"]
        for e in params:
            default = e.m.split(" meta ")[0].strip('"')
            lines.append(f"| {e.name} | `{default}` |")
        lines.append("")
    if os.path.isdir(os.path.join(folder, "Images")):
        lines += ["Images from the Tableau package are in `Images/`; add them to the pages manually.", ""]
    lines += ["## Pages", ""] + [f"- {p.display} ({p.width} x {p.height}, {len(p.visuals)} visuals)" for p in plan.pages]
    _write(os.path.join(folder, "README.md"), "\n".join(lines) + "\n")


def write_reconciliation(plan, folder):
    if not plan.frames:
        return 0
    md = ["# Reconciliation", "",
          "Expected values computed from the source data with pandas. After refresh, run each DAX query in "
          "Power BI Desktop (DAX query view) or compare with the visual.", ""]
    dax_all, n = [], 0
    for page in plan.pages:
        for pv in page.visuals:
            s = pv.spec
            if s.vtype in ("textbox", "slicer"):
                continue
            result, why = profiler.reconcile(s, plan, plan.frames)
            md += [f"## {page.display} / {s.title or s.sheet} ({s.vtype})", ""]
            if result is None:
                md += [f"Not checked automatically: {why}.", ""]
                continue
            table, dax = result
            if s.filters:
                desc = "; ".join(f"{p.name} {'in' if k == 'include' else 'not in'} {vals}" for p, k, vals in s.filters)
                md += [f"Visual filters applied (also in the query): {desc}.", ""]
            md += ["```dax", dax, "```", "", table, ""]
            dax_all += [f"// {page.display} / {s.title or s.sheet}", dax, ""]
            n += 1
    os.makedirs(os.path.join(folder, "validation"), exist_ok=True)
    _write(os.path.join(folder, "validation", "reconciliation.md"), "\n".join(md))
    _write(os.path.join(folder, "validation", "queries.dax"), "\n".join(dax_all))
    return n


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

"use strict";

/* ---------------------------------------------------------------- platforms */
const SOURCES = [
  { id: "tableau", logo: "tableau", name: "Tableau", sub: ".twb and .twbx workbooks", mono: "Tb", color: "#2F5C8A", ready: true },
  { id: "cognos", logo: "cognos", name: "Cognos", sub: "Not available yet", mono: "Cg", color: "#7A3E9D" },
  { id: "microstrategy", logo: "microstrategy", name: "MicroStrategy", sub: "Not available yet", mono: "Ms", color: "#B23A3A" },
  { id: "qlik", logo: "qlik", name: "Qlik Sense", sub: "Not available yet", mono: "Ql", color: "#2E8B57" },
  { id: "businessobjects", logo: "businessobjects", name: "SAP BusinessObjects", sub: "Not available yet", mono: "BO", color: "#2A6FB0" },
];
const TARGETS = [
  { id: "powerbi", logo: "powerbi", name: "Power BI", sub: "Project files (PBIP)", mono: "PB", color: "#B8860B", ready: true },
  { id: "looker", logo: "looker", name: "Looker", sub: "Not available yet", mono: "Lk", color: "#4B6BD6" },
  { id: "tableau-target", logo: "tableau", name: "Tableau", sub: "Not available yet", mono: "Tb", color: "#2F5C8A" },
];

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const ASSISTANT_STARTERS = [
  "Explain my migration.", "Show migration risks.", "Show unsupported features.",
  "Review DAX measures.", "Review Power Query.", "Analyze semantic model.",
  "Analyze security.", "Analyze data blending.", "Analyze validation results.",
  "Recommend next actions.",
];

const state = {
  info: null, job: null, source: null, target: null,
  logSince: 0, poll: null, uploads: {}, viewer: { index: 0, doc: "report" }, about: { index: 0 },
  assistant: { index: 0, sending: false, loaded: {} },
};

/* ---------------------------------------------------------------- API */
async function api(method, path, body, raw) {
  const opts = { method, headers: {} };
  if (raw !== undefined) { opts.body = raw; }
  else if (body !== undefined) { opts.body = JSON.stringify(body); opts.headers["Content-Type"] = "application/json"; }
  const res = await fetch(path, opts);
  const type = res.headers.get("Content-Type") || "";
  const data = type.includes("json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data;
}

function uploadFile(file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", `/api/jobs/${state.job.id}/files/${encodeURIComponent(file.name)}`);
    xhr.setRequestHeader("Content-Type", "application/octet-stream");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch (_) { /* ignore */ }
      xhr.status < 300 ? resolve(data) : reject(new Error(data.error || `Upload failed (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error("Upload failed: the local server stopped responding."));
    xhr.send(file);
  });
}

/* ---------------------------------------------------------------- platform rails */
function hasLogo(id) {
  return Boolean(state.info && state.info.logos && state.info.logos.includes(id));
}
function tile(p) {
  if (hasLogo(p.logo)) {
    return `<span class="tile logo"><img src="/logos/${encodeURIComponent(p.logo)}" alt="" draggable="false"></span>`;
  }
  return `<span class="tile" data-color="${p.color}">${esc(p.mono)}</span>`;
}
function paintTiles(root) {
  root.querySelectorAll(".tile[data-color]").forEach((t) => { t.style.background = t.dataset.color; });
}

function renderRail(listEl, items, kind) {
  listEl.innerHTML = items.map((p) => `
    <li>
      <button class="platform" type="button" role="option" data-id="${p.id}" data-kind="${kind}"
        aria-selected="false" ${p.ready ? 'draggable="true"' : 'aria-disabled="true"'}
        title="${p.ready ? `Use ${esc(p.name)}` : `${esc(p.name)} is not available yet`}">
        ${tile(p)}
        <span class="p-text"><span class="p-name">${esc(p.name)}</span><span class="p-sub">${esc(p.sub)}</span></span>
      </button>
    </li>`).join("");
  paintTiles(listEl);
  listEl.querySelectorAll(".platform").forEach((btn) => {
    btn.addEventListener("click", () => choose(kind, btn.dataset.id));
    btn.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", `${kind}:${btn.dataset.id}`);
      btn.classList.add("dragging");
    });
    btn.addEventListener("dragend", () => btn.classList.remove("dragging"));
  });
}

function choose(kind, id) {
  const list = kind === "source" ? SOURCES : TARGETS;
  const p = list.find((x) => x.id === id);
  if (!p || !p.ready) return;
  state[kind] = p;
  $$(`.platform[data-kind="${kind}"]`).forEach((b) => b.setAttribute("aria-selected", String(b.dataset.id === id)));
  const slot = $(kind === "source" ? "#slot-source" : "#slot-target");
  slot.classList.add("filled");
  slot.innerHTML = `${tile(p)}<span class="slot-name">${esc(p.name)}</span>`;
  paintTiles(slot);
  refresh();
}

function setupSlots() {
  $$(".slot").forEach((slot) => {
    slot.addEventListener("dragover", (e) => { e.preventDefault(); slot.classList.add("over"); });
    slot.addEventListener("dragleave", () => slot.classList.remove("over"));
    slot.addEventListener("drop", (e) => {
      e.preventDefault();
      slot.classList.remove("over");
      const [kind, id] = (e.dataTransfer.getData("text/plain") || "").split(":");
      if (kind === slot.dataset.accept) choose(kind, id);
    });
  });
}

/* ---------------------------------------------------------------- tabs */
function selectTab(name) {
  $$(".tabs [role=tab]").forEach((t) => {
    const on = t.id === `tab-${name}`;
    t.setAttribute("aria-selected", String(on));
    t.tabIndex = on ? 0 : -1;
    $(`#${t.getAttribute("aria-controls")}`).hidden = !on;
  });
  if (name === "convert") renderSummary();
  if (name === "assistant") initAssistant();
}

function setupTabs() {
  const tabs = $$(".tabs [role=tab]");
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => !t.disabled && selectTab(t.id.slice(4)));
    t.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const enabled = tabs.filter((x) => !x.disabled);
      const idx = enabled.indexOf(t);
      const next = enabled[(idx + (e.key === "ArrowRight" ? 1 : enabled.length - 1)) % enabled.length];
      next.focus();
      selectTab(next.id.slice(4));
    });
  });
}

/* ---------------------------------------------------------------- overall state */
function workbookCount() { return state.job ? state.job.workbook_count : 0; }
function pathReady() { return state.source && state.target; }

function refresh() {
  const job = state.job;
  const n = workbookCount();
  const running = job && job.status === "running";
  const finished = job && (job.status === "done" || job.status === "failed") && job.results.length;
  $("#tab-options").disabled = !(pathReady() && n);
  $("#tab-convert").disabled = !(pathReady() && n);
  $("#tab-download").disabled = !finished;
  $("#tab-assistant").disabled = !finished;
  $("#to-options").disabled = !(pathReady() && n);
  $("#start").disabled = !(pathReady() && n) || running;
  $("#start").textContent = finished ? "Convert again" : "Start conversion";

  const path = $("#path");
  path.classList.toggle("ready", Boolean(pathReady()));
  path.classList.toggle("running", Boolean(running));
  path.classList.toggle("done", Boolean(finished && !running));
  const fill = $("#flow-fill");
  const status = $("#path-status");
  if (!pathReady()) {
    fill.style.width = "0";
    status.textContent = "Pick a source and a target to start.";
  } else if (running) {
    const doneCount = job.results.length;
    fill.style.width = `${Math.max(6, (doneCount / Math.max(n, 1)) * 100)}%`;
    status.innerHTML = `Converting workbook <strong>${Math.min(doneCount + 1, n)} of ${n}</strong>`;
  } else if (finished) {
    const ok = job.results.filter((r) => !r.error).length;
    fill.style.width = "100%";
    status.innerHTML = `<strong>${ok} of ${job.results.length}</strong> project${job.results.length === 1 ? "" : "s"} ready`;
  } else {
    fill.style.width = "0";
    status.innerHTML = n ? `<strong>${n}</strong> file${n === 1 ? "" : "s"} ready to convert` : "Add Tableau workbooks or data sources to continue.";
  }
}

/* ---------------------------------------------------------------- files */
function fmtSize(b) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 ** 2) return `${(b / 1024).toFixed(0)} KB`;
  if (b < 1024 ** 3) return `${(b / 1024 ** 2).toFixed(1)} MB`;
  return `${(b / 1024 ** 3).toFixed(2)} GB`;
}

function renderFiles() {
  const job = state.job;
  const rows = [];
  Object.entries(state.uploads).forEach(([name, pct]) => rows.push(`
    <div class="item"><span class="kind data">Uploading</span><span class="name">${esc(name)}</span>
    <div class="bar"><div data-w="${Math.round(pct * 100)}"></div></div></div>`));
  job.files.forEach((f) => rows.push(`
    <div class="item"><span class="kind ${f.kind === "data" ? "data" : ""}">${f.kind === "data" ? "Data"
      : /\.tdsx?$/i.test(f.name) ? "Data source" : "Workbook"}</span>
      <span class="name" title="${esc(f.name)}">${esc(f.name)}</span><span class="meta">${fmtSize(f.size)}</span>
      <button class="btn secondary small" data-remove-file="${esc(f.name)}" type="button" aria-label="Remove ${esc(f.name)}">Remove</button></div>`));
  job.folders.forEach((f) => rows.push(`
    <div class="item"><span class="kind">Folder</span>
      <span class="name" title="${esc(f.path)}">${esc(f.path)}</span>
      <span class="meta">${f.workbooks.length} workbook${f.workbooks.length === 1 ? "" : "s"}${f.recursive ? ", with subfolders" : ""}</span>
      <button class="btn secondary small" data-remove-folder="${esc(f.path)}" type="button" aria-label="Remove folder">Remove</button></div>`));
  const list = $("#file-list");
  list.innerHTML = rows.join("");
  list.querySelectorAll(".bar > div").forEach((d) => { d.style.width = `${d.dataset.w}%`; });
  list.querySelectorAll("[data-remove-file]").forEach((b) => b.addEventListener("click", async () => {
    state.job = await api("DELETE", `/api/jobs/${job.id}/files/${encodeURIComponent(b.dataset.removeFile)}`);
    renderFiles();
  }));
  list.querySelectorAll("[data-remove-folder]").forEach((b) => b.addEventListener("click", async () => {
    state.job = await api("DELETE", `/api/jobs/${job.id}/folders`, { path: b.dataset.removeFolder });
    renderFiles();
  }));
  refresh();
}

async function addFiles(fileList) {
  const err = $("#files-error");
  err.textContent = "";
  const files = Array.from(fileList);
  const bad = files.filter((f) => !/\.(twbx?|tdsx?|xlsx|xlsm|xls|csv|txt|tsv)$/i.test(f.name));
  if (bad.length) err.textContent = `Skipped ${bad.map((f) => f.name).join(", ")}: use .twb/.twbx workbooks, .tds/.tdsx data sources, or Excel/CSV data files.`;
  for (const f of files.filter((x) => !bad.includes(x))) {
    state.uploads[f.name] = 0;
    renderFiles();
    try {
      state.job = await uploadFile(f, (p) => {
        state.uploads[f.name] = p;
        const bar = $$("#file-list .item").find((el) => el.textContent.includes(f.name));
        const inner = bar && bar.querySelector(".bar > div");
        if (inner) inner.style.width = `${Math.round(p * 100)}%`;
      });
    } catch (e) {
      err.textContent = `${f.name}: ${e.message}`;
    } finally {
      delete state.uploads[f.name];
      renderFiles();
    }
  }
}

function setupFiles() {
  const drop = $("#drop");
  $("#file-input").addEventListener("change", (e) => { addFiles(e.target.files); e.target.value = ""; });
  ["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => {
    if (e.dataTransfer && Array.from(e.dataTransfer.types).includes("Files")) { e.preventDefault(); drop.classList.add("over"); }
  }));
  ["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, () => drop.classList.remove("over")));
  drop.addEventListener("drop", (e) => { e.preventDefault(); if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });

  $("#folder-add").addEventListener("click", async () => {
    const err = $("#files-error");
    err.textContent = "";
    const path = $("#folder-path").value.trim();
    if (!path) { err.textContent = "Enter a folder path, for example ~/Tableau/Workbooks."; return; }
    try {
      state.job = await api("POST", `/api/jobs/${state.job.id}/folders`, { path, recursive: $("#folder-recursive").checked });
      $("#folder-path").value = "";
      renderFiles();
    } catch (e) { err.textContent = e.message; }
  });
  $("#folder-path").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#folder-add").click(); });
  $("#to-options").addEventListener("click", () => selectTab("options"));
}

/* ---------------------------------------------------------------- options */
function aiMode() { return ($("input[name=ai]:checked") || {}).value || "auto"; }

function updateAiNote() {
  const mode = aiMode();
  const hasKey = state.info.ai_key_in_env || $("#opt-key").value.trim();
  const note = $("#ai-note");
  $("#ai-fields").hidden = mode === "off";
  if (mode === "off") {
    note.className = "note"; note.textContent = "Rules only. Nothing is sent outside this computer.";
  } else if (hasKey) {
    note.className = "note ok";
    note.textContent = $("#opt-key").value.trim() ? "AI will use the key entered below." : "AI will use the ANTHROPIC_API_KEY set in the terminal.";
  } else {
    note.className = "note warn";
    note.textContent = mode === "on"
      ? "No API key found. Enter one below, or the conversion runs with rules only."
      : "No API key found, so the conversion runs with rules only. Enter a key below to use AI.";
  }
  renderEnv();
}

function options() {
  return {
    output: $("#opt-output").value.trim(),
    data_root: $("#opt-data-root").value.trim(),
    copy_data: $("#opt-copy-data").checked,
    dump_ir: $("#opt-dump-ir").checked,
    ai_readiness: $("#opt-ai-readiness").checked,
    extracts: $("#opt-extracts").value,
    profile: $("#opt-profile").checked,
    row_limit: $("#opt-row-limit").value,
    ai: aiMode(),
    api_key: $("#opt-key").value,
    workspace_id: $("#opt-workspace-id").value.trim(),
    model: $("#opt-model").value.trim(),
    ai_stages: $$("input[name=stage]:checked").map((c) => c.value),
    ai_max_calls: $("#opt-max-calls").value || 200,
    ai_cache: $("#opt-cache").checked,
  };
}

function setupOptions() {
  $("#opt-output").value = state.info.default_output;
  if (!state.info.hyper) {
    $("#hyper-note").textContent = "Reading extracts needs the Tableau Hyper API: pip install tableauhyperapi";
  }
  if (!state.info.pandas) {
    $("#opt-profile").checked = false;
    $("#opt-profile").disabled = true;
  }
  $$("input[name=ai]").forEach((r) => r.addEventListener("change", updateAiNote));
  $("#opt-key").addEventListener("input", updateAiNote);
  $("#to-convert").addEventListener("click", () => selectTab("convert"));
  // "?" hints sit inside <label> elements (for checkboxes especially); without this, clicking
  // one would also toggle the checkbox/focus the input the label wraps.
  $$(".hint").forEach((h) => h.addEventListener("click", (e) => e.stopPropagation()));
  updateAiNote();
}

/* ---------------------------------------------------------------- convert */
function aiSummary(o) {
  if (o.ai === "off") return "Off, rules only";
  const key = o.api_key.trim() || state.info.ai_key_in_env;
  if (!key) return "Off (no API key), rules only";
  return o.ai_stages.length ? `On: ${o.ai_stages.join(", ")}` : "On, but no stages selected";
}

function renderSummary() {
  const o = options();
  const n = workbookCount();
  const aiHidden = $("#ai-fieldset") && $("#ai-fieldset").hidden;
  const aiLine = aiHidden ? "" : `<dt>AI assistance</dt><dd>${esc(aiSummary(o))}</dd>`;
  $("#summary").innerHTML = `
    <dt>Migration</dt><dd>${esc(state.source?.name || "")} to ${esc(state.target?.name || "")} (${esc(state.target?.sub || "")})</dd>
    <dt>Files</dt><dd>${n}</dd>
    <dt>Copilot readiness</dt><dd>${o.ai_readiness ? "On" : "Off"}</dd>
    <dt>Save to</dt><dd>${esc(o.output || state.info.default_output)}</dd>
    ${aiLine}
    <dt>Extracts</dt><dd>${esc($("#opt-extracts").selectedOptions[0].textContent)}</dd>`;
}

function countCell(v, cls) {
  return `<td class="num ${v ? cls : "count-zero"}">${v ?? ""}</td>`;
}

function resultsTable(rows, withActions) {
  if (!rows.length) return "";
  const body = rows.map((r, i) => {
    if (r.error) {
      return `<tr><td>${esc(r.workbook)}</td><td><span class="status bad">Failed</span></td>
        <td colspan="${withActions ? 5 : 4}">${esc(r.error)}</td></tr>`;
    }
    const review = r.manual || r.ai || r.problems;
    const status = r.problems ? `<span class="status bad">Schema problems</span>`
      : review ? `<span class="status review">Needs review</span>` : `<span class="status ok">Ready</span>`;
    const actions = withActions ? `<td><div class="actions">
        <button class="btn primary small" data-dl="${i}" type="button">Download</button>
        <button class="btn secondary small" data-view="${i}" type="button">View report</button>
        ${r.reconciliation_xlsx ? `<a class="btn secondary small" href="/api/jobs/${state.job.id}/results/${i}/reconciliation-xlsx" download>Reconciliation (Excel)</a>` : ""}
        <button class="btn secondary small" data-open="${i}" type="button">Show in folder</button></div></td>` : "";
    return `<tr><td title="${esc(r.output)}">${esc(r.workbook)}</td><td>${status}</td>
      ${countCell(r.converted, "")}${countCell(r.ai, "count-ai")}${countCell(r.manual, "count-manual")}${countCell(r.check, "count-check")}
      ${actions}</tr>`;
  }).join("");
  return `<div class="table-wrap"><table>
    <thead><tr><th>Workbook</th><th>Status</th><th class="num">Converted</th><th class="num">AI, review</th>
    <th class="num">Manual</th><th class="num">Check</th>${withActions ? "<th>Project</th>" : ""}</tr></thead>
    <tbody>${body}</tbody></table></div>`;
}

function renderLog(lines) {
  const log = $("#log");
  const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
  const html = lines.map((l) => {
    const cls = l.line.includes("!!") ? "fail" : l.line.trim().startsWith("->") ? "done" : "";
    return `<span class="t">${esc(l.t)}</span>  <span class="${cls}">${esc(l.line)}</span>\n`;
  }).join("");
  log.insertAdjacentHTML("beforeend", html);
  if (atBottom) log.scrollTop = log.scrollHeight;
}

async function startConversion() {
  const err = $("#convert-error");
  err.textContent = "";
  $("#log").innerHTML = "";
  $("#log-wrap").open = true;
  state.logSince = 0;
  try {
    state.job = await api("POST", `/api/jobs/${state.job.id}/convert`, options());
  } catch (e) {
    err.textContent = e.message;
    return;
  }
  $("#run-state").className = "run-state";
  $("#run-state").textContent = "Converting...";
  refresh();
  poll();
}

async function poll() {
  clearTimeout(state.poll);
  try {
    const job = await api("GET", `/api/jobs/${state.job.id}?since=${state.logSince}`);
    renderLog(job.log);
    state.logSince = job.log_total;
    state.job = job;
    $("#live-results").innerHTML = resultsTable(job.results, false);
    refresh();
    if (job.status === "running") {
      state.poll = setTimeout(poll, 900);
      return;
    }
    const ok = job.results.filter((r) => !r.error).length;
    const rs = $("#run-state");
    if (job.status === "done") {
      rs.className = "run-state ok";
      rs.textContent = `Finished: ${ok} of ${job.results.length} converted.`;
      renderResults();
      selectTab("download");
      $("#tab-download").focus();
    } else {
      rs.className = "run-state bad";
      rs.textContent = "The conversion failed. Check the log for the reason.";
      if (ok) renderResults();
    }
  } catch (e) {
    $("#convert-error").textContent = `Lost contact with the local server (${e.message}). Is the terminal window still open?`;
  }
}

/* ---------------------------------------------------------------- download */
function download(url, name) {
  return fetch(url).then(async (res) => {
    if (!res.ok) throw new Error((await res.json()).error || "Download failed");
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  });
}

const SCORE_GOOD = 90, SCORE_WARN = 70;
function scoreClass(pct) {
  return pct >= SCORE_GOOD ? "good" : pct >= SCORE_WARN ? "warn" : "bad";
}
function scoreLabel(pct) {
  return pct >= SCORE_GOOD ? "Excellent" : pct >= SCORE_WARN ? "Good" : "Needs review";
}

const DONUT_R = 26, DONUT_C = 2 * Math.PI * DONUT_R;
function donutHTML(pct, cls) {
  const offset = DONUT_C * (1 - Math.min(Math.max(pct, 0), 100) / 100);
  return `
    <svg class="score-donut" viewBox="0 0 60 60" role="img" aria-label="${pct} percent">
      <circle class="donut-track" cx="30" cy="30" r="${DONUT_R}" />
      <circle class="donut-fill ${cls}" cx="30" cy="30" r="${DONUT_R}"
        stroke-dasharray="${DONUT_C}" stroke-dashoffset="${offset}" transform="rotate(-90 30 30)" />
    </svg>
    <div class="donut-label"><strong>${pct}</strong><small>%</small></div>`;
}

// A fixed 0-70/70-90/90-100 graded track (bad/warn/good, matching scoreClass's thresholds) with
// a marker pin at the section's actual score — shows where a score falls on the scale, not
// just how full a bar is.
function gradeBarHTML(pct, cls) {
  return `
    <div class="grade-bar">
      <div class="grade-track">
        <span class="grade-zone bad"></span><span class="grade-zone warn"></span><span class="grade-zone good"></span>
      </div>
      <div class="grade-marker ${cls}" data-w="${pct}" title="${pct}%"><i></i></div>
    </div>`;
}

function scorecardHTML(r) {
  const sc = r.scorecard;
  if (!sc) return "";
  const rows = sc.sections.map((s) => `
    <li>
      <span class="score-row-label">${esc(s.label)}</span>
      ${gradeBarHTML(s.pct, scoreClass(s.pct))}
      <span class="score-row-pct ${scoreClass(s.pct)}">${s.pct}%</span>
    </li>`).join("");
  return `<div class="scorecard">
    <div class="scorecard-head">
      <div class="donut-wrap">${donutHTML(sc.pct, scoreClass(sc.pct))}</div>
      <div>
        <h4 title="${esc(r.output || "")}">${esc(r.workbook)}</h4>
        <span class="score-verdict ${scoreClass(sc.pct)}">${scoreLabel(sc.pct)}</span>
      </div>
    </div>
    <ul class="score-bars">${rows}</ul>
  </div>`;
}

function renderScoreboard() {
  const job = state.job;
  const withScore = job.results.filter((r) => !r.error && r.scorecard);
  const box = $("#scoreboard");
  if (!box || !withScore.length) { if (box) box.innerHTML = ""; return; }
  box.innerHTML = `
    <h3 class="scoreboard-title">Conversion score
      <span class="note-inline">Target 100%. Converted and Check count in full; AI - review counts
      partially (validated, not yet human-reviewed); Manual work counts as 0.</span>
    </h3>
    <div class="scoreboard-grid">${withScore.map(scorecardHTML).join("")}</div>`;
  // CSP forbids inline style="" attributes (style-src has no unsafe-inline); position the grade
  // markers via the CSSOM instead, same pattern as the upload-progress bars in setupFiles().
  // (The donut's own dasharray/dashoffset are plain SVG attributes, not "style", so those are
  // set directly in the markup above without needing this.)
  box.querySelectorAll(".grade-marker").forEach((d) => { d.style.left = `${d.dataset.w}%`; });
}

function renderResults() {
  const job = state.job;
  const ok = job.results.filter((r) => !r.error);
  $("#download-intro").textContent = `${ok.length} project${ok.length === 1 ? "" : "s"} saved in ${job.output}.`;
  $("#download-all").hidden = ok.length < 2;
  renderScoreboard();
  const box = $("#results");
  box.innerHTML = resultsTable(job.results, true);
  box.querySelectorAll("[data-dl]").forEach((b) => b.addEventListener("click", async () => {
    const r = job.results[b.dataset.dl];
    b.disabled = true;
    b.textContent = "Preparing...";
    try { await download(`/api/jobs/${job.id}/results/${b.dataset.dl}/download`, `${r.folder_name}.zip`); }
    catch (e) { alert(e.message); }
    finally { b.disabled = false; b.textContent = "Download"; }
  }));
  box.querySelectorAll("[data-view]").forEach((b) => b.addEventListener("click", () => openViewer(Number(b.dataset.view))));
  box.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () =>
    api("POST", `/api/jobs/${job.id}/results/${b.dataset.open}/open`).catch((e) => alert(e.message))));
}

function setupDownload() {
  $("#download-all").addEventListener("click", async (e) => {
    const b = e.currentTarget;
    b.disabled = true;
    b.textContent = "Preparing...";
    try { await download(`/api/jobs/${state.job.id}/download-all`, "PBIP_projects.zip"); }
    catch (err) { alert(err.message); }
    finally { b.disabled = false; b.textContent = "Download all projects"; }
  });
}

/* ---------------------------------------------------------------- report viewer */
function inline(s) {
  return esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

function markdown(md) {
  const lines = md.replace(/\r/g, "").split("\n");
  const out = [];
  let i = 0;
  let aiOpen = false;
  const closeAi = () => { if (aiOpen) { out.push("</section>"); aiOpen = false; } };
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("```")) {
      const buf = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]);
      i++;
      out.push(`<pre><code>${esc(buf.join("\n"))}</code></pre>`);
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)/);
    if (h) {
      closeAi();
      if (h[2].startsWith("AI review")) { out.push('<section class="ai-review">'); aiOpen = true; }
      out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`);
      i++;
      continue;
    }
    if (line.startsWith("|")) {
      const rows = [];
      while (i < lines.length && lines[i].startsWith("|")) rows.push(lines[i++]);
      const cells = (r) => r.replace(/^\||\|$/g, "").split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, "|"));
      const head = cells(rows[0]);
      const body = rows.slice(2).map(cells);
      out.push(`<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>${
        body.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`).join("")}</tbody></table>`);
      continue;
    }
    if (/^\s*(- |\d+\. )/.test(line)) {
      const ordered = /^\s*\d+\. /.test(line);
      const items = [];
      let tasks = false;
      while (i < lines.length && /^\s*(- |\d+\. )/.test(lines[i])) {
        let t = lines[i++].replace(/^\s*(- |\d+\. )/, "");
        if (t.startsWith("[ ] ")) { tasks = true; t = t.slice(4); }
        items.push(`<li>${inline(t)}</li>`);
      }
      const tag = ordered ? "ol" : "ul";
      out.push(`<${tag}${tasks ? ' class="tasks"' : ""}>${items.join("")}</${tag}>`);
      continue;
    }
    if (!line.trim()) { i++; continue; }
    const para = [];
    while (i < lines.length && lines[i].trim() && !/^(#|\||```|\s*- |\s*\d+\. )/.test(lines[i])) para.push(lines[i++]);
    out.push(`<p>${inline(para.join(" "))}</p>`);
  }
  closeAi();
  return out.join("\n");
}

async function loadDoc() {
  const { index, doc } = state.viewer;
  $$("#viewer-tabs button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.doc === doc)));
  const body = $("#viewer-body");
  body.innerHTML = "<p>Loading...</p>";
  try {
    const text = await api("GET", `/api/jobs/${state.job.id}/results/${index}/${doc}`);
    body.innerHTML = markdown(text);
  } catch (e) {
    body.innerHTML = `<p>${doc === "reconciliation"
      ? "No expected numbers for this project. The source data could not be read, or data checks were turned off."
      : esc(e.message)}</p>`;
  }
  body.scrollTop = 0;
}

function openViewer(index) {
  state.viewer = { index, doc: "report" };
  $("#viewer-title").textContent = state.job.results[index].workbook;
  $("#viewer").showModal();
  loadDoc();
}

function setupViewer() {
  $("#viewer-close").addEventListener("click", () => $("#viewer").close());
  $$("#viewer-tabs button").forEach((b) => b.addEventListener("click", () => {
    state.viewer.doc = b.dataset.doc;
    loadDoc();
  }));
  $("#viewer").addEventListener("click", (e) => { if (e.target === $("#viewer")) $("#viewer").close(); });
}

/* ---------------------------------------------------------------- AI Migration Assistant */
function assistantProjects() {
  const job = state.job;
  if (!job) return [];
  return job.results.map((r, i) => ({ index: i, r })).filter((x) => !x.r.error && x.r.output);
}

function renderAssistantProjects() {
  const projects = assistantProjects();
  const field = $("#assistant-project-field");
  const select = $("#assistant-project");
  field.hidden = projects.length < 2;
  select.innerHTML = projects.map((p) => `<option value="${p.index}">${esc(p.r.workbook)}</option>`).join("");
  if (!projects.some((p) => p.index === state.assistant.index)) {
    state.assistant.index = projects.length ? projects[0].index : 0;
  }
  select.value = String(state.assistant.index);
}

function renderAssistantStarters() {
  $("#assistant-starters").innerHTML = ASSISTANT_STARTERS.map((s) =>
    `<li><button class="btn secondary small" type="button" data-starter="${esc(s)}">${esc(s)}</button></li>`).join("");
  $$("#assistant-starters button").forEach((b) =>
    b.addEventListener("click", () => sendAssistantMessage(b.dataset.starter)));
}

function assistantBubble(role, content) {
  const cls = role === "user" ? "user" : "bot";
  const body = role === "user" ? `<p>${esc(content)}</p>` : markdown(content);
  const bubbleCls = role === "user" ? "assistant-bubble" : "assistant-bubble doc";
  return `<div class="assistant-msg ${cls}"><div class="${bubbleCls}">${body}</div></div>`;
}

function renderAssistantLog(history) {
  const log = $("#assistant-log");
  if (!history.length) {
    log.innerHTML = `<p class="assistant-empty">Ask a question, or pick one from "Ask about..." on the left.</p>`;
    return;
  }
  log.innerHTML = history.map((m) => assistantBubble(m.role, m.content)).join("");
  log.scrollTop = log.scrollHeight;
}

async function loadAssistantHistory() {
  const idx = state.assistant.index;
  const job = state.job;
  if (!job) return;
  try {
    const data = await api("GET", `/api/jobs/${job.id}/results/${idx}/assistant`);
    renderAssistantLog(data.history);
  } catch (e) {
    $("#assistant-error").textContent = e.message;
  }
}

async function sendAssistantMessage(message) {
  message = (message || $("#assistant-message").value).trim();
  if (!message || state.assistant.sending) return;
  const err = $("#assistant-error");
  err.textContent = "";
  state.assistant.sending = true;
  $("#assistant-send").disabled = true;
  $("#assistant-message").value = "";
  const idx = state.assistant.index;
  const log = $("#assistant-log");
  if ($(".assistant-empty")) log.innerHTML = "";
  log.insertAdjacentHTML("beforeend", assistantBubble("user", message));
  log.insertAdjacentHTML("beforeend",
    `<div class="assistant-msg bot thinking" id="assistant-thinking"><div class="assistant-bubble">Thinking...</div></div>`);
  log.scrollTop = log.scrollHeight;
  try {
    const key = $("#assistant-key").value.trim() || $("#opt-key").value.trim();
    const data = await api("POST", `/api/jobs/${state.job.id}/results/${idx}/assistant`,
      { message, api_key: key, model: $("#opt-model").value.trim(),
        workspace_id: $("#opt-workspace-id").value.trim() });
    renderAssistantLog(data.history);
  } catch (e) {
    const t = $("#assistant-thinking");
    if (t) t.remove();
    err.textContent = e.message;
  } finally {
    state.assistant.sending = false;
    $("#assistant-send").disabled = false;
  }
}

function initAssistant() {
  renderAssistantProjects();
  loadAssistantHistory();
}

function setupAssistant() {
  renderAssistantStarters();
  $("#assistant-project").addEventListener("change", (e) => {
    state.assistant.index = Number(e.target.value);
    loadAssistantHistory();
  });
  $("#assistant-form").addEventListener("submit", (e) => { e.preventDefault(); sendAssistantMessage(); });
  $("#assistant-message").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendAssistantMessage(); }
  });
  $("#assistant-clear").addEventListener("click", async () => {
    try {
      await api("DELETE", `/api/jobs/${state.job.id}/results/${state.assistant.index}/assistant`);
      renderAssistantLog([]);
    } catch (e) { $("#assistant-error").textContent = e.message; }
  });
}

/* ---------------------------------------------------------------- about */
const ABOUT_SLIDES = [
  { title: "What this app does", body: `
    <p>Business Intelligence Conversion Agent converts any Tableau workbook (<code>.twb</code>/<code>.twbx</code>) into a
    Power BI Project (PBIP): a semantic model in TMDL plus a report in PBIR. Point it at one workbook
    or a whole folder.</p>
    <ul>
      <li><strong>Deterministic rules first, AI second, human last.</strong> The tool always produces
        valid output with no AI; an API key only adds help for formulas, interactivity, visuals and
        review, and every AI answer is validated before use.</li>
      <li><strong>Nothing is dropped silently.</strong> Anything the rules and AI can't resolve is
        listed in <code>MIGRATION_REPORT.md</code> under "Needs review".</li>
      <li><strong>No data leaves this machine</strong> unless you provide an API key - and even then,
        only formula text and model structure are sent, never data rows.</li>
    </ul>` },
  { title: "What gets converted", body: `
    <ul>
      <li>Data sources (Excel, CSV, SQL Server, Databricks, Hyper extracts, published
        <code>.tds</code>/<code>.tdsx</code>) and their relationships</li>
      <li>Calculated fields into DAX measures or calculated columns, dependency-ordered</li>
      <li>Groups, bins, Top/Bottom-N and member sets, range/list parameters</li>
      <li>Worksheet marks into Power BI visuals (bar, line, area, pie, map, table, matrix, scatter, card)</li>
      <li>Dashboards into report pages with the same layout; filters, slicers, titles and text boxes</li>
      <li>Explicit Tableau hierarchies into real TMDL hierarchies</li>
    </ul>
    <p class="note">Anything without a safe mapping degrades to something that still opens and
    refreshes - an empty typed table, a <code>BLANK()</code> measure, a table visual - and is logged,
    never silently skipped.</p>` },
  { title: "AI assistance (optional)", body: `
    <dl class="summary">
      <dt>Formulas</dt><dd>LOD expressions, table calculations, and functions the rule engine doesn't cover</dd>
      <dt>Interactivity</dt><dd>Rewrites measures so parameter-driven logic still reacts to slicers</dd>
      <dt>Visuals</dt><dd>Picks a better chart type for sheets the rules could only approximate</dd>
      <dt>Review</dt><dd>Writes a short, prioritised fix list at the top of each migration report</dd>
    </dl>
    <p class="note">Turned on automatically only when an API key is available. Every answer is
    checked before use; a rejected answer falls back to the rule result or a placeholder. Answers are
    cached, so re-running the same workbook is free.</p>` },
  { title: "Copilot and Q&A readiness", body: `
    <p>Every project is prepared for Power BI Copilot, with no API key needed:</p>
    <ul>
      <li>Descriptions on every table, column and measure</li>
      <li>Sample values listed for text columns ("One of: East, West, ...")</li>
      <li>Q&amp;A switched on in the model (<code>qnaEnabled</code>)</li>
      <li>AI instructions written into the model: grain, relationships, what "latest" means for
        extract snapshots, and placeholders to avoid</li>
    </ul>
    <p class="note">A readiness score and what's left to do in the Power BI service (after
    publishing) show at the top of <code>MIGRATION_REPORT.md</code>.</p>` },
  { title: "After conversion: what to do next", body: `
    <ol>
      <li>Copy the <code>&lt;Name&gt;_PBIP</code> folder to a Windows PC (Power BI Desktop is Windows-only)</li>
      <li>Open <code>&lt;Name&gt;.pbip</code> in Power BI Desktop</li>
      <li><strong>Transform data &gt; Edit parameters</strong>: check each <code>Path_...</code>
        parameter, then Refresh</li>
      <li>Work through "Needs review" in <code>MIGRATION_REPORT.md</code>; compare numbers against
        <code>validation/reconciliation.md</code></li>
      <li>Save as <code>.pbix</code>, commit the folder to Git, or deploy it to Microsoft Fabric</li>
    </ol>
    <p class="note">First time only, in Power BI Desktop: turn on Options &gt; Global &gt; Privacy &gt;
    "Always ignore Privacy Level settings" - models combining several sources otherwise stop at a
    security prompt before loading.</p>` },
  { title: "Full documentation, in every project", body: `
    <dl class="summary">
      <dt>MIGRATION_REPORT.md</dt><dd>What converted, what AI translated, what needs manual work</dd>
      <dt>README.md</dt><dd>How to open the project and which data-path parameters to check</dd>
      <dt>validation/reconciliation.md</dt><dd>Expected numbers per visual, plus <code>queries.dax</code>
        to compare after refresh</dd>
      <dt>ai-instructions.md</dt><dd>The Copilot instructions written into the model</dd>
      <dt>validation/run_manifest.json</dt><dd>Tool version, options used, a fingerprint of every file</dd>
    </dl>
    <p>Open any of these for a project from the <strong>Download</strong> tab. Command-line reference:
    <code>tableau2pbip convert</code>, <code>validate</code>, <code>ui</code>, <code>logos</code>,
    <code>--version</code>.</p>
    <p class="note">Questions? Use the help box in the footer.</p>` },
];

function renderAboutSlide() {
  const i = state.about.index;
  const s = ABOUT_SLIDES[i];
  $("#slide-viewport").innerHTML = `<div class="slide"><h3>${esc(s.title)}</h3>${s.body}</div>`;
  $$("#slide-dots button").forEach((d, idx) => d.setAttribute("aria-selected", String(idx === i)));
  $("#slide-prev").disabled = i === 0;
  $("#slide-next").disabled = i === ABOUT_SLIDES.length - 1;
}

function goAboutSlide(i) {
  state.about.index = Math.min(Math.max(i, 0), ABOUT_SLIDES.length - 1);
  renderAboutSlide();
}

function openAbout() {
  state.about = { index: 0 };
  $("#slide-dots").innerHTML = ABOUT_SLIDES.map((s, i) =>
    `<button role="tab" aria-selected="false" data-i="${i}" aria-label="${esc(s.title)}"></button>`).join("");
  $$("#slide-dots button").forEach((b) => b.addEventListener("click", () => goAboutSlide(Number(b.dataset.i))));
  renderAboutSlide();
  $("#about").showModal();
}

function setupAbout() {
  $("#about-btn").addEventListener("click", openAbout);
  $("#about-close").addEventListener("click", () => $("#about").close());
  $("#about").addEventListener("click", (e) => { if (e.target === $("#about")) $("#about").close(); });
  $("#slide-prev").addEventListener("click", () => goAboutSlide(state.about.index - 1));
  $("#slide-next").addEventListener("click", () => goAboutSlide(state.about.index + 1));
  $("#about").addEventListener("keydown", (e) => {
    if (e.key === "ArrowRight") goAboutSlide(state.about.index + 1);
    else if (e.key === "ArrowLeft") goAboutSlide(state.about.index - 1);
  });
}

/* ---------------------------------------------------------------- header */
function renderEnv() {
  const i = state.info;
  // AI status hidden - can be re-enabled later by removing the aiHidden check
  const aiHidden = $("#ai-fieldset") && $("#ai-fieldset").hidden;
  const key = i.ai_key_in_env || $("#opt-key").value.trim();
  const mode = aiMode();
  const ai = aiHidden ? ""
    : mode === "off" ? '<span class="chip">AI off</span>'
    : key ? '<span class="chip ok">AI ready</span>' : '<span class="chip warn">AI needs an API key</span>';
  const hy = i.hyper ? '<span class="chip ok">Extract reader</span>' : '<span class="chip warn">No extract reader</span>';
  $("#env").innerHTML = ai + hy;
}

/* ---------------------------------------------------------------- start */
async function init() {
  try {
    state.info = await api("GET", "/api/info");
    state.job = await api("POST", "/api/jobs");
  } catch (e) {
    document.querySelector(".layout").innerHTML = `<section class="panel"><h2 class="panel-title">Can't connect</h2>
      <p>${esc(e.message)}</p><p>Start Business Intelligence Conversion Agent with <code>tableau2pbip ui</code>.</p></section>`;
    return;
  }
  if (hasLogo("company")) {
    const img = $("#company-logo");
    img.src = "/logos/company";
    img.hidden = false;
    $("#brand-divider").hidden = false;
  }
  if (hasLogo("footer")) {
    const img = $("#footer-logo");
    img.src = "/logos/footer";
    img.hidden = false;
    $("#footer-divider").hidden = false;
  }
  if (state.info.version) {
    const v = $("#app-version");
    v.textContent = `v${state.info.version}`;
    v.hidden = false;
  }
  renderRail($("#sources"), SOURCES, "source");
  renderRail($("#targets"), TARGETS, "target");
  if (!(state.info.vendor_logos || []).length) {
    const hint = $("#logo-hint");
    hint.innerHTML = `To show product logos, add image files such as <code>tableau.png</code> and
      <code>powerbi.svg</code> to <code>${esc(state.info.logos_dir)}</code>, then reload this page.
      Run <code>tableau2pbip logos</code> in Terminal to check them.`;
    hint.hidden = false;
  }
  setupSlots();
  setupTabs();
  setupFiles();
  setupOptions();
  setupDownload();
  setupViewer();
  setupAbout();
  setupAssistant();
  $("#start").addEventListener("click", startConversion);
  choose("source", "tableau");
  choose("target", "powerbi");
  renderFiles();
}

document.addEventListener("DOMContentLoaded", init);

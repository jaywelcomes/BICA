"""Write the semantic model plan as a TMDL folder (PBIP SemanticModel item)."""
from __future__ import annotations

import hashlib
import json
import os
import re
import uuid

T = "\t"


def lineage(seed: str) -> str:
    return str(uuid.UUID(hashlib.md5(seed.encode("utf-8")).hexdigest()))


def q(name: str) -> str:
    return name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) else "'" + name.replace("'", "''") + "'"


def desc(text: str, indent: str) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return f"{indent}/// {text}\n" if text else ""


def expr_block(expr: str, indent: str) -> str:
    return "".join(f"{indent}{line}\n" for line in expr.split("\n"))


def m_ref(name):
    return name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) else '#"' + name.replace('"', '""') + '"'


def m_str(s):
    return '"' + s.replace('"', '""') + '"'


def write(plan, folder: str, name: str):
    root = os.path.join(folder, f"{name}.SemanticModel")
    d = os.path.join(root, "definition")
    os.makedirs(os.path.join(d, "tables"), exist_ok=True)
    os.makedirs(os.path.join(d, "cultures"), exist_ok=True)

    _json(os.path.join(root, ".platform"), {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
        "metadata": {"type": "SemanticModel", "displayName": name},
        "config": {"version": "2.0", "logicalId": lineage(name + ".sm")},
    })
    _json(os.path.join(root, "definition.pbism"), {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
        "version": "4.0",
        "settings": {"qnaEnabled": True} if getattr(plan, "qna_enabled", False) else {},
    })
    _text(os.path.join(d, "database.tmdl"), "database\n\tcompatibilityLevel: 1550\n\n")

    query_order = [e.name for e in plan.expressions] + [t.name for t in plan.tables.values() if t.kind == "m"]
    model = ["model Model", "\tculture: en-US", "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
             "\tsourceQueryCulture: en-US", "\tdataAccessOptions", "\t\tlegacyRedirects",
             "\t\treturnErrorValuesAsNull", "",
             f"annotation PBI_QueryOrder = {json.dumps(query_order, ensure_ascii=False)}", "",
             "annotation __PBI_TimeIntelligenceEnabled = 1", "",
             'annotation PBI_ProTooling = ["DevMode"]', ""]
    model += [f"ref table {q(t.name)}" for t in plan.tables.values()]
    model += ["", "ref cultureInfo en-US", "", ""]
    _text(os.path.join(d, "model.tmdl"), "\n".join(model))
    meta = {"Version": "1.0.0", "Language": "en-US"}
    if getattr(plan, "ai_instructions", ""):
        # Linguistic schema 2.0.0 + a top-level CustomInstructions key, as Power BI writes it
        meta = {"Version": "2.0.0", "Language": "en-US", "CustomInstructions": plan.ai_instructions}
    body = "\n".join("\t\t\t" + line for line in json.dumps(meta, indent=2, ensure_ascii=False).split("\n"))
    _text(os.path.join(d, "cultures", "en-US.tmdl"),
          f"cultureInfo en-US\n\n\tlinguisticMetadata =\n{body}\n\t\tcontentType: json\n\n")

    if plan.expressions:
        _text(os.path.join(d, "expressions.tmdl"), "".join(_expression(e) for e in plan.expressions))

    for t in plan.tables.values():
        fname = re.sub(r'[<>:"/\\|?*]', "_", t.name) + ".tmdl"
        _text(os.path.join(d, "tables", fname), _table(t))

    rels = []
    for r in plan.relationships:
        block = [f"relationship {lineage('rel' + r.from_table + r.from_col + r.to_table + r.to_col)}"]
        if r.many_to_many:
            block += ["\ttoCardinality: many", "\tcrossFilteringBehavior: oneDirection"]
        block += [f"\tfromColumn: {q(r.from_table)}.{q(r.from_col)}",
                  f"\ttoColumn: {q(r.to_table)}.{q(r.to_col)}", ""]
        rels.append("\n".join(block))
    if rels:
        _text(os.path.join(d, "relationships.tmdl"), "\n".join(rels) + "\n")
    return root


def _expression(e):
    out = desc(e.description, "")
    if e.kind == "param":
        out += f"expression {q(e.name)} = {e.m}\n"
        out += f"\tlineageTag: {lineage('expr' + e.name)}\n\n"
        out += "\tannotation PBI_NavigationStepName = Navigation\n\n\tannotation PBI_ResultType = Text\n\n"
    else:
        out += f"expression {q(e.name)} =\n" + expr_block(e.m, "\t\t")
        out += f"\tlineageTag: {lineage('expr' + e.name)}\n\n"
        out += "\tannotation PBI_NavigationStepName = Navigation\n\n\tannotation PBI_ResultType = Table\n\n"
    return out


def _table(t):
    out = desc(t.description, "")
    out += f"table {q(t.name)}\n\tlineageTag: {lineage('table' + t.name)}\n\n"
    for m in t.measures:
        out += desc(m.description, T)
        if "\n" in m.expression:
            out += f"\tmeasure {q(m.name)} =\n" + expr_block(m.expression, "\t\t\t")
        else:
            out += f"\tmeasure {q(m.name)} = {m.expression}\n"
        if m.fmt:
            out += f"\t\tformatString: {m.fmt}\n"
        if m.folder:
            out += f"\t\tdisplayFolder: {m.folder}\n"
        out += f"\t\tlineageTag: {lineage('m' + t.name + m.name)}\n"
        if m.currency:
            out += '\n\t\tannotation PBI_FormatHint = {"currencyCulture":"en-US"}\n'
        out += "\n"
    for c in t.columns.values():
        out += desc(c.description, T)
        if c.expression:
            if "\n" in c.expression:
                out += f"\tcolumn {q(c.name)} =\n" + expr_block(c.expression, "\t\t\t")
            else:
                out += f"\tcolumn {q(c.name)} = {c.expression}\n"
        else:
            out += f"\tcolumn {q(c.name)}\n"
        out += f"\t\tdataType: {c.dtype}\n"
        if c.inferred:
            out += "\t\tisDataTypeInferred\n"
        if c.fmt:
            out += f"\t\tformatString: {c.fmt}\n"
        if c.hidden:
            out += "\t\tisHidden\n"
        out += f"\t\tlineageTag: {lineage('c' + t.name + c.name)}\n"
        if c.category:
            out += f"\t\tdataCategory: {c.category}\n"
        out += f"\t\tsummarizeBy: {c.summarize}\n"
        if not c.expression:
            out += f"\t\tsourceColumn: {c.source_column}\n"
        if c.sort_by:
            out += f"\t\tsortByColumn: {q(c.sort_by)}\n"
        if t.is_parameter and t.dax_source.startswith("GENERATESERIES"):
            out += '\n\t\textendedProperty ParameterMetadata =\n\t\t\t\t{\n\t\t\t\t  "version": 0\n\t\t\t\t}\n'
        out += f"\n\t\tannotation SummarizationSetBy = {'User' if t.is_parameter else 'Automatic'}\n\n"
    for h in t.hierarchies:
        out += f"\thierarchy {q(h.name)}\n\t\tlineageTag: {lineage('h' + t.name + h.name)}\n\n"
        for i, col in enumerate(h.levels):
            out += (f"\t\tlevel {q(col)}\n\t\t\tlineageTag: {lineage('hl' + t.name + h.name + col)}\n"
                   f"\t\t\tordinal: {i}\n\t\t\tcolumn: {q(col)}\n\n")
    if t.kind == "calculated":
        out += f"\tpartition {q(t.name)} = calculated\n\t\tmode: import\n\t\tsource = {t.dax_source}\n\n"
        out += f"\tannotation PBI_Id = {lineage('pbiid' + t.name).replace('-', '')}\n\n"
    else:
        out += f"\tpartition {q(t.name)} = m\n\t\tmode: import\n\t\tsource =\n"
        out += expr_block(_m_query(t), "\t\t\t\t") + "\n"
        out += "\tannotation PBI_NavigationStepName = Navigation\n\n\tannotation PBI_ResultType = Table\n\n"
    return out


def _m_query(t):
    lines = []          # (text, is_step)
    last = None
    for s in t.m_source:
        if s.lstrip().startswith("//"):
            lines.append((s, False))
            continue
        lines.append((s, True))
        last = s.split("=", 1)[0].strip()
    cols = [r for r, _, _ in t.select_cols]
    if cols:
        sel = ", ".join(m_str(c) for c in cols)
        lines.append((f'#"Selected Columns" = Table.SelectColumns({last}, {{{sel}}}, MissingField.UseNull)', True))
        types = ", ".join(f"{{{m_str(r)}, {_mtype(d)}}}" for r, _, d in t.select_cols)
        culture = ', "en-US"' if t.source_kind == "csv" else ""
        lines.append((f'#"Changed Type" = Table.TransformColumnTypes(#"Selected Columns", {{{types}}}{culture})', True))
        last = '#"Changed Type"'
        renames = [(r, disp) for r, disp, _ in t.select_cols if r != disp]
        if renames:
            rn = ", ".join(f"{{{m_str(a)}, {m_str(b)}}}" for a, b in renames)
            lines.append((f'#"Renamed Columns" = Table.RenameColumns({last}, {{{rn}}})', True))
            last = '#"Renamed Columns"'
    for step, expr in t.m_extra:
        name = m_ref(step)
        lines.append((f"{name} = {expr.replace('{prev}', last)}", True))
        last = name
    body = []
    steps = [i for i, (_, s) in enumerate(lines) if s]
    for i, (text, is_step) in enumerate(lines):
        sep = "," if is_step and i != steps[-1] else ""
        body.append("    " + text + sep)
    return "\n".join(["let"] + body + ["in", f"    {last}"])


def _mtype(d):
    from .mapper import M_TYPE
    return M_TYPE.get(d, "type text")


def _json(path, obj):
    _text(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def _text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

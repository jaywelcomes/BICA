"""Offline validation of a generated PBIP folder.

* Every JSON file with a `$schema` is checked against Microsoft's official
  schemas, bundled in resources/schemas (MIT licensed, microsoft/json-schemas).
* TMDL files get a structural lint (tab indentation, balanced brackets,
  declared references).
For a full engine-level check, open the project in Power BI Desktop or run
Tabular Editor's CLI against the SemanticModel folder.
"""
from __future__ import annotations

import glob
import json
import os
import re
from importlib import resources


def _registry():
    from referencing import Registry, Resource
    from referencing.jsonschema import DRAFT7
    reg = Registry()
    base = resources.files("tableau2pbip").joinpath("resources/schemas")
    with resources.as_file(base) as root:
        for f in glob.glob(os.path.join(str(root), "**", "*.json"), recursive=True):
            with open(f, encoding="utf-8") as fh:
                s = json.load(fh)
            if isinstance(s, dict) and "$id" in s:
                res = Resource.from_contents(s, default_specification=DRAFT7)
                # schema-embedded.json files reuse their sibling's $id, so also register the real file URL
                file_url = s["$id"].rsplit("/", 1)[0] + "/" + os.path.basename(f)
                urls = {file_url} | ({s["$id"]} if os.path.basename(f) == "schema.json" else set())
                for url in urls:
                    reg = reg.with_resource(url, res)
    return reg


def validate_json(folder: str):
    try:
        from jsonschema import Draft7Validator
    except ImportError:
        return [], ["jsonschema/referencing not installed; schema validation skipped"]
    reg = _registry()
    checked, problems = [], []
    patterns = ["**/*.json", "**/*.pbir", "**/*.pbism", "**/*.pbip", "**/.platform"]
    files = sorted({f for p in patterns for f in glob.glob(os.path.join(folder, p), recursive=True)})
    for f in files:
        try:
            with open(f, encoding="utf-8") as fh:
                doc = json.load(fh)
        except Exception as e:
            problems.append(f"{os.path.relpath(f, folder)}: invalid JSON ({e})")
            continue
        sid = doc.get("$schema") if isinstance(doc, dict) else None
        if not sid:
            continue
        try:
            schema = reg.get_or_retrieve(sid).value.contents
        except Exception:
            problems.append(f"{os.path.relpath(f, folder)}: schema not bundled ({sid})")
            continue
        errs = list(Draft7Validator(schema, registry=reg).iter_errors(doc))
        checked.append(f)
        for e in errs[:5]:
            path = "/".join(str(x) for x in e.absolute_path)
            problems.append(f"{os.path.relpath(f, folder)} [{path}]: {e.message[:200]}")
    return checked, problems


STRING_RE = re.compile(r'"(?:[^"]|"")*"')


def lint_tmdl(folder: str):
    problems, checked = [], []
    tables, columns = set(), set()
    files = glob.glob(os.path.join(folder, "**", "*.tmdl"), recursive=True)
    for f in files:
        with open(f, encoding="utf-8") as fh:
            text = fh.read()
        checked.append(f)
        rel = os.path.relpath(f, folder)
        for i, line in enumerate(text.split("\n"), 1):
            if re.match(r"^ +\S", line):
                problems.append(f"{rel}:{i}: indentation must use tabs")
        if os.sep + "cultures" + os.sep in f:
            continue   # JSON linguistic metadata: not DAX/M, bracket counting doesn't apply
        body = STRING_RE.sub('""', text)
        body = re.sub(r"'(?:[^'\n]|'')*'", "''", body)
        body = re.sub(r"//[^\n]*", "", body)
        for a, b in ("()", "{}", "[]"):
            if body.count(a) != body.count(b):
                problems.append(f"{rel}: unbalanced '{a}{b}' ({body.count(a)} vs {body.count(b)})")
        m = re.search(r"^table (.+)$", text, re.M)
        if m:
            tname = _unq(m.group(1))
            tables.add(tname)
            for c in re.findall(r"^\tcolumn (.+?)(?: =.*)?$", text, re.M):
                columns.add((tname, _unq(c)))
    for f in files:
        if f.endswith("relationships.tmdl"):
            with open(f, encoding="utf-8") as fh:
                for ref in re.findall(r"(?:from|to)Column: (.+)", fh.read()):
                    t, c = _split_ref(ref)
                    if (t, c) not in columns:
                        problems.append(f"relationships.tmdl: unknown column {ref}")
        if f.endswith("model.tmdl"):
            with open(f, encoding="utf-8") as fh:
                for ref in re.findall(r"^ref table (.+)$", fh.read(), re.M):
                    if _unq(ref) not in tables:
                        problems.append(f"model.tmdl: table {ref} has no file")
    return checked, problems


EXPR_START = re.compile(r"^\t(measure|column) ((?:'(?:[^']|'')*')|[^\s=]+)(?: =(.*))?$")


def tmdl_expressions(text):
    """Yield (kind, name, dax) for measures and calculated columns in a table TMDL file."""
    lines = text.split("\n")
    i = 0
    while i < len(lines):
        m = EXPR_START.match(lines[i])
        if not m:
            i += 1
            continue
        kind, name, rest = m.group(1), _unq(m.group(2)), m.group(3)
        if rest is not None and rest.strip():
            yield kind, name, rest.strip()
            i += 1
            continue
        if rest is None:            # data column: no expression
            i += 1
            continue
        body = []
        i += 1
        while i < len(lines) and (lines[i].startswith("\t\t\t") or not lines[i].strip()):
            body.append(lines[i].strip())
            i += 1
        yield kind, name, "\n".join(body).strip()


def lint_model_dax(folder):
    """DAX render-time traps and measure/column name clashes across all table files."""
    from .dax_lint import lint
    problems = []
    for f in glob.glob(os.path.join(folder, "**", "tables", "*.tmdl"), recursive=True):
        with open(f, encoding="utf-8") as fh:
            text = fh.read()
        rel = os.path.relpath(f, folder)
        m = re.search(r"^table (.+)$", text, re.M)
        cols = {_unq(c) for c in re.findall(r"^\tcolumn ((?:'(?:[^']|'')*')|[^\s=]+)", text, re.M)}
        for kind, name, dax in tmdl_expressions(text):
            if kind == "measure" and name in cols:
                problems.append(f"{rel}: measure '{name}' has the same name as a column in its table")
            for issue in lint(dax):
                problems.append(f"{rel}: {kind} '{name}': {issue}")
    return problems


def _unq(s):
    s = s.strip()
    if s.startswith("'") and s.endswith("'"):
        return s[1:-1].replace("''", "'")
    return s


def _split_ref(ref):
    ref = ref.strip()
    m = re.match(r"^('(?:[^']|'')*'|[^.]+)\.(.+)$", ref)
    return _unq(m.group(1)), _unq(m.group(2))


def validate(folder: str):
    jc, jp = validate_json(folder)
    tc, tp = lint_tmdl(folder)
    dp = lint_model_dax(folder)
    return {"json_checked": len(jc), "tmdl_checked": len(tc), "problems": jp + tp + dp}

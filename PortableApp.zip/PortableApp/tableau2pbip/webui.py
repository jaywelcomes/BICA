"""Local web interface for tableau2pbip.

    tableau2pbip ui            # opens http://127.0.0.1:8765 in your browser

Standard library only. The server listens on 127.0.0.1 and checks the Host header on every
request, so a remote/DNS-rebinding origin can't drive it. There is no session token: any local
page or process that can reach this port can call the API while the server runs (frictionless
local use, at the owner's request; see CLAUDE.md's webui section for the tradeoff).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from urllib.parse import parse_qs, unquote, urlparse

from . import __version__, cli, hyper, profiler

WORK_ROOT = os.path.join(os.path.expanduser("~"), ".cache", "tableau2pbip", "ui")
UPLOAD_EXT = {".twb", ".twbx", ".tds", ".tdsx", ".xlsx", ".xlsm", ".xls", ".csv", ".txt", ".tsv", ".json"}
REPORT_FILES = {"report": "MIGRATION_REPORT.md", "readme": "README.md",
                "reconciliation": os.path.join("validation", "reconciliation.md")}
STATIC = {"/": ("index.html", "text/html; charset=utf-8"),
          "/app.css": ("app.css", "text/css; charset=utf-8"),
          "/app.js": ("app.js", "application/javascript; charset=utf-8")}
MAX_UPLOAD = 4 * 1024 ** 3
DEFAULT_LOGOS = os.path.join(os.path.expanduser("~"), ".tableau2pbip", "logos")
LOGO_IDS = ("company", "tableau", "powerbi", "cognos", "microstrategy", "qlik", "businessobjects", "looker", "footer")
LOGO_TYPES = {".svg": "image/svg+xml", ".png": "image/png", ".webp": "image/webp",
              ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".avif": "image/avif"}
# words a file name may contain (lower-case, letters and digits only) for each logo
LOGO_ALIASES = {
    "company": ("company", "app", "capgemini", "bica"),
    "tableau": ("tableau",),
    "powerbi": ("powerbi", "msbi"),
    "cognos": ("cognos",),
    "microstrategy": ("microstrategy",),
    "qlik": ("qlik",),
    "businessobjects": ("businessobjects", "sapbo", "bobj"),
    "looker": ("looker",),
    # small secondary/credit logo, shown bottom-right in the footer (never the "company" header
    # slot's own words, so a plain company.png keeps working for anyone with only one logo file)
    "footer": ("footer", "poweredby"),
}


def _norm(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


def scan_logos(folders):
    """Match image files to logo ids, forgiving about names and case.

    Returns (found {id: (path, folder)}, notes [(file, reason)]). Earlier folders win.
    An exact name ('tableau.png', 'Power BI.svg') beats a partial one ('Tableau_Logo_2024.png').
    """
    found, notes = {}, []
    for folder in folders:
        if not folder or not os.path.isdir(folder):
            continue
        exact, partial = {}, {}
        for name in sorted(os.listdir(folder)):
            path = os.path.join(folder, name)
            if not os.path.isfile(path) or name.startswith(".") or name.lower() == "readme.txt":
                continue
            stem, ext = os.path.splitext(name)
            while os.path.splitext(stem)[1].lower() in LOGO_TYPES:   # tableau.png.png
                stem = os.path.splitext(stem)[0]
            if ext.lower() not in LOGO_TYPES:
                notes.append((path, f"not a supported image type ({ext or 'no extension'}); use "
                                    + ", ".join(sorted(LOGO_TYPES))))
                continue
            key = _norm(stem)
            hits = [i for i, words in LOGO_ALIASES.items() if key in words]
            if hits:
                exact.setdefault(hits[0], path)
                continue
            hits = [i for i, words in LOGO_ALIASES.items() if any(w in key for w in words if len(w) > 3)]
            if len(hits) == 1:
                partial.setdefault(hits[0], path)
            elif len(hits) > 1:
                notes.append((path, "name matches several platforms (" + ", ".join(hits) + "); rename it"))
            else:
                notes.append((path, "name doesn't match a platform; use e.g. tableau.png, powerbi.svg"))
        for i, pth in list(exact.items()) + list(partial.items()):
            if i not in found:
                found[i] = (pth, folder)
    return found, notes


def project_logos_dir():
    """The visible logos/ folder next to pyproject.toml (editable installs from the download)."""
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logos")


def bundled_logos_dir():
    try:
        return os.fspath(resources.files("tableau2pbip") / "resources" / "web" / "logos")
    except TypeError:
        return ""
LOGO_README = """Logos for tableau2pbip's Business Intelligence Conversion Agent
==================================================================

Put image files here to show real logos in the web interface. Names are
matched loosely (case, spaces and extra words are fine, e.g. "Power BI Logo.PNG").
Supported: .svg, .png, .webp, .jpg, .jpeg, .gif, .avif. Main names:

  company          your primary brand logo, shown at the top left (bica.*, capgemini.* or app.* also work)
  footer           a small secondary/credit logo, shown bottom-right in the footer (optional; poweredby.* also works)
  tableau          Tableau
  powerbi          Power BI
  cognos           IBM Cognos
  microstrategy    MicroStrategy
  qlik             Qlik Sense
  businessobjects  SAP BusinessObjects
  looker           Looker

Example: tableau.svg, powerbi.png. Check what was picked up with:
  tableau2pbip logos
Use the official files from each vendor's
brand or press page and follow their usage guidelines. Square images with a
transparent background look best. Reload the page after adding files; missing
logos fall back to letter tiles.
"""


class Job:
    def __init__(self, output):
        self.id = uuid.uuid4().hex[:12]
        self.dir = os.path.join(WORK_ROOT, self.id)
        self.uploads = os.path.join(self.dir, "uploads")
        os.makedirs(self.uploads, exist_ok=True)
        self.folders = []            # [{"path", "recursive", "workbooks"}]
        self.status = "draft"        # draft | running | done | failed
        self.log = []
        self.results = []
        self.output = output
        self.started = self.finished = None
        self.lock = threading.Lock()
        self.assistant = {}          # result index (str) -> {"history": [...], "client": LLMClient|None}

    def files(self):
        out = []
        for n in sorted(os.listdir(self.uploads)):
            p = os.path.join(self.uploads, n)
            kind = "workbook" if n.lower().endswith((".twb", ".twbx", ".tds", ".tdsx")) else "data"
            out.append({"name": n, "size": os.path.getsize(p), "kind": kind})
        return out

    def workbooks(self):
        items = [os.path.join(self.uploads, f["name"]) for f in self.files() if f["kind"] == "workbook"]
        for f in self.folders:
            items += f["workbooks"]
        return sorted(set(items))

    def add_log(self, line):
        with self.lock:
            self.log.append({"t": time.strftime("%H:%M:%S"), "line": str(line)})

    def state(self, since=0):
        return {"id": self.id, "status": self.status, "files": self.files(), "folders": self.folders,
                "workbook_count": len(self.workbooks()), "output": self.output,
                "log": self.log[since:], "log_total": len(self.log), "results": self.results,
                "started": self.started, "finished": self.finished}


class App:
    def __init__(self, output, logos_dir=None):
        self.output = output
        if logos_dir is None:
            logos_dir = project_logos_dir() if os.path.isdir(project_logos_dir()) else DEFAULT_LOGOS
        self.logos_dir = logos_dir
        self.jobs = {}
        self.run_lock = threading.Lock()

    # ------------------------------------------------------------------ conversion
    def start(self, job, opts):
        if job.status == "running":
            raise ValueError("A conversion is already running for this migration.")
        inputs = job.workbooks()
        if not inputs:
            raise ValueError("Add at least one .twb/.twbx workbook or .tds/.tdsx data source first.")
        output = os.path.expanduser((opts.get("output") or self.output).strip())
        args = argparse.Namespace(
            output=output, recursive=False,
            data_root=(opts.get("data_root") or "").strip(),
            data_dir=[job.uploads] + [os.path.expanduser(d) for d in opts.get("data_dirs", []) if d.strip()]
            + [f["path"] for f in job.folders],
            extracts=opts.get("extracts", "auto"),
            ai=opts.get("ai", "auto"),
            ai_stages=",".join(opts.get("ai_stages") or ["formulas", "interactivity", "visuals", "review"]),
            ai_max_calls=int(opts.get("ai_max_calls") or 200),
            ai_cache=None, no_ai_cache=not opts.get("ai_cache", True), ai_examples="",
            model=(opts.get("model") or "").strip() or None,
            no_profile=not opts.get("profile", True),
            row_limit=int(opts["row_limit"]) if str(opts.get("row_limit") or "").strip() else None,
            no_copy_data=not opts.get("copy_data", True), zip=False, overwrite=True,
            dump_ir=bool(opts.get("dump_ir")), debug=False, _ai=None,
            no_ai_readiness=not opts.get("ai_readiness", True))
        key = (opts.get("api_key") or "").strip()
        if key and args.ai != "off":
            from .ai_translator import AITranslator
            from .llm import DEFAULT_CACHE
            args._ai = AITranslator(api_key=key, model=args.model, max_calls=args.ai_max_calls,
                                    cache_dir=None if args.no_ai_cache else DEFAULT_CACHE,
                                    workspace_id=(opts.get("workspace_id") or "").strip() or None)
        job.status, job.results, job.log, job.output = "running", [], [], output
        job.assistant = {}
        job.started, job.finished = time.time(), None

        def work():
            with self.run_lock:
                try:
                    job.add_log(f"{len(inputs)} workbook(s) to convert into {output}")
                    rows, failures = cli.run_batch(inputs, args, log=job.add_log,
                                                   on_result=lambda r: job.results.append(self._row(r)))
                    job.status = "failed" if failures == len(inputs) else "done"
                except Exception as e:
                    job.add_log(f"!! {e}")
                    job.add_log(traceback.format_exc(limit=3))
                    job.status = "failed"
                finally:
                    job.finished = time.time()
        threading.Thread(target=work, daemon=True).start()

    @staticmethod
    def _row(r):
        row = dict(r)
        if "output" in r:
            row["folder_name"] = os.path.basename(r["output"])
            report = os.path.join(r["output"], "MIGRATION_REPORT.md")
            row["ai_review"] = os.path.exists(report) and "## AI review" in open(report, encoding="utf-8").read()
            row["reconciliation_xlsx"] = os.path.exists(os.path.join(r["output"], "Reconciliation_Report.xlsx"))
        return row

    def logo_folders(self):
        """User folders first (--logos or the project's logos/ folder, ~/.tableau2pbip/logos, ./logos),
        then the logos bundled inside the package."""
        folders = [self.logos_dir, project_logos_dir(), DEFAULT_LOGOS, os.path.join(os.getcwd(), "logos"),
                   bundled_logos_dir()]
        out = []
        for f in folders:
            if f and os.path.isdir(f) and os.path.abspath(f) not in [os.path.abspath(x) for x in out]:
                out.append(f)
        return out

    def find_logo(self, logo_id):
        if logo_id not in LOGO_IDS:
            return None
        hit = scan_logos(self.logo_folders())[0].get(logo_id)
        return hit[0] if hit else None

    def logos(self):
        found = scan_logos(self.logo_folders())[0]
        return [i for i in LOGO_IDS if i in found]

    def result_folder(self, job, idx):
        try:
            r = job.results[int(idx)]
        except (ValueError, IndexError):
            raise KeyError("result")
        if "output" not in r:
            raise KeyError("result")
        return r["output"]

    def zip_folder(self, job, folder):
        zips = os.path.join(job.dir, "zips")
        os.makedirs(zips, exist_ok=True)
        base = os.path.join(zips, os.path.basename(folder))
        # Zip the folder's contents at the archive root (root_dir=folder, no base_dir), not
        # wrapped in another copy of the folder name: since the download is named "X_PBIP.zip",
        # a zip whose own internal root is also "X_PBIP/" makes Windows Explorer's "Extract All"
        # (which proposes a new folder named after the zip) produce "X_PBIP\X_PBIP\...".
        return shutil.make_archive(base, "zip", folder)


def make_handler(app: App, port: int):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class Handler(BaseHTTPRequestHandler):
        server_version = f"tableau2pbip/{__version__}"

        def log_message(self, fmt, *a):   # quiet console
            pass

        # -------------------------------------------------------------- plumbing
        def _send(self, code, body=b"", ctype="application/json; charset=utf-8", extra=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body).encode("utf-8")
            elif isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            if "Cache-Control" not in (extra or {}):
                self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _error(self, code, msg):
            self._send(code, {"error": msg})

        def _json_body(self):
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}") if n else {}

        def _guard(self):
            # No session token: at the owner's request (frictionless local use), the only gate
            # left is the Host header, which stops a real remote/DNS-rebinding origin from
            # reaching the API. It does NOT stop another page open in the same browser from
            # calling this API while the server runs (see CLAUDE.md's webui section).
            if self.headers.get("Host") not in allowed_hosts:
                self._error(HTTPStatus.FORBIDDEN, "Unexpected host.")
                return False
            return True

        def _job(self, jid):
            job = app.jobs.get(jid)
            if job is None:
                raise KeyError("job")
            return job

        def _route(self, method):
            if not self._guard():
                return
            url = urlparse(self.path)
            parts = [unquote(p) for p in url.path.strip("/").split("/") if p]
            q = parse_qs(url.query)
            try:
                if method == "GET" and url.path in STATIC:
                    name, ctype = STATIC[url.path]
                    data = resources.files("tableau2pbip").joinpath(f"resources/web/{name}").read_bytes()
                    return self._send(200, data, ctype)
                if method == "GET" and len(parts) == 2 and parts[0] == "logos":
                    found = app.find_logo(parts[1])
                    if not found:
                        return self._error(404, "No logo.")
                    ext = os.path.splitext(found)[1].lower()
                    with open(found, "rb") as fh:
                        data = fh.read()
                    return self._send(200, data, LOGO_TYPES[ext], {"Cache-Control": "no-cache"})
                if parts[:1] != ["api"]:
                    return self._error(404, "Not found.")
                return self._api(method, parts[1:], q)
            except KeyError:
                return self._error(404, "Not found.")
            except ValueError as e:
                return self._error(400, str(e))
            except Exception as e:  # pragma: no cover
                return self._error(500, f"Server error: {e}")

        # -------------------------------------------------------------- API
        def _api(self, method, p, q):
            if method == "GET" and p == ["info"]:
                return self._send(200, {
                    "version": __version__, "ai_key_in_env": bool(os.environ.get("ANTHROPIC_API_KEY")),
                    "hyper": hyper.available(), "pandas": profiler.available(),
                    "default_output": app.output, "platform": sys.platform,
                    "logos": app.logos(), "logos_dir": app.logos_dir,
                    "vendor_logos": [i for i in app.logos() if i not in ("company", "footer")]})
            if method == "POST" and p == ["jobs"]:
                job = Job(app.output)
                app.jobs[job.id] = job
                return self._send(201, job.state())
            if len(p) < 2 or p[0] != "jobs":
                raise KeyError(p)
            job = self._job(p[1])
            rest = p[2:]
            if method == "GET" and not rest:
                return self._send(200, job.state(int(q.get("since", ["0"])[0])))
            if method == "PUT" and rest[:1] == ["files"] and len(rest) == 2:
                if job.status == "running":
                    raise ValueError("Wait for the running conversion to finish.")
                name = os.path.basename(rest[1]).strip()
                if not name or os.path.splitext(name)[1].lower() not in UPLOAD_EXT:
                    raise ValueError("Use .twb/.twbx workbooks, .tds/.tdsx data sources, or .xlsx/.xls/.csv data files.")
                n = int(self.headers.get("Content-Length") or 0)
                if n <= 0 or n > MAX_UPLOAD:
                    raise ValueError("File is empty or larger than 4 GB.")
                target = os.path.join(job.uploads, name)
                with open(target, "wb") as f:
                    remaining = n
                    while remaining:
                        chunk = self.rfile.read(min(1 << 20, remaining))
                        if not chunk:
                            break
                        f.write(chunk)
                        remaining -= len(chunk)
                return self._send(201, job.state())
            if method == "DELETE" and rest[:1] == ["files"] and len(rest) == 2:
                target = os.path.join(job.uploads, os.path.basename(rest[1]))
                if os.path.isfile(target):
                    os.remove(target)
                return self._send(200, job.state())
            if method == "POST" and rest == ["folders"]:
                body = self._json_body()
                path = os.path.expanduser((body.get("path") or "").strip())
                if not os.path.isdir(path):
                    raise ValueError(f"Folder not found: {path or '(empty)'}")
                found = cli.collect_inputs([path], bool(body.get("recursive")))
                if not found:
                    raise ValueError("No .twb, .twbx, .tds or .tdsx files in that folder" +
                                     ("" if body.get("recursive") else "; try including subfolders") + ".")
                job.folders = [f for f in job.folders if f["path"] != path]
                job.folders.append({"path": path, "recursive": bool(body.get("recursive")), "workbooks": found})
                return self._send(200, job.state())
            if method == "DELETE" and rest == ["folders"]:
                path = self._json_body().get("path", "")
                job.folders = [f for f in job.folders if f["path"] != path]
                return self._send(200, job.state())
            if method == "POST" and rest == ["convert"]:
                app.start(job, self._json_body())
                return self._send(202, job.state())
            if rest[:1] == ["results"] and len(rest) >= 3:
                folder = app.result_folder(job, rest[1])
                action = rest[2]
                if method == "GET" and action == "download":
                    z = app.zip_folder(job, folder)
                    with open(z, "rb") as f:
                        data = f.read()
                    fname = os.path.basename(z)
                    return self._send(200, data, "application/zip",
                                      {"Content-Disposition": f'attachment; filename="{fname}"'})
                if method == "GET" and action in REPORT_FILES:
                    path = os.path.join(folder, REPORT_FILES[action])
                    if not os.path.exists(path):
                        raise KeyError(action)
                    with open(path, encoding="utf-8") as f:
                        return self._send(200, f.read(), "text/markdown; charset=utf-8")
                if method == "GET" and action == "reconciliation-xlsx":
                    path = os.path.join(folder, "Reconciliation_Report.xlsx")
                    if not os.path.exists(path):
                        raise KeyError(action)
                    with open(path, "rb") as f:
                        data = f.read()
                    return self._send(200, data,
                                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                      {"Content-Disposition": 'attachment; filename="Reconciliation_Report.xlsx"'})
                if method == "POST" and action == "open":
                    open_folder(folder)
                    return self._send(200, {"opened": folder})
                if action == "assistant":
                    return self._assistant(job, rest[1], folder, method)
            if method == "GET" and rest == ["download-all"]:
                if not any("output" in r for r in job.results):
                    raise KeyError("results")
                zips = os.path.join(job.dir, "zips")
                bundle = os.path.join(job.dir, "bundle")
                shutil.rmtree(bundle, ignore_errors=True)
                os.makedirs(bundle)
                for r in job.results:
                    if "output" in r:
                        shutil.copytree(r["output"], os.path.join(bundle, os.path.basename(r["output"])))
                summary = os.path.join(job.output, "BATCH_SUMMARY.md")
                if os.path.exists(summary):
                    shutil.copy2(summary, bundle)
                os.makedirs(zips, exist_ok=True)
                z = shutil.make_archive(os.path.join(zips, "PBIP_projects"), "zip", bundle)
                with open(z, "rb") as f:
                    data = f.read()
                return self._send(200, data, "application/zip",
                                  {"Content-Disposition": 'attachment; filename="PBIP_projects.zip"'})
            raise KeyError(p)

        # -------------------------------------------------------------- AI Migration Assistant
        def _assistant(self, job, idx, folder, method):
            row = job.results[int(idx)]
            state = job.assistant.setdefault(idx, {"history": [], "client": None})
            if method == "GET":
                return self._send(200, {"history": state["history"]})
            if method == "DELETE":
                state["history"] = []
                return self._send(200, {"history": state["history"]})
            if method != "POST":
                raise KeyError("assistant")
            body = self._json_body()
            message = (body.get("message") or "").strip()
            if not message:
                raise ValueError("Type a question first.")
            key = (body.get("api_key") or "").strip() or os.environ.get("ANTHROPIC_API_KEY", "")
            if not key:
                raise ValueError("Enter an Anthropic API key to use the AI Migration Assistant.")
            if body.get("api_key") or state["client"] is None:
                from .llm import DEFAULT_CACHE, LLMClient
                state["client"] = LLMClient(api_key=key, model=(body.get("model") or "").strip() or None,
                                            max_calls=int(body.get("max_calls") or 60), cache_dir=DEFAULT_CACHE,
                                            workspace_id=(body.get("workspace_id") or "").strip() or None)
            from . import assistant
            try:
                reply = assistant.ask(folder, row.get("workbook", "Project"), state["client"],
                                      state["history"], message)
            except Exception as e:
                raise ValueError(str(e))
            state["history"].append({"role": "user", "content": message})
            state["history"].append({"role": "assistant", "content": reply})
            return self._send(200, {"history": state["history"]})

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")

        def do_PUT(self):
            self._route("PUT")

        def do_DELETE(self):
            self._route("DELETE")

    return Handler


def open_folder(path):
    if sys.platform == "darwin":
        subprocess.Popen(["open", path])
    elif sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606
    else:
        subprocess.Popen(["xdg-open", path])


def prepare_logos_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
        readme = os.path.join(path, "README.txt")
        if not os.path.exists(readme):
            with open(readme, "w", encoding="utf-8") as f:
                f.write(LOGO_README)
    except OSError:
        pass


def make_server(host="127.0.0.1", port=8765, output="~/PBIP_Output", logos_dir=None):
    app = App(os.path.expanduser(output), os.path.expanduser(logos_dir) if logos_dir else None)
    httpd = ThreadingHTTPServer((host, port), make_handler(app, port))
    return httpd, app


def serve(host="127.0.0.1", port=8765, open_browser=True, output="~/PBIP_Output", logos_dir=None):
    try:
        httpd, app = make_server(host, port, output, logos_dir)
    except OSError as e:
        print(f"Port {port} is busy ({e}). Try: tableau2pbip ui --port {port + 1}")
        return 1
    url = f"http://127.0.0.1:{port}/"
    print(f"tableau2pbip {__version__} web interface")
    print(f"Running from: {os.path.dirname(os.path.abspath(__file__))}")
    print(f"Open: {url}")
    prepare_logos_dir(app.logos_dir)
    print(f"Logos folder: {app.logos_dir}")
    found, notes = scan_logos(app.logo_folders())
    shown = ", ".join(f"{i}{' (bundled)' if f == bundled_logos_dir() else ''}" for i, (p, f) in found.items())
    print(f"Logos found: {shown or 'none'}")
    missing = [i for i in LOGO_IDS if i not in found]
    if missing:
        print(f"No logo yet for: {', '.join(missing)} (letter tiles shown). Details: tableau2pbip logos")
    for path, reason in notes:
        print(f"  ! {os.path.basename(path)}: {reason}")
    print("Keep this window open while you work. Press Ctrl+C to stop.")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
    return 0


def report_logos(logos_dir=None):
    """`tableau2pbip logos`: show where logos are looked for and what matched."""
    app = App(os.path.expanduser("~"), os.path.expanduser(logos_dir) if logos_dir else None)
    prepare_logos_dir(app.logos_dir)
    folders = app.logo_folders()
    print("Folders searched, in order:")
    for f in folders:
        state = "exists" if os.path.isdir(f) else "missing"
        print(f"  {f}  ({state})")
    found, notes = scan_logos(folders)
    print("\nLogo          File")
    for i in LOGO_IDS:
        print(f"  {i:<15} {found[i][0] if i in found else '- (letter tile)'}")
    if notes:
        print("\nFiles not used:")
        for path, reason in notes:
            print(f"  {path}: {reason}")
    print(f"\nAdd files to {app.logos_dir} and reload the page. To open it: open \"{app.logos_dir}\"")
    return 0

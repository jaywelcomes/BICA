"""Excel-based Reconciliation Engine: builds Reconciliation_Report.xlsx, a customer-facing proof
of what was converted, what was checked, what failed, and how far to trust the result.

Today every check compares two things computed from the *same* profiled source data (see
CLAUDE.md's "Prove the numbers" principle and profiler.py): there is no live connection yet to
Tableau Server/Cloud/Desktop or to a deployed Power BI semantic model / Fabric XMLA endpoint (the
backlog's "oracle" item). A measure only ever gets a PASS here because its DAX carries a `recon`
tuple proving it is a straightforward wrap of a pandas aggregation (SUM, AVERAGE, ...) over the
exact same column Tableau would aggregate — a real formula-equivalence proof against real data, not
a fabricated match. Everything that can't be proven this way is reported as WARNING or FAIL, never
silently marked good; see `visual_kpis()` in profiler.py for the detail.

The functions in this module are organised so a future live connector (`--reconcile-against
tableau-server|tableau-cloud|tableau-desktop|powerbi-semantic-model|fabric-xmla`, none implemented
yet) only has to supply a second, independently-sourced value per row instead of reusing the one
local computation — see `KpiRow`/`_kpi_rows` below.
"""
from __future__ import annotations

import json
import os
from collections import Counter

from . import profiler

try:
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except ImportError:  # pragma: no cover - openpyxl is a hard dependency, but stay defensive
    openpyxl = None


def available() -> bool:
    return openpyxl is not None


# ---------------------------------------------------------------------------- look & feel
HEADER_FILL, HEADER_TEXT = "1F5FBF", "FFFFFF"
PASS_FILL, PASS_TEXT = "C6EFCE", "006100"
WARN_FILL, WARN_TEXT = "FFEB9C", "9C6500"
FAIL_FILL, FAIL_TEXT = "FFC7CE", "9C0006"
STATUS_STYLE = {"PASS": (PASS_FILL, PASS_TEXT), "WARNING": (WARN_FILL, WARN_TEXT), "FAIL": (FAIL_FILL, FAIL_TEXT)}
THIN = None  # set once openpyxl is known importable, see _border()


def _border():
    global THIN
    if THIN is None:
        side = Side(style="thin", color="DCE2EA")
        THIN = Border(left=side, right=side, top=side, bottom=side)
    return THIN


def _sheet(book, title, columns, rows, subtitle=""):
    """columns: [(key, label, width)]. rows: [dict]. Writes a header row (frozen, filterable,
    styled), one data row per dict (missing keys blank), colours any 'status' column PASS/WARNING/
    FAIL, and returns the worksheet."""
    ws = book.create_sheet(title)
    start = 1
    if subtitle:
        ws.cell(row=1, column=1, value=subtitle).font = Font(italic=True, color="5B6878")
        start = 3
    for c, (key, label, width) in enumerate(columns, start=1):
        cell = ws.cell(row=start, column=c, value=label)
        cell.font = Font(bold=True, color=HEADER_TEXT)
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.border = _border()
        ws.column_dimensions[get_column_letter(c)].width = width
    ws.row_dimensions[start].height = 26
    for r, row in enumerate(rows, start=start + 1):
        for c, (key, _, _) in enumerate(columns, start=1):
            value = row.get(key)
            cell = ws.cell(row=r, column=c, value=value)
            cell.border = _border()
            cell.alignment = Alignment(vertical="top", wrap_text=key in ("detail", "note", "notes"))
            if key == "status" and value in STATUS_STYLE:
                fill, text = STATUS_STYLE[value]
                cell.fill = PatternFill("solid", fgColor=fill)
                cell.font = Font(bold=True, color=text)
    last_row = max(start + 1, start + len(rows))
    last_col = get_column_letter(len(columns))
    ws.freeze_panes = ws.cell(row=start + 1, column=1).coordinate
    ws.auto_filter.ref = f"A{start}:{last_col}{last_row}"
    return ws


def _weighted_pct(statuses, weight=None):
    """PASS/WARNING/FAIL -> 0-100, weighting each row 1.0 / 0.5 / 0.0 by default. An empty list is
    treated as fully trustworthy (nothing to check counts as nothing outstanding), matching
    reporting.conversion_score's own empty-section convention."""
    weight = weight or {"PASS": 1.0, "WARNING": 0.5, "FAIL": 0.0}
    if not statuses:
        return 100.0
    return round(100 * sum(weight.get(s, 0.0) for s in statuses) / len(statuses), 1)


# ---------------------------------------------------------------------------- row builders
def _kpi_rows(plan):
    """One row per (worksheet, measure) actually placed on a page. See profiler.visual_kpis for
    why "Tableau Value" and "Power BI Value" are the same figure today, and the module docstring
    above for how a future live connector would change that."""
    rows = []
    for page in plan.pages:
        for pv in page.visuals:
            s = pv.spec
            if s.vtype in ("textbox", "slicer"):
                continue
            worksheet = f"{page.display} / {s.title or s.sheet}"
            measures = [p.name for p in s.all_projections() if p.kind == "measure"]
            if not measures:
                continue
            kpis, reason = profiler.visual_kpis(s, plan, plan.frames)
            if not kpis:
                for name in measures:
                    rows.append({"worksheet": worksheet, "measure": name, "tableau": None, "powerbi": None,
                                "diff": None, "pct": None, "status": "WARNING",
                                "note": f"Not automatically verified: {reason or 'no measures'}. "
                                        "Compare manually in Power BI Desktop after refresh."})
                continue
            for k in kpis:
                if k["value"] is None:
                    status = "FAIL" if k["error"] else "WARNING"
                    note = k["error"] or ("Not automatically verified — this measure isn't a simple "
                                          "aggregation the tool can recompute from source data; compare "
                                          "manually in Power BI Desktop after refresh.")
                    rows.append({"worksheet": worksheet, "measure": k["measure"], "tableau": None,
                                "powerbi": None, "diff": None, "pct": None, "status": status, "note": note})
                    continue
                v = round(k["value"], 2)
                rows.append({"worksheet": worksheet, "measure": k["measure"], "tableau": v, "powerbi": v,
                            "diff": 0.0, "pct": "0.00%", "status": "PASS",
                            "note": f"{k['derivation']} of {k['table']}[{k['column']}], proven against the "
                                    "shared source data."})
    return rows


def _data_validation_rows(plan):
    rows = []
    frames = plan.frames or {}
    for tname in plan.tables:
        t = plan.tables[tname]
        if t.kind == "calculated" or t.is_parameter:
            continue
        frame = frames.get(tname)
        if frame is None:
            rows.append({"table": tname, "tableau": None, "powerbi": None, "diff": None, "status": "WARNING",
                        "note": f"No profiled source data for this table ({t.source_note or t.source_kind or 'unknown source'}); "
                                "row counts not checked. Compare manually after refresh."})
            continue
        n = len(frame)
        rows.append({"table": tname, "tableau": n, "powerbi": n, "diff": 0, "status": "PASS",
                    "note": "Same source rows feed both the Tableau workbook and the generated Power Query table."})
    return rows


def _blend_rows(plan):
    rows = []
    for b in plan.blends:
        rows.append({"worksheet": b["worksheet"], "primary": b["primary"], "secondary": b["secondary"],
                    "linking": b["linking_fields"], "confidence": f"{b['confidence']}%",
                    "created": "Yes" if b["relationship_created"] else "No",
                    "status": b["status"], "detail": b["detail"]})
    return rows


def _security_rows(plan):
    if not plan.security:
        return [{"filter": "None detected", "roles": "N/A", "status": "PASS",
                "warning": "No Tableau row-level-security functions (USERNAME/FULLNAME/ISMEMBEROF/"
                          "ISFULLNAME/TABLEAUSERVER) were found in this workbook's calculations."}]
    rows = []
    for s in plan.security:
        rows.append({"filter": f"{s['calc']} (uses {s['function']})", "roles": "None (manual setup required)",
                    "status": "WARNING",
                    "warning": f"Formula `{s['formula']}` usually implements row-level security and was NOT "
                              "converted. Build an equivalent Power BI RLS role before sharing this report — "
                              "see MIGRATION_REPORT.md."})
    return rows


def _unsupported_rows(wb, plan):
    calc_items = [i for i in plan.items if i.area == "Calculation" and i.status == "placeholder"]
    groups = [
        ("Story Points", wb.unsupported.get("story_points", []),
         "Rebuild each story as a set of Power BI report pages with bookmarks (View > Bookmarks), "
         "or as a PowerPoint export."),
        ("Viz Extensions", wb.unsupported.get("viz_extensions", []),
         "Bar/Line/Donut/KPI Card extensions convert to a native Power BI visual automatically (see "
         "the Visuals section of MIGRATION_REPORT.md for which); none of the extension's own custom "
         "formatting, colours or layout carries over. Everything else (Sankey, Bullet, Heat Map, "
         "Sunburst, Hierarchy Table, ...) becomes a plain table with the same fields — find or build "
         "an equivalent Power BI custom visual (AppSource) for those."),
        ("Web Data Connectors", wb.unsupported.get("web_data_connectors", []),
         "Rebuild the connection as a Power Query web/API source (Get Data > Web, or a custom "
         "connector) pointing at the same endpoint."),
        ("Unsupported Calculations", [i.name for i in calc_items],
         "Each became a BLANK() measure/placeholder column; see \"Needs review\" in "
         "MIGRATION_REPORT.md for the specific Tableau formula and reason."),
    ]
    rows = []
    for feature, names, remediation in groups:
        rows.append({"feature": feature, "count": len(names),
                    "details": ", ".join(names) if names else "(none found)",
                    "remediation": "Yes — " + remediation if names else "No — none found"})
    return rows


# ---------------------------------------------------------------------------- build
def build(plan, wb, folder, name, validation, coverage_score):
    """Writes Reconciliation_Report.xlsx into `folder`. Returns a summary dict (also used to add a
    section to MIGRATION_REPORT.md), or None if openpyxl isn't importable."""
    if not available():
        return None
    kpi_rows = _kpi_rows(plan)
    data_rows = _data_validation_rows(plan)
    blend_rows = _blend_rows(plan)
    security_rows = _security_rows(plan)
    unsupported_rows = _unsupported_rows(wb, plan)

    all_checks = kpi_rows + data_rows + blend_rows + [r for r in security_rows if r.get("filter") != "None detected"]
    counts = Counter(r["status"] for r in all_checks)
    passed, failed, warnings = counts.get("PASS", 0), counts.get("FAIL", 0), counts.get("WARNING", 0)

    validation_score = _weighted_pct([r["status"] for r in kpi_rows + data_rows])
    security_score = _weighted_pct([r["status"] for r in security_rows])
    blend_score = _weighted_pct([r["status"] for r in blend_rows])
    coverage_pct = coverage_score["pct"] if coverage_score else 100.0
    overall = round((coverage_pct + validation_score + security_score + blend_score) / 4, 1)

    summary = {
        "workbook": wb.name, "worksheets": len(wb.worksheets),
        "measures_validated": len({r["measure"] for r in kpi_rows}),
        "kpi_checks": len(kpi_rows), "passed": passed, "failed": failed, "warnings": warnings,
        "coverage_pct": coverage_pct, "reconciliation_pct": validation_score,
        "security_score": security_score, "blend_score": blend_score, "trust_pct": overall,
        "schema_problems": len(validation.get("problems", [])),
    }

    book = openpyxl.Workbook()
    book.remove(book.active)
    _write_summary(book, plan, wb, summary)
    _sheet(book, "KPI Validation",
          [("worksheet", "Worksheet Name", 26), ("measure", "Measure Name", 24),
           ("tableau", "Tableau Value", 16), ("powerbi", "Power BI Value", 16),
           ("diff", "Difference", 14), ("pct", "% Difference", 14), ("status", "Status", 12),
           ("note", "Notes", 60)],
          kpi_rows,
          subtitle="Both value columns are computed from the same profiled source data (see the "
                   "Reconciliation Engine note on the Executive Summary sheet) — this proves the "
                   "generated DAX formula, not a live Power BI query result.")
    _sheet(book, "Data Validation",
          [("table", "Table Name", 26), ("tableau", "Tableau Row Count", 18),
           ("powerbi", "Power BI Row Count", 18), ("diff", "Difference", 12), ("status", "Status", 12),
           ("note", "Notes", 60)],
          data_rows)
    _sheet(book, "Data Blending Validation",
          [("worksheet", "Worksheet", 22), ("primary", "Primary Datasource", 22),
           ("secondary", "Secondary Datasource", 22), ("linking", "Linking Fields", 22),
           ("confidence", "Confidence Score", 16), ("created", "Relationship Created", 18),
           ("status", "Validation Status", 14), ("detail", "Details", 60)],
          blend_rows)
    _sheet(book, "Security Validation",
          [("filter", "Tableau User Filters Detected", 34), ("roles", "Power BI RLS Roles Created", 28),
           ("status", "Validation Status", 14), ("warning", "Warning Messages", 70)],
          security_rows)
    _sheet(book, "Unsupported Features",
          [("feature", "Feature", 26), ("count", "Count Detected", 14), ("details", "Details", 50),
           ("remediation", "Manual Remediation Required", 60)],
          unsupported_rows,
          subtitle="Story points, viz extensions and web data connectors are found with a best-effort scan "
                   "of the workbook XML (not yet verified against a real workbook using them): a count of 0 "
                   "means none were found by this scan, not a guarantee the workbook has none.")

    path = os.path.join(folder, "Reconciliation_Report.xlsx")
    book.save(path)

    # A JSON twin of the same data (not just the Executive Summary dict) so other tools — today,
    # assistant.py's AI Migration Assistant — can ground answers on the exact rows shown in the
    # spreadsheet without parsing the .xlsx binary.
    os.makedirs(os.path.join(folder, "validation"), exist_ok=True)
    with open(os.path.join(folder, "validation", "reconciliation_summary.json"), "w",
             encoding="utf-8", newline="\n") as f:
        json.dump({"summary": summary, "kpi_validation": kpi_rows, "data_validation": data_rows,
                  "data_blending_validation": blend_rows, "security_validation": security_rows,
                  "unsupported_features": unsupported_rows}, f, indent=1, ensure_ascii=False)
    return summary


def _write_summary(book, plan, wb, s):
    ws = book.create_sheet("Executive Summary", 0)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 46
    ws.sheet_view.showGridLines = False
    title = ws.cell(row=1, column=1, value="Reconciliation Report")
    title.font = Font(bold=True, size=18, color=HEADER_TEXT)
    ws.merge_cells("A1:B1")
    ws.cell(row=1, column=1).fill = PatternFill("solid", fgColor=HEADER_FILL)
    for c in range(1, 3):
        ws.cell(row=1, column=c).fill = PatternFill("solid", fgColor=HEADER_FILL)
    ws.row_dimensions[1].height = 30
    ws.cell(row=2, column=1, value="Generated by tableau2pbip's Reconciliation Engine").font = \
        Font(italic=True, color="5B6878")
    ws.merge_cells("A2:B2")

    def kv(row, label, value, bold_value=False, status=None):
        ws.cell(row=row, column=1, value=label).font = Font(bold=True)
        cell = ws.cell(row=row, column=2, value=value)
        if bold_value:
            cell.font = Font(bold=True, size=13)
        if status:
            fill, text = STATUS_STYLE.get(status, (None, None))
            if fill:
                cell.fill = PatternFill("solid", fgColor=fill)
                cell.font = Font(bold=True, color=text, size=13)

    r = 4
    kv(r, "Workbook Name", s["workbook"]); r += 1
    kv(r, "Number of Worksheets", s["worksheets"]); r += 1
    kv(r, "Number of Measures Validated", s["measures_validated"]); r += 1
    kv(r, "Passed Checks", s["passed"], status="PASS" if s["passed"] else None); r += 1
    kv(r, "Failed Checks", s["failed"], status="FAIL" if s["failed"] else "PASS"); r += 1
    kv(r, "Warnings", s["warnings"], status="WARNING" if s["warnings"] else "PASS"); r += 1
    r += 1
    kv(r, "Migration Coverage %", f"{s['coverage_pct']}%"); r += 1
    kv(r, "Reconciliation Score %", f"{s['reconciliation_pct']}%"); r += 1
    r += 1
    trust_status = "PASS" if s["trust_pct"] >= 90 else "WARNING" if s["trust_pct"] >= 70 else "FAIL"
    kv(r, "Overall Trust Score", f"{s['trust_pct']}%", bold_value=True, status=trust_status); r += 2

    ws.cell(row=r, column=1, value="Trust score breakdown").font = Font(bold=True, size=13)
    r += 1
    for label, pct in (("Migration Coverage Score", s["coverage_pct"]), ("Validation Score", s["reconciliation_pct"]),
                       ("Security Score", s["security_score"]), ("Data Blending Score", s["blend_score"])):
        kv(r, label, f"{pct}%")
        r += 1
    r += 1
    ws.cell(row=r, column=1, value="How these scores are computed").font = Font(bold=True, size=13)
    r += 1
    method = [
        "Migration Coverage Score: share of everything in the workbook that converted or has a "
        "working rule/AI answer (from MIGRATION_REPORT.md's conversion score).",
        "Validation Score: weighted pass rate across the KPI Validation and Data Validation sheets "
        "(PASS = 1.0, WARNING = 0.5, FAIL = 0.0).",
        "Security Score: 100% when no Tableau row-level-security functions were found; lower "
        "otherwise, since none are auto-converted to a Power BI RLS role.",
        "Data Blending Score: weighted pass rate across the Data Blending Validation sheet "
        "(a built relationship = PASS, anything left for manual review = WARNING).",
        "Overall Trust Score: the plain average of the four scores above.",
        "",
        "Methodology note: without a live connection to Tableau Server/Cloud/Desktop or a deployed "
        "Power BI semantic model / Fabric XMLA endpoint, \"Tableau Value\" and \"Power BI Value\" on the "
        "KPI Validation sheet are both computed from the same profiled source data — this proves the "
        "generated DAX formula is arithmetically consistent with that data, which is not the same as a "
        "live query match. Always refresh in Power BI Desktop and re-check before sharing externally.",
    ]
    for line in method:
        ws.cell(row=r, column=1, value=line).alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        ws.row_dimensions[r].height = 30 if line else 8
        r += 1
    if s["schema_problems"]:
        r += 1
        kv(r, "Schema validation problems", s["schema_problems"], status="FAIL")
    return ws
